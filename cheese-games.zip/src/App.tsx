import React, { useState, useEffect, useCallback, useRef } from 'react';
import { MainSection, BrowserTab, Game, PanicSettings } from './types';
import { LaserTrailCanvas } from './components/LaserTrailCanvas';
import { IntroSequence } from './components/IntroSequence';
import { TopBrowserBar } from './components/TopBrowserBar';
import { HeroSection } from './components/HeroSection';
import { GamesView } from './components/GamesView';
import { MoviesView } from './components/MoviesView';
import { CloakingView } from './components/CloakingView';
import { AiView } from './components/AiView';
import { GamePlayerModal } from './components/GamePlayerModal';
import { ProxyBrowserView } from './components/ProxyBrowserView';
import { initProxy, formatSearchOrUrl, decodeProxyUrl } from './utils/scramjetProxy';

const DEFAULT_TITLE = 'Cheese';
const DEFAULT_FAVICON = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🧀</text></svg>";

export default function App() {
  const [showIntro, setShowIntro] = useState<boolean>(true);
  const [activeSection, setActiveSection] = useState<MainSection>('games');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [activeProxyUrl, setActiveProxyUrl] = useState<string>('https://duckduckgo.com');

  // Initialize Scramjet & Epoxy Proxy Backend
  useEffect(() => {
    initProxy();
  }, []);

  // Configurable Panic Settings
  const [panicSettings, setPanicSettings] = useState<PanicSettings>(() => {
    const saved = localStorage.getItem('cheesy_panic_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return {
      key: 'Escape',
      code: 'Escape',
      url: 'https://classroom.google.com'
    };
  });

  const updatePanicSettings = (newSettings: PanicSettings) => {
    setPanicSettings(newSettings);
    localStorage.setItem('cheesy_panic_settings', JSON.stringify(newSettings));
  };

  // Tab & Cloaking State
  const [currentTitle, setCurrentTitle] = useState<string>(() => {
    return localStorage.getItem('cheesy_tab_title') || DEFAULT_TITLE;
  });
  const [currentFavicon, setCurrentFavicon] = useState<string>(() => {
    return localStorage.getItem('cheesy_tab_favicon') || DEFAULT_FAVICON;
  });

  // Browser Tabs system
  const [tabs, setTabs] = useState<BrowserTab[]>([
    {
      id: 'tab-main',
      title: 'Home',
      section: 'games',
      favicon: DEFAULT_FAVICON
    }
  ]);
  const [activeTabId, setActiveTabId] = useState<string>('tab-main');

  const activeTabIdRef = useRef(activeTabId);
  activeTabIdRef.current = activeTabId;

  // Apply Title & Favicon to actual browser DOM
  const applyCloakToDOM = useCallback((title: string, faviconUrl: string) => {
    document.title = title;
    setCurrentTitle(title);
    setCurrentFavicon(faviconUrl);
    localStorage.setItem('cheesy_tab_title', title);
    localStorage.setItem('cheesy_tab_favicon', faviconUrl);

    let link = document.getElementById('dynamic-favicon') as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement('link');
      link.id = 'dynamic-favicon';
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    link.href = faviconUrl;
  }, []);

  const resetCloak = useCallback(() => {
    applyCloakToDOM(DEFAULT_TITLE, DEFAULT_FAVICON);
  }, [applyCloakToDOM]);

  // Sync initial title and favicon to DOM on mount without triggering React state re-renders
  useEffect(() => {
    const savedTitle = localStorage.getItem('cheesy_tab_title') || DEFAULT_TITLE;
    const savedFavicon = localStorage.getItem('cheesy_tab_favicon') || DEFAULT_FAVICON;
    document.title = savedTitle;
    let link = document.getElementById('dynamic-favicon') as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement('link');
      link.id = 'dynamic-favicon';
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    link.href = savedFavicon;
  }, []);

  // Execute Panic Action
  const triggerPanic = useCallback(() => {
    applyCloakToDOM('Google Classroom', 'https://www.google.com/s2/favicons?domain=classroom.google.com&sz=64');
    window.location.href = panicSettings.url || 'https://classroom.google.com';
  }, [applyCloakToDOM, panicSettings.url]);

  // Global keydown for panic key
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        if (e.key === 'Escape') {
          triggerPanic();
        }
        return;
      }

      const matchKey = e.key.toLowerCase() === panicSettings.key.toLowerCase();
      const matchCode = e.code.toLowerCase() === panicSettings.code.toLowerCase();
      if (matchKey || matchCode) {
        e.preventDefault();
        triggerPanic();
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [panicSettings, triggerPanic]);

  // Tab management
  const handleSelectTab = useCallback((id: string) => {
    setActiveTabId(id);
    const found = tabs.find((t) => t.id === id);
    if (found) {
      setActiveSection(found.section);
      if (found.section === 'browser' && found.url) {
        setActiveProxyUrl(found.url);
        setSearchQuery(found.url);
      }
      if (found.gameData) {
        setSelectedGame(found.gameData);
      } else {
        setSelectedGame(null);
      }
    }
  }, [tabs]);

  const handleSearchSubmit = useCallback((query: string) => {
    const rawQuery = query.trim();
    if (!rawQuery) return;

    const formatted = formatSearchOrUrl(rawQuery);
    setSearchQuery(formatted);
    setActiveProxyUrl(formatted);
    setActiveSection('browser');
    setSelectedGame(null);

    // Dynamically change tab name and favicon based on what you looked up
    let displayTitle = rawQuery;
    let faviconUrl = DEFAULT_FAVICON;

    try {
      const cleanInput = rawQuery.replace(/^https?:\/\//i, '');
      const domain = cleanInput.split('/')[0];
      if (domain.includes('.') && !domain.includes(' ')) {
        displayTitle = domain;
        faviconUrl = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
      } else {
        displayTitle = rawQuery;
        faviconUrl = 'https://www.google.com/s2/favicons?domain=duckduckgo.com&sz=64';
      }
    } catch {
      displayTitle = rawQuery;
    }

    setTabs((prev) =>
      prev.map((t) =>
        t.id === activeTabIdRef.current
          ? {
              ...t,
              section: 'browser',
              title: displayTitle,
              url: formatted,
              favicon: faviconUrl,
              gameData: undefined
            }
          : t
      )
    );
  }, []);

  const handleCloseTab = useCallback((id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setTabs((prev) => {
      if (prev.length <= 1) return prev;
      const remaining = prev.filter((t) => t.id !== id);
      if (activeTabIdRef.current === id) {
        const nextTab = remaining[remaining.length - 1];
        setActiveTabId(nextTab.id);
        setActiveSection(nextTab.section);
        setSelectedGame(nextTab.gameData || null);
      }
      return remaining;
    });
  }, []);

  const handleNewTab = useCallback(() => {
    const newId = `tab-${Date.now()}`;
    const newTab: BrowserTab = {
      id: newId,
      title: 'Home',
      section: 'games',
      favicon: DEFAULT_FAVICON
    };
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newId);
    setActiveSection('games');
    setSelectedGame(null);
  }, []);

  const handleSelectSection = useCallback((section: MainSection) => {
    setActiveSection(section);
    setSelectedGame(null);
    setTabs((prev) =>
      prev.map((t) =>
        t.id === activeTabIdRef.current
          ? {
              ...t,
              section,
              title:
                section === 'games'
                  ? 'Cheese'
                  : section === 'ai'
                  ? 'Cheesy AI'
                  : section === 'movies'
                  ? 'Cinema Stream'
                  : 'Tab Cloaking',
              gameData: undefined
            }
          : t
      )
    );
  }, []);

  const handleSelectGame = useCallback((game: Game) => {
    setSelectedGame(game);
  }, []);

  const handleProxyNavigate = useCallback((url: string) => {
    setActiveProxyUrl(url);
    let navTitle = url;
    let favicon = DEFAULT_FAVICON;
    try {
      const parsed = new URL(url);
      navTitle = parsed.hostname.replace(/^www\./, '');
      favicon = `https://www.google.com/s2/favicons?domain=${parsed.hostname}&sz=64`;
    } catch {}

    setTabs((prev) =>
      prev.map((t) =>
        t.id === activeTabIdRef.current
          ? { ...t, url, title: navTitle, favicon }
          : t
      )
    );
  }, []);

  // Sync search bar and active tab whenever an in-page link or form inside the proxy is navigated
  useEffect(() => {
    const handleProxyMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'CHEESE_PROXY_NAVIGATE' && event.data.url) {
        let navUrl = event.data.url;
        if (typeof navUrl === 'string' && navUrl.includes('/service/')) {
          navUrl = decodeProxyUrl(navUrl);
        }
        setSearchQuery(navUrl);
        handleProxyNavigate(navUrl);
      }
    };
    window.addEventListener('message', handleProxyMessage);
    return () => window.removeEventListener('message', handleProxyMessage);
  }, [handleProxyNavigate]);

  const handleIntroComplete = useCallback(() => {
    setShowIntro(false);
  }, []);

  return (
    <div className="min-h-screen bg-[#070608] text-white flex flex-col font-mono relative selection:bg-yellow-400 selection:text-black">
      {/* 1. Laser Mouse Trail Canvas */}
      <LaserTrailCanvas />

      {/* 2. Intro Sequence */}
      {showIntro ? (
        <IntroSequence onComplete={handleIntroComplete} />
      ) : (
        <div className="flex-1 flex flex-col relative z-10">
          {/* Top Browser Bar */}
          <TopBrowserBar
            tabs={tabs}
            activeTabId={activeTabId}
            onSelectTab={handleSelectTab}
            onCloseTab={handleCloseTab}
            onNewTab={handleNewTab}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onSearchSubmit={handleSearchSubmit}
          />

          {/* Hero Section: Centered Cheese, search bar, and 4 destination buttons - hidden in browser mode so search shows on the whole tab */}
          {activeSection !== 'browser' && (
            <HeroSection
              currentSection={activeSection}
              onSelectSection={handleSelectSection}
              searchQuery={searchQuery}
              onSearch={setSearchQuery}
              onSearchSubmit={handleSearchSubmit}
            />
          )}

          {/* Main View Port */}
          <main className={`flex-1 flex flex-col min-h-0 ${activeSection === 'browser' ? 'p-0 pb-0' : 'pb-16'}`}>
            {activeSection === 'browser' && (
              <ProxyBrowserView
                initialUrl={activeProxyUrl}
                onNavigate={handleProxyNavigate}
              />
            )}

            {activeSection === 'games' && (
              <GamesView
                onSelectGame={handleSelectGame}
              />
            )}

            {activeSection === 'ai' && <AiView />}

            {activeSection === 'movies' && <MoviesView />}

            {activeSection === 'cloaking' && (
              <CloakingView
                currentTitle={currentTitle}
                currentFavicon={currentFavicon}
                onApplyCloak={applyCloakToDOM}
                onResetCloak={resetCloak}
                panicSettings={panicSettings}
                onUpdatePanicSettings={updatePanicSettings}
              />
            )}
          </main>

          {/* Game Player Modal without stealth tab button */}
          <GamePlayerModal
            game={selectedGame}
            onClose={() => setSelectedGame(null)}
          />

          {/* Underground style footer with updated creator credits - hidden in browser mode so proxied content fills tab */}
          {activeSection !== 'browser' && (
            <footer className="w-full border-t-2 border-stone-800 py-5 px-4 text-center bg-black">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 text-xs text-stone-500 font-mono">
                <span className="font-orbitron font-black text-yellow-400">CHEESE</span>
                <span className="hidden sm:inline">•</span>
                <span className="text-orange-500">From the creators of Cheese</span>
                <span className="hidden sm:inline">•</span>
                <span>We like it drippy</span>
              </div>
            </footer>
          )}
        </div>
      )}
    </div>
  );
}
