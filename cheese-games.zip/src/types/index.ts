export type GameType = 'ugs-cdn' | 'gn-math' | 'builtin-2048' | 'builtin-flappy' | 'builtin-snake' | 'iframe';

export type GameProvider = 'gn-math' | 'ugs' | 'truffled';

export interface Game {
  id: string;
  title: string;
  thumbnail?: string;
  category?: string;
  file?: string; // UGS filename like cl1v1lol
  embedUrl?: string;
  type: GameType;
  popular?: boolean;
  provider?: GameProvider;
}

export type MainSection = 'browser' | 'games' | 'ai' | 'movies' | 'cloaking';

export interface BrowserTab {
  id: string;
  title: string;
  section: MainSection;
  favicon?: string;
  gameData?: Game;
  url?: string;
}

export interface PanicSettings {
  key: string;
  code: string;
  url: string;
}
