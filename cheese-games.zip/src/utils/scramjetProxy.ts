export const SCRAMJET_PREFIX = '/service/';

let isInitialized = false;
let initPromise: Promise<boolean> | null = null;
let scramjetControllerInstance: any = null;
let epoxyTransportInstance: any = null;

/**
 * Formats a user input string into either a direct URL or a DuckDuckGo search query URL.
 * When user searches something, it uses DuckDuckGo.
 */
export function formatSearchOrUrl(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) {
    return 'https://duckduckgo.com/?kae=d';
  }

  // If already full protocol
  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }

  // If looks like a domain name (e.g., example.com, now.gg, discord.com/login, roblox.com)
  const isDomain = /^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}(:\d+)?(\/.*)?$/i.test(trimmed);
  if (isDomain && !trimmed.includes(' ')) {
    return `https://${trimmed}`;
  }

  // Otherwise, default to modern DuckDuckGo search with bot-safe parameters
  return `https://duckduckgo.com/?q=${encodeURIComponent(trimmed)}&t=h_&ia=web&kae=d`;
}

/**
 * Ensures the $scramjet IndexedDB database exists and contains all required object stores.
 */
export async function ensureScramjetDatabase(): Promise<void> {
  if (typeof window === 'undefined' || !window.indexedDB) return;

  const stores = ['config', 'cookies', 'redirectTrackers', 'referrerPolicies', 'publicSuffixList'];

  return new Promise<void>((resolve) => {
    try {
      const openReq = indexedDB.open('$scramjet');
      openReq.onupgradeneeded = () => {
        const db = openReq.result;
        for (const s of stores) {
          if (!db.objectStoreNames.contains(s)) {
            db.createObjectStore(s);
          }
        }
      };
      openReq.onsuccess = () => {
        const db = openReq.result;
        const missing = stores.filter((s) => !db.objectStoreNames.contains(s));
        const ver = db.version;
        db.close();

        if (missing.length === 0) {
          resolve();
          return;
        }

        // Database exists but is missing required stores -> trigger version upgrade
        const upReq = indexedDB.open('$scramjet', ver + 1);
        upReq.onupgradeneeded = () => {
          const udb = upReq.result;
          for (const s of stores) {
            if (!udb.objectStoreNames.contains(s)) {
              udb.createObjectStore(s);
            }
          }
        };
        upReq.onsuccess = () => {
          upReq.result.close();
          resolve();
        };
        upReq.onerror = () => resolve();
      };
      openReq.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

/**
 * Initializes Epoxy transport and Scramjet Controller with Service Worker.
 */
export async function initProxy(): Promise<boolean> {
  if (typeof window === 'undefined') return false;
  if (isInitialized) return true;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    try {
      // 0. Ensure Scramjet IndexedDB stores exist before loading controller
      await ensureScramjetDatabase();

      const anyWin = window as any;

      // 1. Initialize Epoxy Transport from /epoxy/index.js
      if (typeof anyWin.EpoxyTransport === 'function' && !epoxyTransportInstance) {
        try {
          epoxyTransportInstance = new anyWin.EpoxyTransport({
            wisp_v2: true
          });
          if (typeof epoxyTransportInstance.init === 'function') {
            await epoxyTransportInstance.init();
          }
          console.log('[Proxy] Epoxy transport initialized successfully');
        } catch (epoxyErr) {
          console.warn('[Proxy] Epoxy transport note:', epoxyErr);
        }
      }

      // 2. Register Service Worker
      if ('serviceWorker' in navigator) {
        try {
          const reg = await navigator.serviceWorker.register('/sw.js', {
            scope: '/'
          });
          console.log('[Scramjet Proxy] ServiceWorker registered with scope:', reg.scope);
        } catch (swErr) {
          console.warn('[Scramjet Proxy] ServiceWorker register note:', swErr);
        }
      }

      // 3. Initialize ScramjetController
      if (typeof anyWin.$scramjetLoadController === 'function') {
        const { ScramjetController } = anyWin.$scramjetLoadController();

        scramjetControllerInstance = new ScramjetController({
          prefix: SCRAMJET_PREFIX,
          files: {
            wasm: '/scramjet/scramjet.wasm.wasm',
            all: '/scramjet/scramjet.all.js',
            sync: '/scramjet/scramjet.sync.js'
          },
          flags: {
            serviceworkers: false,
            syncxhr: false,
            strictRewrites: false,
            rewriterLogs: false,
            captureErrors: true,
            allowInvalidJs: true
          }
        });

        await scramjetControllerInstance.init();
        isInitialized = true;
        console.log('[Scramjet Proxy] Controller initialized successfully with Epoxy');
        return true;
      }
    } catch (err) {
      console.error('[Scramjet Proxy] Initialization error:', err);
    }
    return false;
  })();

  return initPromise;
}

/**
 * Returns whether the proxy controller has been initialized.
 */
export function isProxyReady(): boolean {
  return isInitialized;
}

/**
 * Encodes a URL for proxy navigation via Scramjet v2.
 */
export function encodeProxyUrl(targetUrl: string): string {
  const formatted = formatSearchOrUrl(targetUrl);
  if (scramjetControllerInstance && typeof scramjetControllerInstance.encodeUrl === 'function') {
    try {
      return scramjetControllerInstance.encodeUrl(formatted);
    } catch (err) {
      console.warn('[Scramjet v2] encodeUrl fallback error:', err);
    }
  }

  // Scramjet v2 service route
  return `${SCRAMJET_PREFIX}${encodeURIComponent(formatted)}`;
}

/**
 * Decodes a proxied URL back to its original target URL.
 */
export function decodeProxyUrl(proxiedUrl: string): string {
  if (scramjetControllerInstance && typeof scramjetControllerInstance.decodeUrl === 'function') {
    try {
      return scramjetControllerInstance.decodeUrl(proxiedUrl);
    } catch {}
  }

  if (proxiedUrl.startsWith(SCRAMJET_PREFIX)) {
    try {
      return decodeURIComponent(proxiedUrl.slice(SCRAMJET_PREFIX.length));
    } catch {}
  }

  if (proxiedUrl.includes('/api/proxy?url=')) {
    try {
      const parsed = new URL(proxiedUrl, window.location.origin);
      const target = parsed.searchParams.get('url');
      if (target) return decodeURIComponent(target);
    } catch {}
  }

  return proxiedUrl;
}
