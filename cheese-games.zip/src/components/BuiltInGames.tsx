import React, { useState, useEffect, useRef } from 'react';
import { RotateCcw, Trophy, ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Play } from 'lucide-react';

/* -------------------------------------------------------------
 * 1. 2048 CHEESE EDITION
 * ------------------------------------------------------------- */
export const Game2048: React.FC = () => {
  const [grid, setGrid] = useState<number[][]>(() => initGrid());
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('cheesy_2048_best') || '0', 10);
  });
  const [gameOver, setGameOver] = useState<boolean>(false);

  function initGrid() {
    const empty = Array(4).fill(0).map(() => Array(4).fill(0));
    addRandom(empty);
    addRandom(empty);
    return empty;
  }

  function addRandom(board: number[][]) {
    const emptyCells: { r: number; c: number }[] = [];
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        if (board[r][c] === 0) emptyCells.push({ r, c });
      }
    }
    if (emptyCells.length === 0) return;
    const { r, c } = emptyCells[Math.floor(Math.random() * emptyCells.length)];
    board[r][c] = Math.random() < 0.9 ? 2 : 4;
  }

  const resetGame = () => {
    const fresh = initGrid();
    setGrid(fresh);
    setScore(0);
    setGameOver(false);
  };

  const move = (direction: 'up' | 'down' | 'left' | 'right') => {
    if (gameOver) return;
    let rotated = JSON.parse(JSON.stringify(grid));
    let moved = false;
    let gainedScore = 0;

    const slide = (row: number[]) => {
      let filtered = row.filter((val) => val !== 0);
      for (let i = 0; i < filtered.length - 1; i++) {
        if (filtered[i] === filtered[i + 1]) {
          filtered[i] *= 2;
          gainedScore += filtered[i];
          filtered[i + 1] = 0;
        }
      }
      filtered = filtered.filter((val) => val !== 0);
      while (filtered.length < 4) filtered.push(0);
      return filtered;
    };

    if (direction === 'left') {
      for (let r = 0; r < 4; r++) {
        const nextRow = slide(rotated[r]);
        if (nextRow.join(',') !== rotated[r].join(',')) moved = true;
        rotated[r] = nextRow;
      }
    } else if (direction === 'right') {
      for (let r = 0; r < 4; r++) {
        const reversed = [...rotated[r]].reverse();
        const nextRow = slide(reversed).reverse();
        if (nextRow.join(',') !== rotated[r].join(',')) moved = true;
        rotated[r] = nextRow;
      }
    } else if (direction === 'up') {
      for (let c = 0; c < 4; c++) {
        const col = [rotated[0][c], rotated[1][c], rotated[2][c], rotated[3][c]];
        const nextCol = slide(col);
        for (let r = 0; r < 4; r++) {
          if (rotated[r][c] !== nextCol[r]) moved = true;
          rotated[r][c] = nextCol[r];
        }
      }
    } else if (direction === 'down') {
      for (let c = 0; c < 4; c++) {
        const col = [rotated[3][c], rotated[2][c], rotated[1][c], rotated[0][c]];
        const nextCol = slide(col);
        for (let r = 0; r < 4; r++) {
          if (rotated[3 - r][c] !== nextCol[r]) moved = true;
          rotated[3 - r][c] = nextCol[r];
        }
      }
    }

    if (moved) {
      addRandom(rotated);
      setGrid(rotated);
      const newScore = score + gainedScore;
      setScore(newScore);
      if (newScore > bestScore) {
        setBestScore(newScore);
        localStorage.setItem('cheesy_2048_best', newScore.toString());
      }
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        move('up');
      } else if (['ArrowDown', 'KeyS'].includes(e.code)) {
        e.preventDefault();
        move('down');
      } else if (['ArrowLeft', 'KeyA'].includes(e.code)) {
        e.preventDefault();
        move('left');
      } else if (['ArrowRight', 'KeyD'].includes(e.code)) {
        e.preventDefault();
        move('right');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [grid, gameOver, score, bestScore]);

  const getTileStyle = (val: number) => {
    switch (val) {
      case 2: return 'bg-amber-100/10 text-amber-200 border-amber-300/30';
      case 4: return 'bg-amber-300/20 text-amber-300 border-amber-400/40';
      case 8: return 'bg-amber-500/30 text-amber-400 border-amber-500/60 shadow-[0_0_10px_rgba(245,158,11,0.3)]';
      case 16: return 'bg-orange-500/40 text-orange-300 border-orange-500/70 shadow-[0_0_12px_rgba(249,115,22,0.4)]';
      case 32: return 'bg-orange-600/50 text-orange-200 border-orange-500 shadow-[0_0_15px_rgba(234,88,12,0.5)]';
      case 64: return 'bg-red-500/50 text-red-100 border-red-500 shadow-[0_0_18px_rgba(239,68,68,0.6)]';
      case 128: return 'bg-yellow-400 text-stone-950 font-black shadow-[0_0_20px_#facc15]';
      case 256: return 'bg-amber-400 text-stone-950 font-black shadow-[0_0_25px_#fbbf24]';
      case 512: return 'bg-orange-500 text-white font-black shadow-[0_0_30px_#f97316]';
      case 1024: return 'bg-red-600 text-white font-black shadow-[0_0_35px_#dc2626]';
      case 2048: return 'bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-500 text-black font-black shadow-[0_0_40px_#ffea00]';
      default: return 'bg-stone-900/60 text-stone-600 border-stone-800';
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-6 bg-stone-950 text-white select-none max-w-md mx-auto">
      {/* Header */}
      <div className="w-full flex items-center justify-between mb-4">
        <div>
          <h2 className="font-orbitron font-extrabold text-2xl text-amber-400">2048 CHEESE</h2>
          <p className="text-[11px] font-mono text-stone-400">Combine molten tiles to reach 2048</p>
        </div>
        <div className="flex gap-2">
          <div className="px-3 py-1 bg-stone-900 border border-stone-800 rounded-lg text-center">
            <div className="text-[9px] font-mono text-stone-400">SCORE</div>
            <div className="text-sm font-bold text-amber-300 font-mono">{score}</div>
          </div>
          <div className="px-3 py-1 bg-stone-900 border border-amber-500/30 rounded-lg text-center">
            <div className="text-[9px] font-mono text-amber-400">BEST</div>
            <div className="text-sm font-bold text-amber-400 font-mono">{bestScore}</div>
          </div>
        </div>
      </div>

      {/* Grid container */}
      <div className="w-80 h-80 bg-stone-900/90 p-2.5 rounded-2xl border-2 border-amber-500/40 grid grid-cols-4 gap-2.5 shadow-2xl relative">
        {grid.map((row, r) =>
          row.map((cell, c) => (
            <div
              key={`${r}-${c}`}
              className={`rounded-xl flex items-center justify-center font-orbitron font-bold text-lg sm:text-xl border transition-all duration-150 ${getTileStyle(cell)}`}
            >
              {cell > 0 ? cell : ''}
            </div>
          ))
        )}
      </div>

      {/* Control Buttons */}
      <div className="mt-5 flex items-center justify-between w-full">
        <button
          onClick={resetGame}
          className="flex items-center gap-1.5 px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-mono rounded-xl border border-stone-700 cursor-pointer transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>New Game</span>
        </button>

        <div className="grid grid-cols-3 gap-1">
          <div />
          <button onClick={() => move('up')} className="p-2 bg-stone-900 hover:bg-amber-500 hover:text-black rounded-lg border border-stone-800 cursor-pointer transition-colors">
            <ArrowUp className="w-4 h-4" />
          </button>
          <div />
          <button onClick={() => move('left')} className="p-2 bg-stone-900 hover:bg-amber-500 hover:text-black rounded-lg border border-stone-800 cursor-pointer transition-colors">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button onClick={() => move('down')} className="p-2 bg-stone-900 hover:bg-amber-500 hover:text-black rounded-lg border border-stone-800 cursor-pointer transition-colors">
            <ArrowDown className="w-4 h-4" />
          </button>
          <button onClick={() => move('right')} className="p-2 bg-stone-900 hover:bg-amber-500 hover:text-black rounded-lg border border-stone-800 cursor-pointer transition-colors">
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

/* -------------------------------------------------------------
 * 2. FLAPPY CHEESE
 * ------------------------------------------------------------- */
export const FlappyCheese: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [gameState, setGameState] = useState<'start' | 'playing' | 'gameover'>('start');
  const [score, setScore] = useState(0);
  const [bestScore, setBestScore] = useState(() => {
    return parseInt(localStorage.getItem('cheesy_flappy_best') || '0', 10);
  });

  const stateRef = useRef({
    birdY: 180,
    birdVelocity: 0,
    gravity: 0.35,
    jump: -6.5,
    pipes: [] as { x: number; top: number; bottom: number; passed: boolean }[],
    score: 0,
    isPlaying: false
  });

  const startGame = () => {
    stateRef.current = {
      birdY: 180,
      birdVelocity: 0,
      gravity: 0.35,
      jump: -6.5,
      pipes: [
        { x: 380, top: 120, bottom: 240, passed: false },
        { x: 560, top: 160, bottom: 280, passed: false }
      ],
      score: 0,
      isPlaying: true
    };
    setScore(0);
    setGameState('playing');
  };

  const flap = () => {
    if (gameState === 'start' || gameState === 'gameover') {
      startGame();
    } else {
      stateRef.current.birdVelocity = stateRef.current.jump;
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') {
        e.preventDefault();
        flap();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const loop = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Background
      ctx.fillStyle = '#0f0c13';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Stars/Dots
      ctx.fillStyle = 'rgba(255, 234, 0, 0.2)';
      for (let i = 0; i < 20; i++) {
        ctx.fillRect((i * 45) % canvas.width, (i * 35) % canvas.height, 2, 2);
      }

      if (stateRef.current.isPlaying) {
        const s = stateRef.current;
        s.birdVelocity += s.gravity;
        s.birdY += s.birdVelocity;

        // Ground / Ceiling collision
        if (s.birdY > canvas.height - 25 || s.birdY < 15) {
          s.isPlaying = false;
          setGameState('gameover');
        }

        // Pipe loop
        for (let i = 0; i < s.pipes.length; i++) {
          const pipe = s.pipes[i];
          pipe.x -= 2.2;

          // Check if bird passed pipe
          if (!pipe.passed && pipe.x < 70) {
            pipe.passed = true;
            s.score += 1;
            setScore(s.score);
            if (s.score > bestScore) {
              setBestScore(s.score);
              localStorage.setItem('cheesy_flappy_best', s.score.toString());
            }
          }

          // Pipe collision
          if (
            pipe.x < 90 &&
            pipe.x > 30 &&
            (s.birdY < pipe.top || s.birdY > pipe.bottom)
          ) {
            s.isPlaying = false;
            setGameState('gameover');
          }

          // Draw pipe top (Cheese pipe)
          ctx.fillStyle = '#ea580c';
          ctx.fillRect(pipe.x, 0, 48, pipe.top);
          ctx.fillStyle = '#fbbf24';
          ctx.fillRect(pipe.x + 4, 0, 40, pipe.top);

          // Pipe bottom
          ctx.fillStyle = '#ea580c';
          ctx.fillRect(pipe.x, pipe.bottom, 48, canvas.height - pipe.bottom);
          ctx.fillStyle = '#fbbf24';
          ctx.fillRect(pipe.x + 4, pipe.bottom, 40, canvas.height - pipe.bottom);
        }

        // Recycle pipes
        if (s.pipes.length > 0 && s.pipes[0].x < -60) {
          s.pipes.shift();
          const top = 60 + Math.random() * 150;
          const gap = 120;
          s.pipes.push({
            x: canvas.width + 40,
            top,
            bottom: top + gap,
            passed: false
          });
        }
      }

      // Draw Bird (Cheese wedge)
      ctx.save();
      ctx.translate(65, stateRef.current.birdY);
      ctx.rotate((stateRef.current.birdVelocity * 3.5 * Math.PI) / 180);
      ctx.font = '28px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🧀', 0, 0);
      ctx.restore();

      animId = requestAnimationFrame(loop);
    };

    loop();
    return () => cancelAnimationFrame(animId);
  }, [bestScore]);

  return (
    <div className="flex flex-col items-center justify-center p-4 bg-stone-950 text-white select-none">
      <div className="w-full max-w-sm flex items-center justify-between mb-3">
        <span className="font-orbitron font-bold text-lg text-amber-400">FLAPPY CHEESE</span>
        <div className="flex gap-2 text-xs font-mono">
          <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded">SCORE: {score}</span>
          <span className="px-2 py-1 bg-stone-900 border border-amber-500/40 text-amber-400 rounded">BEST: {bestScore}</span>
        </div>
      </div>

      <div className="relative cursor-pointer rounded-2xl overflow-hidden border-2 border-amber-500/40 shadow-2xl" onClick={flap}>
        <canvas ref={canvasRef} width={360} height={420} className="block" />

        {gameState === 'start' && (
          <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center p-4 text-center">
            <div className="text-4xl mb-2 animate-bounce">🧀</div>
            <h3 className="font-orbitron font-extrabold text-xl text-yellow-400 mb-1">TAP OR SPACE TO FLAP</h3>
            <p className="text-xs text-stone-300 font-mono">Dodge molten cheddar pipes!</p>
          </div>
        )}

        {gameState === 'gameover' && (
          <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center p-4 text-center">
            <h3 className="font-orbitron font-extrabold text-2xl text-red-500 mb-1">CRUNCHED!</h3>
            <p className="text-sm font-mono text-amber-300 mb-4">Final Score: {score}</p>
            <button
              onClick={startGame}
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-bold font-orbitron text-xs rounded-xl shadow-lg cursor-pointer"
            >
              PLAY AGAIN
            </button>
          </div>
        )}
      </div>
      <p className="text-[11px] font-mono text-stone-400 mt-2">Spacebar, Up Arrow or Click to Fly</p>
    </div>
  );
};

/* -------------------------------------------------------------
 * 3. NEON SNAKE
 * ------------------------------------------------------------- */
export const NeonSnake: React.FC = () => {
  const [snake, setSnake] = useState([{ x: 10, y: 10 }]);
  const [food, setFood] = useState({ x: 15, y: 15 });
  const [dir, setDir] = useState<'UP' | 'DOWN' | 'LEFT' | 'RIGHT'>('RIGHT');
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const dirRef = useRef<'UP' | 'DOWN' | 'LEFT' | 'RIGHT'>('RIGHT');

  const restart = () => {
    setSnake([{ x: 10, y: 10 }]);
    setFood({ x: 15, y: 15 });
    dirRef.current = 'RIGHT';
    setDir('RIGHT');
    setScore(0);
    setGameOver(false);
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp' && dirRef.current !== 'DOWN') dirRef.current = 'UP';
      else if (e.key === 'ArrowDown' && dirRef.current !== 'UP') dirRef.current = 'DOWN';
      else if (e.key === 'ArrowLeft' && dirRef.current !== 'RIGHT') dirRef.current = 'LEFT';
      else if (e.key === 'ArrowRight' && dirRef.current !== 'LEFT') dirRef.current = 'RIGHT';
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  useEffect(() => {
    if (gameOver) return;
    const interval = setInterval(() => {
      setSnake((prev) => {
        const head = { ...prev[0] };
        const d = dirRef.current;
        if (d === 'UP') head.y -= 1;
        if (d === 'DOWN') head.y += 1;
        if (d === 'LEFT') head.x -= 1;
        if (d === 'RIGHT') head.x += 1;

        // Collision wall
        if (head.x < 0 || head.x >= 20 || head.y < 0 || head.y >= 20) {
          setGameOver(true);
          return prev;
        }

        // Collision self
        if (prev.some((seg) => seg.x === head.x && seg.y === head.y)) {
          setGameOver(true);
          return prev;
        }

        const newSnake = [head, ...prev];
        if (head.x === food.x && head.y === food.y) {
          setScore((s) => s + 10);
          setFood({
            x: Math.floor(Math.random() * 20),
            y: Math.floor(Math.random() * 20)
          });
        } else {
          newSnake.pop();
        }
        return newSnake;
      });
    }, 110);
    return () => clearInterval(interval);
  }, [gameOver, food]);

  return (
    <div className="flex flex-col items-center justify-center p-4 bg-stone-950 text-white select-none">
      <div className="w-full max-w-sm flex items-center justify-between mb-3">
        <span className="font-orbitron font-bold text-lg text-amber-400">NEON SNAKE</span>
        <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded text-xs font-mono">
          SCORE: {score}
        </span>
      </div>

      <div className="relative w-[340px] h-[340px] bg-stone-900/90 rounded-2xl border-2 border-amber-500/40 p-1 grid grid-cols-20 grid-rows-20 shadow-2xl">
        {Array.from({ length: 400 }).map((_, i) => {
          const x = i % 20;
          const y = Math.floor(i / 20);
          const isHead = snake[0].x === x && snake[0].y === y;
          const isBody = snake.slice(1).some((s) => s.x === x && s.y === y);
          const isFood = food.x === x && food.y === y;

          return (
            <div
              key={i}
              className={`rounded-sm transition-colors ${
                isHead
                  ? 'bg-amber-300 shadow-[0_0_8px_#ffea00]'
                  : isBody
                  ? 'bg-amber-500/80'
                  : isFood
                  ? 'bg-red-500 rounded-full animate-pulse shadow-[0_0_8px_#ef4444]'
                  : 'bg-transparent'
              }`}
            />
          );
        })}

        {gameOver && (
          <div className="absolute inset-0 bg-black/80 rounded-2xl flex flex-col items-center justify-center p-4">
            <h3 className="font-orbitron font-bold text-xl text-red-500 mb-2">GAME OVER</h3>
            <p className="text-xs font-mono text-amber-300 mb-4">Score: {score}</p>
            <button
              onClick={restart}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-bold font-orbitron text-xs rounded-xl shadow cursor-pointer"
            >
              PLAY AGAIN
            </button>
          </div>
        )}
      </div>

      {/* Control Pad */}
      <div className="mt-4 grid grid-cols-3 gap-1">
        <div />
        <button onClick={() => { if (dirRef.current !== 'DOWN') dirRef.current = 'UP'; }} className="p-2 bg-stone-900 border border-stone-800 hover:bg-amber-500 hover:text-black rounded-lg cursor-pointer">
          <ArrowUp className="w-4 h-4" />
        </button>
        <div />
        <button onClick={() => { if (dirRef.current !== 'RIGHT') dirRef.current = 'LEFT'; }} className="p-2 bg-stone-900 border border-stone-800 hover:bg-amber-500 hover:text-black rounded-lg cursor-pointer">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <button onClick={() => { if (dirRef.current !== 'UP') dirRef.current = 'DOWN'; }} className="p-2 bg-stone-900 border border-stone-800 hover:bg-amber-500 hover:text-black rounded-lg cursor-pointer">
          <ArrowDown className="w-4 h-4" />
        </button>
        <button onClick={() => { if (dirRef.current !== 'LEFT') dirRef.current = 'RIGHT'; }} className="p-2 bg-stone-900 border border-stone-800 hover:bg-amber-500 hover:text-black rounded-lg cursor-pointer">
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
