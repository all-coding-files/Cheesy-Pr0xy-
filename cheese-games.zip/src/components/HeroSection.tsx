import React from 'react';
import { MainSection } from '../types';
import { Search, Gamepad2, Bot, Film, Shield, RefreshCw } from 'lucide-react';

interface HeroSectionProps {
  currentSection: MainSection;
  onSelectSection: (section: MainSection) => void;
  onSearch: (query: string) => void;
  searchQuery: string;
  onSearchSubmit?: (query: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  currentSection,
  onSelectSection,
  onSearch,
  searchQuery,
  onSearchSubmit
}) => {
  // Destination buttons: Games, AI, Movies, Cloaking (Apps and TOS removed as requested)
  const destinationButtons: {
    id: MainSection;
    label: string;
    icon: (isActive: boolean) => React.ReactNode;
  }[] = [
    {
      id: 'games',
      label: 'Games',
      icon: (isActive) => (
        <Gamepad2
          className={`w-5 h-5 transition-colors ${
            isActive ? 'text-black' : 'text-yellow-400 group-hover:text-yellow-300'
          }`}
        />
      )
    },
    {
      id: 'ai',
      label: 'AI',
      icon: (isActive) => (
        <Bot
          className={`w-5 h-5 transition-colors ${
            isActive ? 'text-black' : 'text-yellow-400 group-hover:text-yellow-300'
          }`}
        />
      )
    },
    {
      id: 'movies',
      label: 'Movies',
      icon: (isActive) => (
        <Film
          className={`w-5 h-5 transition-colors ${
            isActive ? 'text-black' : 'text-yellow-400 group-hover:text-yellow-300'
          }`}
        />
      )
    },
    {
      id: 'cloaking',
      label: 'Cloaking',
      icon: (isActive) => (
        <Shield
          className={`w-5 h-5 transition-colors ${
            isActive ? 'text-black' : 'text-yellow-400 group-hover:text-yellow-300'
          }`}
        />
      )
    }
  ];

  return (
    <div className="w-full flex flex-col items-center justify-center pt-8 pb-6 px-4 text-center select-none relative">
      {/* Title: CHEESE */}
      <div className="inline-flex items-center justify-center mb-1 mx-auto text-center">
        <h1 className="font-orbitron font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-widest text-[#ffe600] drop-shadow-[0_0_35px_rgba(255,230,0,0.95)] uppercase text-center whitespace-nowrap">
          CHEESE
        </h1>
      </div>

      {/* Centered "We like it drippy" */}
      <div className="font-orbitron font-black text-lg sm:text-2xl md:text-3xl tracking-widest uppercase text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-400 to-red-500 drop-shadow-[0_2px_10px_rgba(239,68,68,0.5)] mb-6 text-center">
        We like it drippy
      </div>

      {/* Centered Web & Proxy Search bar under the Cheese title with reload website button */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (onSearchSubmit) onSearchSubmit(searchQuery);
        }}
        className="w-full max-w-2xl mb-6 mx-auto"
      >
        <div className="relative flex items-center">
          <Search className="absolute left-4 w-5 h-5 text-yellow-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearch(e.target.value)}
            placeholder="Search DuckDuckGo or enter URL (e.g. roblox.com)..."
            className="w-full pl-12 pr-40 py-3.5 rounded-xl bg-black border-2 border-yellow-400 text-white placeholder-stone-500 font-mono text-sm sm:text-base focus:outline-none focus:border-red-500 focus:shadow-[0_0_20px_rgba(255,234,0,0.7)] shadow-xl"
          />
          <div className="absolute right-2.5 flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="p-1.5 rounded-lg bg-stone-900 border border-stone-800 hover:border-yellow-400 text-stone-400 hover:text-yellow-400 transition-colors cursor-pointer"
              title="Reload Website"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearch('')}
                className="px-2 py-1 rounded bg-stone-800 text-stone-400 hover:text-white text-xs font-mono cursor-pointer"
              >
                Clear
              </button>
            )}
            <button
              type="submit"
              className="px-3 py-1.5 rounded-lg bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs sm:text-sm font-mono transition-transform hover:scale-105 cursor-pointer flex items-center gap-1.5 shadow-[0_0_12px_rgba(255,234,0,0.6)]"
              title="Search with DuckDuckGo on Scramjet Proxy"
            >
              <Search className="w-4 h-4" />
              <span>Search</span>
            </button>
          </div>
        </div>
      </form>

      {/* DESTINATION BUTTONS (Games, AI, Movies, Cloaking) */}
      <div className="w-full max-w-2xl grid grid-cols-2 sm:grid-cols-4 gap-3 mx-auto">
        {destinationButtons.map((btn) => {
          const isActive = currentSection === btn.id;
          return (
            <button
              key={btn.id}
              onClick={() => onSelectSection(btn.id)}
              className={`flex items-center justify-center gap-2 py-3 px-3 rounded-xl border-2 transition-all cursor-pointer group ${
                isActive
                  ? 'bg-yellow-400 text-black border-yellow-300 shadow-[0_0_25px_rgba(255,234,0,0.8)] scale-103'
                  : 'bg-black text-white border-stone-800 hover:border-yellow-400 hover:bg-stone-900 hover:-translate-y-0.5'
              }`}
            >
              <div className="p-1 rounded-lg flex items-center justify-center shrink-0">
                {btn.icon(isActive)}
              </div>
              <span className={`font-orbitron font-black text-xs sm:text-sm tracking-wider uppercase ${
                isActive ? 'text-black' : 'text-white'
              }`}>
                {btn.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
