import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FastForward, Sparkles } from 'lucide-react';

interface IntroSequenceProps {
  onComplete: () => void;
}

export const IntroSequence: React.FC<IntroSequenceProps> = ({ onComplete }) => {
  // Phase 0: "U were bored"
  // Phase 1: "In the middle of class"
  // Phase 2: "So you switched Tabs to..."
  // Phase 3: "CHEESY GAMES" + "We like it drippy"
  const [phase, setPhase] = useState<number>(0);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    const timer1 = setTimeout(() => setPhase(1), 2400);
    const timer2 = setTimeout(() => setPhase(2), 4800);
    const timer3 = setTimeout(() => setPhase(3), 7200);
    const timerFinish = setTimeout(() => {
      onCompleteRef.current?.();
    }, 11500);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timerFinish);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-40 bg-radial from-[#1a1209] via-[#0d0905] to-[#040302] flex flex-col items-center justify-center overflow-hidden px-4 select-none">
      {/* Background ambient radial cheese glow */}
      <div className="absolute w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-orange-600/15 via-amber-500/15 to-yellow-400/10 blur-[130px] pointer-events-none animate-pulse" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,170,0,0.06)_1px,transparent_1px)] bg-[size:28px_28px] pointer-events-none" />

      {/* Skip button */}
      <button
        onClick={onComplete}
        className="absolute top-6 right-6 z-50 flex items-center gap-2 px-4 py-2 rounded-full text-xs font-mono text-amber-300/80 bg-stone-900/80 border border-amber-500/30 hover:border-amber-400 hover:text-amber-200 hover:bg-stone-800 transition-all backdrop-blur-md cursor-pointer group shadow-lg shadow-orange-950/40"
      >
        <span>Skip Intro</span>
        <FastForward className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform text-amber-400" />
      </button>

      {/* Main cinematic text container */}
      <div className="relative z-10 w-full max-w-4xl text-center flex flex-col items-center justify-center min-h-[300px]">
        <AnimatePresence mode="wait">
          {phase === 0 && (
            <motion.div
              key="intro-1"
              initial={{ opacity: 0, scale: 0.94, filter: 'blur(8px)' }}
              animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
              exit={{ opacity: 0, scale: 1.04, filter: 'blur(8px)' }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="font-mono-code font-bold text-3xl sm:text-5xl md:text-6xl text-[#ffea00] tracking-wider leading-tight drop-shadow-[0_0_25px_rgba(255,234,0,0.85)]"
            >
              U were bored
            </motion.div>
          )}

          {phase === 1 && (
            <motion.div
              key="intro-2"
              initial={{ opacity: 0, scale: 0.94, filter: 'blur(8px)' }}
              animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
              exit={{ opacity: 0, scale: 1.04, filter: 'blur(8px)' }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="font-mono-code font-bold text-3xl sm:text-5xl md:text-6xl text-[#ffea00] tracking-wider leading-tight drop-shadow-[0_0_25px_rgba(255,234,0,0.85)]"
            >
              In the middle of class
            </motion.div>
          )}

          {phase === 2 && (
            <motion.div
              key="intro-3"
              initial={{ opacity: 0, scale: 0.94, filter: 'blur(8px)' }}
              animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
              exit={{ opacity: 0, scale: 1.04, filter: 'blur(8px)' }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="font-mono-code font-bold text-3xl sm:text-5xl md:text-6xl text-[#ffea00] tracking-wider leading-tight drop-shadow-[0_0_25px_rgba(255,234,0,0.85)]"
            >
              So you switched Tabs to...
            </motion.div>
          )}

          {phase === 3 && (
            <motion.div
              key="intro-brand"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col items-center gap-4"
            >
              {/* Bold Yellow CHEESE - No V2 as requested */}
              <div className="relative inline-flex items-center justify-center text-center">
                <span className="font-orbitron font-black text-5xl sm:text-7xl md:text-8xl lg:text-9xl tracking-[0.18em] sm:tracking-[0.24em] md:tracking-[0.28em] text-[#ffe600] drop-shadow-[0_0_40px_rgba(255,230,0,0.95)] uppercase inline-block">
                  CHEESE
                </span>
              </div>

              {/* We like it drippy */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.8 }}
                className="font-orbitron font-black text-2xl sm:text-3xl md:text-4xl tracking-widest uppercase text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-orange-500 drop-shadow-[0_4px_12px_rgba(245,158,11,0.6)]"
              >
                We like it drippy
              </motion.div>

              {/* Creators credit */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8, duration: 0.6 }}
                className="font-mono-code text-xs sm:text-sm text-orange-400/90 tracking-widest uppercase mt-4"
              >
                From the creators of Cheese
              </motion.div>

              {/* Enter Button */}
              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.1, duration: 0.5 }}
                onClick={onComplete}
                className="mt-8 px-8 py-3.5 rounded-xl font-orbitron font-bold text-sm tracking-widest uppercase bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-400 text-stone-950 hover:brightness-110 shadow-[0_0_30px_rgba(255,170,0,0.6)] hover:shadow-[0_0_45px_rgba(255,190,0,0.85)] hover:scale-105 active:scale-95 transition-all cursor-pointer flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-stone-950" />
                <span>ENTER CHEESE</span>
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Progress dots at bottom */}
      <div className="absolute bottom-10 flex items-center gap-2.5 z-20">
        {[0, 1, 2, 3].map((idx) => (
          <div
            key={idx}
            className={`h-1.5 rounded-full transition-all duration-500 ${
              phase === idx
                ? 'w-8 bg-amber-400 shadow-[0_0_10px_#f59e0b]'
                : phase > idx
                ? 'w-2 bg-amber-600/60'
                : 'w-2 bg-stone-800'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
