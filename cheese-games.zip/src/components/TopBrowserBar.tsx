import React from 'react';
import { BrowserTab } from '../types';
import { Plus, X, ArrowLeft, ArrowRight, RefreshCw, Search } from 'lucide-react';

interface TopBrowserBarProps {
  tabs: BrowserTab[];
  activeTabId: string;
  onSelectTab: (id: string) => void;
  onCloseTab: (id: string, e: React.MouseEvent) => void;
  onNewTab: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSearchSubmit?: (q: string) => void;
}

export const TopBrowserBar: React.FC<TopBrowserBarProps> = ({
  tabs,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onNewTab,
  searchQuery,
  onSearchChange,
  onSearchSubmit
}) => {
  return (
    <div className="w-full bg-[#08080b] border-b-2 border-yellow-500/40 select-none sticky top-0 z-40">
      {/* 1. Tabs Row (above search bar) - NO title parts for each tab, default cheese emoji */}
      <div className="flex items-center px-2 pt-2 gap-1 overflow-x-auto scrollbar-none border-b border-stone-800">
        <div className="flex items-center gap-1.5 flex-1 min-w-0">
          {tabs.map((tab) => {
            const isActive = tab.id === activeTabId;
            return (
              <div
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                title={tab.title}
                className={`group relative flex items-center justify-center gap-1.5 px-3 py-2 rounded-t-lg transition-all cursor-pointer shrink-0 border-t-2 border-x-2 ${
                  isActive
                    ? 'bg-stone-900 border-yellow-400 text-yellow-300 font-bold shadow'
                    : 'bg-black border-transparent text-stone-400 hover:bg-stone-900 hover:text-stone-200'
                }`}
              >
                {/* Tab icon: site favicon or cheese emoji */}
                {tab.favicon && !tab.favicon.includes('data:image/svg+xml') ? (
                  <img
                    src={tab.favicon}
                    alt=""
                    className="w-4 h-4 rounded shrink-0 object-contain"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <span className="text-base leading-none shrink-0" role="img" aria-label="cheese">
                    🧀
                  </span>
                )}

                {/* Tab title dynamically changes based on what the user looked up */}
                <span className="text-xs font-mono font-medium text-stone-200 truncate max-w-[140px]">
                  {tab.title || 'Home'}
                </span>

                {tabs.length > 1 && (
                  <button
                    onClick={(e) => onCloseTab(tab.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-0.5 ml-1 rounded hover:bg-red-600 hover:text-white transition-opacity text-stone-400 cursor-pointer"
                    title="Close tab"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}

          <button
            onClick={onNewTab}
            className="p-1.5 rounded hover:bg-stone-800 text-stone-400 hover:text-yellow-400 transition-colors cursor-pointer shrink-0"
            title="New tab (Cheese 🧀)"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Large Search / URL Bar (Under tabs) */}
      <div className="px-3 sm:px-6 py-2.5 flex items-center gap-3">
        <div className="flex items-center gap-1 text-stone-400 shrink-0">
          <button
            onClick={() => window.history.back()}
            className="p-1.5 rounded hover:bg-stone-800 hover:text-white cursor-pointer"
            title="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => window.history.forward()}
            className="p-1.5 rounded hover:bg-stone-800 hover:text-white cursor-pointer"
            title="Forward"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => window.location.reload()}
            className="p-1.5 rounded hover:bg-stone-800 hover:text-white cursor-pointer"
            title="Reload"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (onSearchSubmit) onSearchSubmit(searchQuery);
          }}
          className="flex-1 relative flex items-center"
        >
          <Search className="absolute left-3.5 w-4 h-4 text-yellow-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search DuckDuckGo, games, or enter URL..."
            className="w-full pl-10 pr-24 py-2 rounded-lg bg-black border border-stone-700 text-white placeholder-stone-500 text-xs sm:text-sm font-mono focus:outline-none focus:border-yellow-400"
          />
          <div className="absolute right-2 flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="p-1.5 rounded hover:bg-stone-800 hover:text-yellow-400 text-stone-400 transition-colors cursor-pointer"
              title="Reload Website"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="text-stone-400 hover:text-white text-xs font-mono px-1.5 py-0.5 rounded hover:bg-stone-800 cursor-pointer"
              >
                Clear
              </button>
            )}
            <button
              type="submit"
              className="px-2.5 py-1 rounded bg-yellow-400 hover:bg-yellow-300 text-black font-bold text-xs font-mono transition-colors cursor-pointer flex items-center gap-1"
              title="Search DuckDuckGo via Scramjet Proxy"
            >
              <Search className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Search</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
