import React, { useState, useEffect, useRef } from 'react';
import {
  encodeProxyUrl,
  formatSearchOrUrl,
  initProxy
} from '../utils/scramjetProxy';

interface ProxyBrowserViewProps {
  initialUrl?: string;
  onClose?: () => void;
  onNavigate?: (url: string) => void;
}

export const ProxyBrowserView: React.FC<ProxyBrowserViewProps> = ({
  initialUrl = 'https://duckduckgo.com/?kae=d',
  onNavigate
}) => {
  const [currentUrl, setCurrentUrl] = useState<string>(() => formatSearchOrUrl(initialUrl));
  const [proxyIframeSrc, setProxyIframeSrc] = useState<string>(() =>
    encodeProxyUrl(formatSearchOrUrl(initialUrl))
  );
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [, setIsProxyReadyState] = useState<boolean>(false);

  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Keep a stable ref to onNavigate
  const onNavigateRef = useRef(onNavigate);
  onNavigateRef.current = onNavigate;

  // Initialize Scramjet & Epoxy once on mount
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const ready = await initProxy();
        if (mounted) {
          setIsProxyReadyState(ready);
        }
      } catch (err) {
        console.warn('Proxy init note:', err);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  // Sync when initialUrl prop updates from TopBrowserBar search
  useEffect(() => {
    if (!initialUrl) return;
    const formatted = formatSearchOrUrl(initialUrl);
    setCurrentUrl((prev) => {
      if (prev !== formatted) {
        setProxyIframeSrc(encodeProxyUrl(formatted));
        setIsLoading(true);
        return formatted;
      }
      return prev;
    });
  }, [initialUrl]);

  return (
    <div
      ref={containerRef}
      className="w-full flex-1 flex flex-col bg-[#070608] h-full min-h-0 relative"
    >
      {/* Loading progress bar */}
      {isLoading && (
        <div className="absolute top-0 left-0 right-0 h-1 bg-yellow-400/20 overflow-hidden z-20">
          <div className="h-full bg-yellow-400 animate-pulse w-full shadow-[0_0_8px_rgba(255,234,0,0.8)]" />
        </div>
      )}

      {/* Main Full-Tab Iframe Webview - Takes up 100% of the viewport under the top browser bar */}
      <div className="flex-1 w-full relative bg-black flex flex-col min-h-0">
        <iframe
          ref={iframeRef}
          src={proxyIframeSrc}
          title="Proxy Webview"
          className="w-full flex-1 border-0 bg-white min-h-[calc(100vh-80px)]"
          onLoad={() => setIsLoading(false)}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        />
      </div>
    </div>
  );
};
