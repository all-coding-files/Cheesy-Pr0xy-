import React, { useState, useRef } from 'react';
import { Film, Maximize2, Minimize2, ExternalLink, RefreshCw } from 'lucide-react';

export const MoviesView: React.FC = () => {
  const [reloadKey, setReloadKey] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Load directly via iframe without proxy as requested
  const directMovieUrl = 'https://triplethd.sarkargroup.asia/';

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current
        .requestFullscreen()
        .then(() => setIsFullscreen(true))
        .catch(() => {});
    } else {
      document
        .exitFullscreen()
        .then(() => setIsFullscreen(false))
        .catch(() => {});
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 py-6 animate-fadeIn select-none">
      {/* Header with Title and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-red-950/80 border border-red-500/40 text-yellow-400 text-xs font-mono mb-1">
            <Film className="w-3.5 h-3.5" />
            <span>CINEMA STREAM</span>
          </div>
          <h2 className="font-orbitron font-black text-2xl sm:text-3xl text-white tracking-wider">
            MOVIES &amp; <span className="text-yellow-400">STREAMING</span>
          </h2>
          <p className="text-xs font-mono text-stone-400 mt-1">
            Direct Cinema Player
          </p>
        </div>

        {/* Action Controls: Reload, Fullscreen, Popout */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setReloadKey((k) => k + 1)}
            className="p-2.5 rounded-xl bg-stone-900 border border-stone-800 hover:border-yellow-400 text-stone-300 hover:text-white transition-colors cursor-pointer"
            title="Reload Stream"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={toggleFullscreen}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs sm:text-sm font-mono shadow-[0_0_15px_rgba(255,234,0,0.5)] transition-all cursor-pointer hover:scale-105 active:scale-95"
            title="Toggle Movie Fullscreen"
          >
            {isFullscreen ? (
              <>
                <Minimize2 className="w-4 h-4" />
                <span>EXIT FULLSCREEN</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-4 h-4" />
                <span>FULLSCREEN MOVIE</span>
              </>
            )}
          </button>

          <a
            href={directMovieUrl}
            target="_blank"
            rel="noreferrer"
            className="p-2.5 rounded-xl bg-stone-900 border border-stone-800 hover:border-yellow-400 text-stone-400 hover:text-white transition-colors cursor-pointer"
            title="Open in new window"
          >
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* Cinema Player Container */}
      <div
        ref={containerRef}
        className="rounded-2xl bg-black border-2 border-yellow-400/80 overflow-hidden shadow-2xl h-[780px] relative flex flex-col"
      >
        <iframe
          key={reloadKey}
          src={directMovieUrl}
          title="Cinema Stream"
          className="w-full flex-1 border-none bg-black"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
          allowFullScreen
        />
      </div>
    </div>
  );
};
