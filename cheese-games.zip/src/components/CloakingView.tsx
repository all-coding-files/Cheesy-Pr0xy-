import React, { useState } from 'react';
import { CLOAK_PRESETS, CloakPreset } from '../data/cloakPresets';
import { Shield, Globe, ExternalLink, Check, RotateCcw, AlertTriangle, Key } from 'lucide-react';
import { PanicSettings } from '../types';

interface CloakingViewProps {
  currentTitle: string;
  currentFavicon: string;
  onApplyCloak: (title: string, faviconUrl: string) => void;
  onResetCloak: () => void;
  panicSettings: PanicSettings;
  onUpdatePanicSettings: (settings: PanicSettings) => void;
}

export const CloakingView: React.FC<CloakingViewProps> = ({
  currentTitle,
  currentFavicon,
  onApplyCloak,
  onResetCloak,
  panicSettings,
  onUpdatePanicSettings
}) => {
  const [customUrl, setCustomUrl] = useState('');
  const [customTitle, setCustomTitle] = useState('');
  const [copiedNotification, setCopiedNotification] = useState<string | null>(null);

  // Panic configuration states
  const [isRecordingKey, setIsRecordingKey] = useState(false);
  const [panicUrlInput, setPanicUrlInput] = useState(panicSettings.url);

  const startRecordingKey = () => {
    setIsRecordingKey(true);
    const handler = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      const newKey = e.key;
      const newCode = e.code;
      onUpdatePanicSettings({
        ...panicSettings,
        key: newKey,
        code: newCode
      });
      setIsRecordingKey(false);
      setCopiedNotification(`Panic key set to: ${newKey.toUpperCase()}`);
      setTimeout(() => setCopiedNotification(null), 3000);
      window.removeEventListener('keydown', handler, true);
    };
    window.addEventListener('keydown', handler, true);
  };

  const handleSavePanicUrl = (e: React.FormEvent) => {
    e.preventDefault();
    let url = panicUrlInput.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    onUpdatePanicSettings({
      ...panicSettings,
      url
    });
    setCopiedNotification(`Panic redirect URL saved: ${url}`);
    setTimeout(() => setCopiedNotification(null), 3000);
  };

  const handleApplyPreset = (preset: CloakPreset) => {
    onApplyCloak(preset.title, preset.faviconUrl);
    setCopiedNotification(`Tab disguised as ${preset.name}!`);
    setTimeout(() => setCopiedNotification(null), 3000);
  };

  const handleLoadRealSite = (preset: CloakPreset, e: React.MouseEvent) => {
    e.stopPropagation();
    window.open(preset.realSiteUrl, '_blank');
  };

  const handleApplyCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customUrl.trim()) return;

    let domain = customUrl.trim();
    try {
      if (!domain.startsWith('http')) domain = 'https://' + domain;
      const parsed = new URL(domain);
      domain = parsed.hostname;
    } catch {
      domain = customUrl.replace(/^https?:\/\//, '').split('/')[0];
    }

    const generatedFavicon = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
    const titleToUse = customTitle.trim() || 'Home';

    onApplyCloak(titleToUse, generatedFavicon);
    setCopiedNotification(`Tab disguised with custom URL: ${domain}`);
    setTimeout(() => setCopiedNotification(null), 3000);
  };

  const openAboutBlankStealth = () => {
    const win = window.open('about:blank', '_blank');
    if (!win) {
      alert('Popup blocked. Please allow popups.');
      return;
    }
    const doc = win.document;
    doc.title = currentTitle || 'Google';

    const link = doc.createElement('link');
    link.rel = 'icon';
    link.href = currentFavicon;
    doc.head.appendChild(link);

    const iframe = doc.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.top = '0';
    iframe.style.left = '0';
    iframe.style.width = '100vw';
    iframe.style.height = '100vh';
    iframe.style.border = 'none';
    iframe.style.margin = '0';
    iframe.src = window.location.href;

    doc.body.style.margin = '0';
    doc.body.appendChild(iframe);
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Title */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-red-950 border border-red-500/50 text-yellow-400 text-xs font-mono mb-2">
          <Shield className="w-3.5 h-3.5" />
          <span>STEALTH TAB CLOAKER</span>
        </div>
        <h2 className="font-orbitron font-black text-3xl sm:text-4xl text-white tracking-wider">
          TAB <span className="text-yellow-400">CLOAKING</span>
        </h2>
        <p className="text-stone-400 text-sm max-w-xl mx-auto mt-2 font-mono">
          Pick your cover: Google, Wikipedia, or YouTube. The default cloak buttons take up the whole space.
        </p>
      </div>

      {/* Live Tab Preview Box */}
      <div className="mb-8 p-4 bg-stone-950 border-2 border-yellow-500/40 rounded-xl">
        <div className="flex items-center justify-between mb-3 text-xs font-mono">
          <span className="text-yellow-400 font-bold">LIVE TAB PREVIEW:</span>
          <button
            onClick={onResetCloak}
            className="flex items-center gap-1 text-stone-400 hover:text-white transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Cheesy Games</span>
          </button>
        </div>

        <div className="bg-[#1b1a20] p-3 rounded-lg border border-stone-800 flex items-center gap-2">
          <div className="flex items-center gap-2 px-3.5 py-1.5 bg-[#2a2933] rounded border border-stone-700 max-w-md overflow-hidden text-xs text-white">
            <img
              src={currentFavicon}
              alt=""
              className="w-4 h-4 rounded-sm shrink-0 object-contain"
            />
            <span className="truncate font-medium">{currentTitle}</span>
            <span className="text-stone-400 ml-2">✕</span>
          </div>
          <span className="text-xs font-mono text-stone-400 hidden sm:inline">
            ← Look at your actual browser tab at the top of your monitor!
          </span>
        </div>

        {copiedNotification && (
          <div className="mt-3 p-2 bg-emerald-950/80 border border-emerald-500 rounded text-emerald-300 text-xs font-mono flex items-center gap-2 animate-bounce">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{copiedNotification}</span>
          </div>
        )}
      </div>

      {/* 3 PRESETS GRID: Google, Wikipedia, YouTube - TAKES UP THE WHOLE SPACE */}
      <div className="mb-10 w-full">
        <h3 className="font-orbitron font-black text-lg text-yellow-400 mb-3 flex items-center gap-2">
          <span>DEFAULT CLOAK PRESETS</span>
        </h3>

        {/* 3 columns taking up the entire container width */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 w-full">
          {CLOAK_PRESETS.map((preset) => {
            const isActive = currentTitle === preset.title;
            return (
              <div
                key={preset.id}
                onClick={() => handleApplyPreset(preset)}
                className={`flex flex-col items-center justify-between p-6 rounded-2xl border-2 transition-all cursor-pointer group relative w-full ${
                  isActive
                    ? 'bg-stone-900 border-yellow-400 shadow-[0_0_30px_rgba(234,179,8,0.5)] scale-102'
                    : 'bg-black border-stone-800 hover:border-yellow-400/80 hover:bg-stone-950 hover:-translate-y-1'
                }`}
              >
                {/* Authentic Favicon Display */}
                <div className="w-20 h-20 rounded-2xl bg-stone-900 border border-stone-700 flex items-center justify-center p-3.5 mb-4 group-hover:scale-110 transition-transform shadow-inner">
                  <img
                    src={preset.faviconUrl}
                    alt={preset.name}
                    className="w-full h-full object-contain"
                  />
                </div>

                <span className="font-orbitron font-black text-xl text-white text-center leading-tight mb-1">
                  {preset.name}
                </span>

                <span className="text-xs text-stone-400 font-mono text-center truncate w-full mb-5">
                  {new URL(preset.realSiteUrl).hostname}
                </span>

                {/* Actions */}
                <div className="w-full space-y-2">
                  <button
                    onClick={() => handleApplyPreset(preset)}
                    className="w-full py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-mono font-black text-xs uppercase shadow cursor-pointer transition-colors"
                  >
                    {isActive ? 'ACTIVE CLOAK' : 'DISGUISE TAB'}
                  </button>

                  <button
                    onClick={(e) => handleLoadRealSite(preset, e)}
                    className="w-full py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-mono text-xs uppercase border border-stone-700 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <span>LOAD REAL SITE</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* PANIC KEY CONFIG & CUSTOM CLOAKER */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Panic Key settings */}
        <div className="p-5 bg-black border-2 border-red-500/60 rounded-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-red-500 font-orbitron font-black text-base mb-1">
              <AlertTriangle className="w-4 h-4" />
              <span>CUSTOM PANIC SHORTCUT</span>
            </div>
            <p className="text-stone-400 text-xs font-mono mb-3">
              Press this key anywhere to immediately disguise the tab and redirect.
            </p>

            <div className="text-xl font-mono font-black text-yellow-400 mb-2">
              {isRecordingKey ? 'PRESS ANY KEY NOW...' : `CURRENT: [ ${panicSettings.key.toUpperCase()} ]`}
            </div>
          </div>

          <div className="space-y-2 mt-2">
            <button
              onClick={startRecordingKey}
              className={`w-full py-2.5 rounded font-mono font-bold text-xs uppercase cursor-pointer ${
                isRecordingKey
                  ? 'bg-red-500 text-white animate-pulse'
                  : 'bg-yellow-400 hover:bg-yellow-300 text-black shadow'
              }`}
            >
              {isRecordingKey ? 'RECORDING KEY...' : 'RECORD NEW PANIC KEY'}
            </button>

            <form onSubmit={handleSavePanicUrl} className="flex gap-2">
              <input
                type="text"
                value={panicUrlInput}
                onChange={(e) => setPanicUrlInput(e.target.value)}
                placeholder="https://classroom.google.com"
                className="flex-1 px-3 py-1.5 bg-stone-900 border border-stone-700 text-white font-mono text-xs rounded"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-yellow-400 font-mono font-bold text-xs rounded border border-stone-700 cursor-pointer"
              >
                SAVE URL
              </button>
            </form>
          </div>
        </div>

        {/* Custom URL generator & About:Blank */}
        <div className="p-5 bg-stone-950 border-2 border-stone-800 rounded-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-yellow-400 font-orbitron font-black text-base mb-1">
              <Globe className="w-4 h-4" />
              <span>CUSTOM URL CLOAK &amp; STEALTH</span>
            </div>
            <p className="text-stone-400 text-xs font-mono mb-3">
              Enter any URL to extract its Google favicon, or launch in About:Blank.
            </p>

            <form onSubmit={handleApplyCustom} className="space-y-2 mb-3">
              <input
                type="text"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="e.g. quizlet.com or desmos.com"
                className="w-full px-3 py-1.5 rounded bg-black border border-stone-700 text-white font-mono text-xs"
              />
              <input
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                placeholder="Custom title (optional)"
                className="w-full px-3 py-1.5 rounded bg-black border border-stone-700 text-white font-mono text-xs"
              />
              <button
                type="submit"
                disabled={!customUrl.trim()}
                className="w-full py-2 rounded bg-yellow-400 hover:bg-yellow-300 text-black font-mono font-bold text-xs uppercase disabled:opacity-40 cursor-pointer"
              >
                APPLY CUSTOM CLOAK
              </button>
            </form>
          </div>

          <button
            onClick={openAboutBlankStealth}
            className="w-full py-2.5 rounded bg-red-600 hover:bg-red-500 text-white font-mono font-black text-xs uppercase shadow cursor-pointer flex items-center justify-center gap-2"
          >
            <span>OPEN IN ABOUT:BLANK TAB</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
