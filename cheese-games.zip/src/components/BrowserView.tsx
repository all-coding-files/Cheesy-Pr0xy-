import React, { useState } from 'react';
import { Search, Globe, Shield, RefreshCw, ArrowLeft, ArrowRight, ExternalLink, Lock } from 'lucide-react';

interface BrowserViewProps {
  initialUrl?: string;
}

export const BrowserView: React.FC<BrowserViewProps> = ({ initialUrl = 'https://duckduckgo.com' }) => {
  const [urlInput, setUrlInput] = useState(initialUrl);
  const [activeUrl, setActiveUrl] = useState(initialUrl);

  const circleButtons = [
    {
      id: 'spotify',
      name: 'Spotify',
      bg: 'bg-[#1db954]',
      hoverBorder: 'hover:border-[#1db954]',
      icon: (
        <svg className="w-5 h-5 fill-black" viewBox="0 0 24 24">
          <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.498 17.306c-.218.358-.684.47-1.042.252-2.855-1.745-6.448-2.14-10.68-1.173-.41.092-.816-.164-.908-.574-.092-.41.164-.816.574-.908 4.63-1.057 8.608-.61 11.804 1.343.358.218.47.684.252 1.06zm1.468-3.262c-.275.448-.86.59-1.308.315-3.268-2.008-8.25-2.59-12.115-1.416-.502.152-1.036-.134-1.188-.636-.152-.502.134-1.036.636-1.188 4.414-1.34 9.907-.69 13.66 1.62.448.275.59.86.315 1.31zm.126-3.41c-3.918-2.327-10.378-2.541-14.127-1.402-.6.183-1.24-.158-1.423-.758-.183-.6.158-1.24.758-1.423 4.305-1.307 11.442-1.055 15.937 1.613.54.32.716 1.02.395 1.56-.32.54-1.02.716-1.54.41z"/>
        </svg>
      ),
      url: 'https://open.spotify.com'
    },
    {
      id: 'github',
      name: 'GitHub',
      bg: 'bg-white',
      hoverBorder: 'hover:border-white',
      icon: (
        <svg className="w-5 h-5 fill-black" viewBox="0 0 24 24">
          <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/>
        </svg>
      ),
      url: 'https://github.com'
    },
    {
      id: 'discord',
      name: 'Discord',
      bg: 'bg-[#5865F2]',
      hoverBorder: 'hover:border-[#5865F2]',
      icon: (
        <svg className="w-5 h-5 fill-white" viewBox="0 0 24 24">
          <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
        </svg>
      ),
      url: 'https://discord.com'
    },
    {
      id: 'tiktok',
      name: 'TikTok',
      bg: 'bg-black border border-stone-700',
      hoverBorder: 'hover:border-[#ff0050]',
      icon: (
        <svg className="w-5 h-5 fill-white" viewBox="0 0 24 24">
          <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
        </svg>
      ),
      url: 'https://tiktok.com'
    },
    {
      id: 'youtube',
      name: 'YouTube',
      bg: 'bg-[#ff0000]',
      hoverBorder: 'hover:border-[#ff0000]',
      icon: (
        <svg className="w-5 h-5 fill-white" viewBox="0 0 24 24">
          <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
        </svg>
      ),
      url: 'https://youtube.com'
    }
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let q = urlInput.trim();
    if (!q) return;

    if (!q.includes('.') || q.includes(' ')) {
      setActiveUrl(`https://duckduckgo.com/?q=${encodeURIComponent(q)}`);
    } else {
      if (!q.startsWith('http://') && !q.startsWith('https://')) {
        q = 'https://' + q;
      }
      setActiveUrl(q);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-6 animate-fadeIn">
      {/* Quick Launch Circles */}
      <div className="mb-6 text-center">
        <div className="text-xs font-mono text-yellow-400 font-bold uppercase tracking-widest mb-3">
          QUICK LAUNCH CIRCLES
        </div>
        <div className="flex items-center justify-center gap-4 sm:gap-6 flex-wrap">
          {circleButtons.map((btn) => (
            <div key={btn.id} className="flex flex-col items-center gap-1 group">
              <button
                onClick={() => {
                  setUrlInput(btn.url);
                  setActiveUrl(btn.url);
                }}
                className={`w-12 h-12 rounded-full flex items-center justify-center p-2.5 ${btn.bg} shadow-md cursor-pointer transform hover:scale-110 transition-all border-2 border-transparent ${btn.hoverBorder}`}
              >
                {btn.icon}
              </button>
              <span className="font-mono text-[10px] text-stone-300">
                {btn.name}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Browser Viewport Window */}
      <div className="rounded-xl bg-black border-2 border-yellow-400 overflow-hidden shadow-2xl">
        {/* URL Bar */}
        <div className="p-3 bg-stone-950 border-b border-stone-800 flex items-center gap-2">
          <form onSubmit={handleSearchSubmit} className="flex-1 flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="Enter URL or search..."
              className="w-full px-3 py-1.5 rounded bg-black border border-stone-700 text-white font-mono text-xs focus:outline-none focus:border-yellow-400"
            />
            <button
              type="submit"
              className="px-3 py-1.5 rounded bg-yellow-400 hover:bg-yellow-300 text-black font-mono font-bold text-xs uppercase cursor-pointer"
            >
              GO
            </button>
          </form>

          <button
            onClick={() => window.open(activeUrl, '_blank')}
            className="p-1.5 rounded bg-stone-900 border border-stone-800 text-stone-300 hover:text-white"
            title="Open in new window"
          >
            <ExternalLink className="w-4 h-4" />
          </button>
        </div>

        {/* Viewport Frame */}
        <div className="h-[520px] bg-stone-950 flex flex-col items-center justify-center p-6 text-center">
          <Globe className="w-12 h-12 text-yellow-400 mb-3 animate-spin" style={{ animationDuration: '20s' }} />
          <h3 className="font-orbitron font-black text-xl text-yellow-400 mb-1">
            PROXY BROWSER ACTIVE
          </h3>
          <p className="text-stone-400 text-xs font-mono max-w-md mb-5">
            Target URL: <span className="text-white font-bold">{activeUrl}</span>
          </p>

          <div className="flex items-center gap-3">
            <button
              onClick={() => window.open(activeUrl, '_blank')}
              className="px-5 py-2.5 rounded bg-yellow-400 hover:bg-yellow-300 text-black font-mono font-bold text-xs uppercase cursor-pointer"
            >
              OPEN DIRECT LINK
            </button>

            <button
              onClick={() => {
                const win = window.open('about:blank', '_blank');
                if (win) {
                  win.document.title = 'Google Docs';
                  const iframe = win.document.createElement('iframe');
                  iframe.src = activeUrl;
                  iframe.style.width = '100vw';
                  iframe.style.height = '100vh';
                  iframe.style.border = 'none';
                  win.document.body.style.margin = '0';
                  win.document.body.appendChild(iframe);
                }
              }}
              className="px-5 py-2.5 rounded bg-red-600 hover:bg-red-500 text-white font-mono font-bold text-xs uppercase cursor-pointer"
            >
              LAUNCH IN ABOUT:BLANK
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
