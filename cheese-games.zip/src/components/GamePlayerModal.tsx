import React, { useState, useEffect } from 'react';
import { Game } from '../types';
import { X, Maximize2, Minimize2, RefreshCw, ExternalLink, Loader2 } from 'lucide-react';
import { Game2048, FlappyCheese, NeonSnake } from './BuiltInGames';

interface GamePlayerModalProps {
  game: Game | null;
  onClose: () => void;
  onOpenAboutBlank?: (url: string, title: string) => void;
}

export const GamePlayerModal: React.FC<GamePlayerModalProps> = ({
  game,
  onClose
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [htmlContent, setHtmlContent] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!game) {
      setHtmlContent(null);
      setIsLoading(false);
      return;
    }

    const effectiveUrl =
      game.embedUrl ||
      (game.file
        ? `https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/${encodeURIComponent(
            game.file.includes('.') ? game.file : game.file + '.html'
          )}`
        : null);

    if (!effectiveUrl) {
      setHtmlContent(null);
      setIsLoading(false);
      return;
    }

    // Check if the URL is from jsDelivr, github, or raw HTML file that needs srcDoc execution
    const isCdnOrPlainHtml =
      effectiveUrl.includes('cdn.jsdelivr.net') ||
      effectiveUrl.includes('raw.githubusercontent.com') ||
      effectiveUrl.includes('/UGS-Files/') ||
      effectiveUrl.endsWith('.html');

    if (isCdnOrPlainHtml) {
      setIsLoading(true);
      setHtmlContent(null);

      fetch(effectiveUrl)
        .then((res) => {
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          return res.text();
        })
        .then((text) => {
          let processed = text;
          // Calculate base URL for relative script/asset imports
          const lastSlash = effectiveUrl.lastIndexOf('/');
          const baseUrl = effectiveUrl.substring(0, lastSlash + 1);

          if (!processed.includes('<base ') && !processed.includes('<BASE ')) {
            if (processed.includes('<head>')) {
              processed = processed.replace('<head>', `<head><base href="${baseUrl}">`);
            } else if (processed.includes('<head ')) {
              processed = processed.replace(/<head[^>]*>/, `$&<base href="${baseUrl}">`);
            } else {
              processed = `<base href="${baseUrl}">\n` + processed;
            }
          }

          setHtmlContent(processed);
          setIsLoading(false);
        })
        .catch((err) => {
          console.warn('Could not fetch srcDoc for game, falling back to direct iframe src:', err);
          setHtmlContent(null);
          setIsLoading(false);
        });
    } else {
      setHtmlContent(null);
      setIsLoading(false);
    }
  }, [game, reloadKey]);

  if (!game) return null;

  const handleOpenNewWindow = () => {
    const effectiveUrl =
      game.embedUrl ||
      (game.file
        ? `https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/${encodeURIComponent(
            game.file.includes('.') ? game.file : game.file + '.html'
          )}`
        : null);

    if (!effectiveUrl) return;

    if (htmlContent) {
      const win = window.open('about:blank', '_blank');
      if (win) {
        win.document.open();
        win.document.write(htmlContent);
        win.document.close();
      }
    } else {
      window.open(effectiveUrl, '_blank');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col justify-center items-center p-2 sm:p-4 animate-fadeIn">
      {/* Game Window Container */}
      <div
        className={`w-full bg-[#0a0a0d] border-2 border-yellow-500/70 rounded-2xl shadow-[0_0_40px_rgba(234,179,8,0.4)] flex flex-col overflow-hidden transition-all duration-200 ${
          isFullscreen ? 'fixed inset-0 rounded-none border-none h-screen' : 'max-w-5xl h-[88vh]'
        }`}
      >
        {/* Header */}
        <div className="p-3 sm:p-4 bg-stone-950 border-b-2 border-stone-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-400 animate-ping" />
            <div>
              <h3 className="font-orbitron font-black text-sm sm:text-lg text-yellow-400 tracking-wide">
                {game.title}
              </h3>
            </div>
          </div>

          {/* Action buttons: Popout, Reload, Fullscreen, Close */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleOpenNewWindow}
              className="p-2 rounded-lg bg-stone-900 border border-stone-800 hover:border-yellow-400 text-stone-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-xs font-mono"
              title="Open Game in Stealth Window"
            >
              <ExternalLink className="w-3.5 h-3.5 text-yellow-400" />
              <span className="hidden sm:inline">Popout</span>
            </button>

            <button
              onClick={() => setReloadKey((k) => k + 1)}
              className="p-2 rounded-lg bg-stone-900 border border-stone-800 hover:border-yellow-400 text-stone-300 hover:text-white transition-colors cursor-pointer"
              title="Reload Game"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-lg bg-stone-900 border border-stone-800 hover:border-yellow-400 text-stone-300 hover:text-white transition-colors cursor-pointer"
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-red-950/80 border border-red-500/50 hover:bg-red-900 text-red-200 transition-colors cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Viewport: Directly runs the actual game */}
        <div className="flex-1 relative bg-black flex items-center justify-center overflow-hidden">
          {isLoading && (
            <div className="absolute inset-0 z-20 bg-black/90 flex flex-col items-center justify-center gap-3">
              <Loader2 className="w-8 h-8 text-yellow-400 animate-spin" />
              <p className="font-mono text-sm text-yellow-400">Loading {game.title}...</p>
            </div>
          )}

          {game.type === 'builtin-2048' ? (
            <div className="w-full h-full overflow-y-auto flex items-center justify-center py-4">
              <Game2048 />
            </div>
          ) : game.type === 'builtin-flappy' ? (
            <div className="w-full h-full overflow-y-auto flex items-center justify-center py-4">
              <FlappyCheese />
            </div>
          ) : game.type === 'builtin-snake' ? (
            <div className="w-full h-full overflow-y-auto flex items-center justify-center py-4">
              <NeonSnake />
            </div>
          ) : htmlContent ? (
            <iframe
              key={`srcdoc-${reloadKey}`}
              srcDoc={htmlContent}
              title={game.title}
              className="w-full h-full border-none"
              allow="autoplay; fullscreen; encrypted-media; gamepad; camera; microphone"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
            />
          ) : (
            <iframe
              key={`src-${reloadKey}`}
              src={game.embedUrl}
              title={game.title}
              className="w-full h-full border-none"
              allow="autoplay; fullscreen; encrypted-media; gamepad; camera; microphone"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
            />
          )}
        </div>
      </div>
    </div>
  );
};
