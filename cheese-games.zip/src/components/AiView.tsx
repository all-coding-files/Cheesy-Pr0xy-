import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, User, Copy, Check, RotateCcw, Lightbulb, Loader2, ChevronDown } from 'lucide-react';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  time: string;
}

export interface AiModelOption {
  id: string;
  name: string;
  badge: string;
  desc: string;
}

const AVAILABLE_MODELS: AiModelOption[] = [
  {
    id: 'chatgpt',
    name: 'ChatGPT',
    badge: 'OpenAI 120B',
    desc: 'Deep reasoning, coding, and step-by-step academic explanations'
  },
  {
    id: 'llama',
    name: 'LLaMA',
    badge: 'Meta AI',
    desc: 'Meta open-weights assistant for programming, math, and direct answers'
  },
  {
    id: 'chatgpt-turbo',
    name: 'ChatGPT Turbo',
    badge: 'OpenAI 20B',
    desc: 'Ultra-fast low-latency responses for quick queries and chat'
  },
  {
    id: 'qwen',
    name: 'Qwen',
    badge: 'Alibaba Cloud',
    desc: 'High-accuracy technical problem solver and multilingual assistant'
  }
];

export const AiView: React.FC = () => {
  const [selectedModel, setSelectedModel] = useState<string>(() => {
    return localStorage.getItem('cheesy_ai_model') || 'chatgpt';
  });
  const [showModelMenu, setShowModelMenu] = useState<boolean>(false);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: "Yo! I'm Cheesy AI. What are we working on today? Need homework help, math steps, code explanations, or essays?",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const handleSelectModel = (modelId: string) => {
    setSelectedModel(modelId);
    localStorage.setItem('cheesy_ai_model', modelId);
    setShowModelMenu(false);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const quickPrompts = [
    'Help me solve this math problem step by step',
    'Write a concise summary of the American Civil War',
    'Explain how recursion works with a simple Python example',
    'Best strategies to get high score in Retro Bowl'
  ];

  const handleSend = async (textToSend?: string) => {
    const prompt = (textToSend || input).trim();
    if (!prompt || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: prompt,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput('');
    setIsLoading(true);

    try {
      const apiMessages = [
        {
          role: 'system',
          content:
            'You are Cheesy AI, the unblocked assistant on Cheese. Help students excel with concise, accurate, and easy-to-understand explanations for homework, math steps, essays, coding, science, and game strategies. Keep your responses clear, helpful, and formatted with bullet points or code blocks where appropriate.'
        },
        ...updatedMessages.slice(-10).map((m) => ({
          role: m.sender === 'user' ? 'user' : 'assistant',
          content: m.text
        }))
      ];

      // 1. Send via local proxy backend (/api/groq) to bypass school/network filters blocking api.groq.com
      let res = await fetch('/api/groq', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: selectedModel,
          messages: apiMessages,
          temperature: 0.7,
          max_tokens: 1500
        })
      });

      // 2. Direct client fallback with Groq API key if local proxy route was unreachable
      if (!res.ok) {
        const GROQ_API_KEY = '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';
        res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${GROQ_API_KEY}`
          },
          body: JSON.stringify({
            model: selectedModel,
            messages: apiMessages,
            temperature: 0.7,
            max_tokens: 1500
          })
        });
      }

      if (!res.ok) {
        throw new Error(`API error: ${res.status}`);
      }

      const data = await res.json();
      const aiReply =
        data.choices?.[0]?.message?.content ||
        'I could not generate an answer right now. Please try again!';

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: aiReply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error('Cheesy AI request error:', err);
      const fallbackMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: `Here is a quick answer for "${prompt}": Make sure to check the problem carefully and solve step by step. Feel free to rephrase or paste the full equation!`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const currentModelObj =
    AVAILABLE_MODELS.find((m) => m.id === selectedModel) || AVAILABLE_MODELS[0];
  const currentModelName = currentModelObj.name;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Title */}
      <div className="text-center mb-6">
        <h2 className="font-orbitron font-black text-3xl sm:text-4xl text-white tracking-wider">
          CHEESY <span className="text-yellow-400">AI</span>
        </h2>
      </div>

      {/* Chat Container */}
      <div className="rounded-2xl bg-black border-2 border-yellow-400 overflow-hidden shadow-[0_0_30px_rgba(234,179,8,0.25)] flex flex-col h-[600px] relative">
        {/* Chat Header with Model Selector */}
        <div className="p-3 bg-stone-950 border-b-2 border-stone-800 flex items-center justify-between text-xs font-mono text-stone-300 relative z-30">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-bold text-yellow-400">CHEESY AI</span>

            {/* Model Selector Dropdown Button */}
            <div className="relative ml-2">
              <button
                onClick={() => setShowModelMenu(!showModelMenu)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-700 hover:border-yellow-400 text-stone-200 hover:text-yellow-300 transition-colors text-xs font-mono font-bold cursor-pointer"
                title="Change AI Model"
              >
                <span className="text-stone-400 font-normal">Model:</span>
                <span className="text-yellow-400 font-bold">{currentModelName}</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </button>

              {/* Model Selection Menu */}
              {showModelMenu && (
                <div className="absolute top-full left-0 mt-1.5 w-72 bg-[#0d0b10] border-2 border-yellow-400 rounded-xl p-2 shadow-2xl z-50">
                  <div className="text-[10px] uppercase font-bold text-stone-400 px-2 py-1 mb-1 border-b border-stone-800">
                    Select AI Model
                  </div>
                  <div className="space-y-1">
                    {AVAILABLE_MODELS.map((m) => (
                      <button
                        key={m.id}
                        onClick={() => handleSelectModel(m.id)}
                        className={`w-full text-left p-2.5 rounded-lg transition-colors cursor-pointer flex flex-col ${
                          selectedModel === m.id
                            ? 'bg-yellow-400 text-black font-bold'
                            : 'hover:bg-stone-900 text-stone-200'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-xs font-bold">{m.name}</span>
                          <span
                            className={`text-[9px] px-1.5 py-0.5 rounded font-mono ${
                              selectedModel === m.id
                                ? 'bg-black text-yellow-400 font-bold'
                                : 'bg-stone-800 text-stone-400'
                            }`}
                          >
                            {m.badge}
                          </span>
                        </div>
                        <span
                          className={`text-[10px] mt-1 ${
                            selectedModel === m.id ? 'text-black/80 font-normal' : 'text-stone-400'
                          }`}
                        >
                          {m.desc}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          <button
            onClick={() =>
              setMessages([
                {
                  id: 'welcome',
                  sender: 'ai',
                  text: "Chat cleared! What's next on your study checklist?",
                  time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                }
              ])
            }
            className="flex items-center gap-1 text-stone-400 hover:text-white transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex items-start gap-3 ${
                m.sender === 'user' ? 'flex-row-reverse' : 'flex-row'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold ${
                  m.sender === 'user'
                    ? 'bg-yellow-400 text-black shadow'
                    : 'bg-stone-900 text-yellow-400 border border-stone-700 shadow'
                }`}
              >
                {m.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[85%] rounded-xl p-4 text-xs sm:text-sm font-mono leading-relaxed relative group ${
                  m.sender === 'user'
                    ? 'bg-yellow-400 text-black font-semibold'
                    : 'bg-stone-950 border border-stone-800 text-stone-200'
                }`}
              >
                <div className="whitespace-pre-wrap">{m.text}</div>
                <div
                  className={`mt-2 text-[10px] font-mono flex items-center justify-between ${
                    m.sender === 'user' ? 'text-black/70' : 'text-stone-500'
                  }`}
                >
                  <span>{m.time}</span>
                  {m.sender === 'ai' && (
                    <button
                      onClick={() => copyToClipboard(m.text, m.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity hover:text-yellow-400 cursor-pointer ml-3 flex items-center gap-1"
                      title="Copy response"
                    >
                      {copiedId === m.id ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                      <span>{copiedId === m.id ? 'Copied' : 'Copy'}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-stone-900 border border-stone-700 flex items-center justify-center text-xs text-yellow-400">
                <Bot className="w-4 h-4" />
              </div>
              <div className="px-4 py-3 bg-stone-950 border border-stone-800 rounded-xl text-xs font-mono text-yellow-400 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-yellow-400" />
                <span>Cheesy AI is generating response with {currentModelName}...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Prompts Bar */}
        <div className="px-3 py-2 bg-stone-950 border-t border-stone-800 flex items-center gap-2 overflow-x-auto text-[11px] scrollbar-none">
          <Lightbulb className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
          {quickPrompts.map((p, i) => (
            <button
              key={i}
              onClick={() => handleSend(p)}
              className="px-2.5 py-1 rounded bg-stone-900 border border-stone-800 hover:border-yellow-400 text-stone-400 hover:text-yellow-300 transition-colors whitespace-nowrap cursor-pointer shrink-0 font-mono"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-stone-950 border-t border-stone-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask Cheesy AI anything (homework, code, math, essays)..."
              className="flex-1 px-4 py-3 rounded-lg bg-black border border-stone-700 text-white placeholder-stone-500 text-xs sm:text-sm font-mono focus:outline-none focus:border-yellow-400"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="px-5 py-3 rounded-lg bg-yellow-400 hover:bg-yellow-300 text-black font-black disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer flex items-center gap-1.5 font-mono text-xs uppercase"
            >
              <span>SEND</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
