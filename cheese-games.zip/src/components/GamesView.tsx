import React, { useState, useEffect, useMemo } from 'react';
import { Game } from '../types';
import { CURATED_GAMES } from '../data/gamesData';
import { fetchGnMathGames } from '../data/gnMathFetcher';
import { TRUFFLED_GAMES } from '../data/truffledGamesData';
import { UGS_GAMES } from '../data/ugsGamesData';
import { Search, Play, X, Zap, Loader2, ChevronDown, Ruler, Save } from 'lucide-react';

interface GamesViewProps {
  onSelectGame: (game: Game) => void;
}

export const GamesView: React.FC<GamesViewProps> = ({
  onSelectGame
}) => {
  // Independent search bar specifically for the Game Vault
  const [search, setSearch] = useState('');
  const [providerFilter, setProviderFilter] = useState<'all' | 'truffled' | 'gn-math' | 'ugs'>('all');
  const [allGames, setAllGames] = useState<Game[]>([]);
  const [activeLetter, setActiveLetter] = useState<string>('ALL');
  const [isLoading, setIsLoading] = useState(true);
  const [displayLimit, setDisplayLimit] = useState(120);

  // Load all GN-Math + Truffled.lol (using official URLs) + Ultimate Game Stash
  // Tag each game with its provider (gn-math, ugs, truffled)
  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    fetchGnMathGames().then((gnGames) => {
      if (!isMounted) return;

      const seen = new Set<string>();
      const combined: Game[] = [];

      const addGame = (g: Game) => {
        if (!g.title || !g.title.trim()) return;
        const key = g.title.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (!seen.has(key)) {
          seen.add(key);
          combined.push(g);
        }
      };

      // 1. GN-Math verified games first (tagged with gn-math, Ruler icon) - correctly claims -3, -b, and all Baldi/original mods
      gnGames.forEach((g) => addGame({ ...g, provider: 'gn-math' }));

      // 2. Curated classics (tagged with ugs or builtin)
      CURATED_GAMES.forEach((g) => addGame({ ...g, provider: g.provider || 'ugs' }));

      // 3. Truffled.lol verified games from truffled.lol/js/json/g.json (tagged with truffled, solid Mushroom icon)
      TRUFFLED_GAMES.forEach((g) => addGame({ ...g, provider: 'truffled' }));

      // 4. Ultimate Game Stash games (tagged with ugs, Floppy Disc icon)
      UGS_GAMES.forEach((g) => addGame({ ...g, provider: 'ugs' }));

      // Alphabetical order A-Z
      combined.sort((a, b) =>
        a.title.localeCompare(b.title, undefined, { sensitivity: 'base', numeric: true })
      );

      setAllGames(combined);
      setIsLoading(false);
    }).catch(() => {
      if (!isMounted) return;
      const combined: Game[] = [];
      CURATED_GAMES.forEach((g) => combined.push({ ...g, provider: 'ugs' }));
      TRUFFLED_GAMES.forEach((g) => combined.push({ ...g, provider: 'truffled' }));
      UGS_GAMES.forEach((g) => combined.push({ ...g, provider: 'ugs' }));
      combined.sort((a, b) => a.title.localeCompare(b.title));
      setAllGames(combined);
      setIsLoading(false);
    });

    return () => {
      isMounted = false;
    };
  }, []);

  const counts = useMemo(() => {
    let truffled = 0;
    let gn = 0;
    let ugs = 0;
    for (const g of allGames) {
      if (g.provider === 'truffled') truffled++;
      else if (g.provider === 'gn-math') gn++;
      else ugs++;
    }
    return { all: allGames.length, truffled, gn, ugs };
  }, [allGames]);

  const alphabet = ['ALL', ...'#ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')];

  const filteredGames = useMemo(() => {
    const query = search.trim().toLowerCase();
    return allGames.filter((game) => {
      if (providerFilter !== 'all' && (game.provider || 'ugs') !== providerFilter) {
        return false;
      }

      const matchesSearch =
        !query || game.title.toLowerCase().includes(query);

      let matchesLetter = true;
      if (activeLetter !== 'ALL') {
        const firstChar = game.title.trim().charAt(0).toUpperCase();
        if (activeLetter === '#') {
          matchesLetter = !isNaN(Number(firstChar));
        } else {
          matchesLetter = firstChar === activeLetter;
        }
      }

      return matchesSearch && matchesLetter;
    });
  }, [allGames, search, activeLetter, providerFilter]);

  // Reset display limit when letter filter, provider or search changes
  useEffect(() => {
    setDisplayLimit(120);
  }, [search, activeLetter, providerFilter]);

  const visibleGames = useMemo(() => {
    return filteredGames.slice(0, displayLimit);
  }, [filteredGames, displayLimit]);

  const handleLoadMore = () => {
    setDisplayLimit((prev) => Math.min(prev + 120, filteredGames.length));
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 py-6 animate-fadeIn">
      {/* Search Bar section inside Games Vault (Separate from Web/Proxy search) */}
      <div className="mb-6 bg-stone-950 border-2 border-yellow-400 rounded-2xl p-4 sm:p-5 shadow-[0_0_25px_rgba(234,179,8,0.25)]">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-yellow-400 text-black font-mono font-black text-xs">
              UNBLOCKED
            </span>
            <h2 className="font-orbitron font-black text-xl sm:text-2xl text-yellow-400 tracking-wider">
              GAMES VAULT
            </h2>
            <span className="text-xs font-mono text-stone-400">
              ({filteredGames.length.toLocaleString()} games A–Z)
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-orange-400">
            {isLoading ? (
              <span className="flex items-center gap-1.5 text-yellow-400">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                LOADING GN-MATH, TRUFFLED &amp; UGS STASH...
              </span>
            ) : (
              <span className="flex items-center gap-1 text-emerald-400">
                <Zap className="w-3.5 h-3.5" />
                {allGames.length.toLocaleString()}+ GAMES LOADED (A–Z)
              </span>
            )}
          </div>
        </div>

        {/* Provider Tabs: ALL, Truffled (Mushroom), GN-Math (Ruler), UGS (Floppy) */}
        <div className="flex items-center gap-2 mb-3 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setProviderFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              providerFilter === 'all'
                ? 'bg-yellow-400 text-black shadow-[0_0_12px_rgba(250,204,21,0.6)]'
                : 'bg-stone-900 border border-stone-800 text-stone-300 hover:border-yellow-400/50'
            }`}
          >
            <span>ALL</span>
            <span className="opacity-70 text-[10px]">({counts.all.toLocaleString()})</span>
          </button>

          <button
            onClick={() => setProviderFilter('truffled')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              providerFilter === 'truffled'
                ? 'bg-red-500 text-white shadow-[0_0_12px_rgba(239,68,68,0.6)]'
                : 'bg-stone-900 border border-stone-800 text-red-300 hover:border-red-400/50'
            }`}
          >
            <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <path d="M12 3c-4.97 0-9 3.58-9 8 0 1.25.32 2.42.88 3.44C4.6 15.7 5.76 16.5 7.1 16.85V20c0 .55.45 1 1 1h7.8c.55 0 1-.45 1-1v-3.15c1.34-.35 2.5-1.15 3.22-2.41.56-1.02.88-2.19.88-3.44 0-4.42-4.03-8-9-8z" />
            </svg>
            <span>TRUFFLED.LOL</span>
            <span className="opacity-70 text-[10px]">({counts.truffled.toLocaleString()})</span>
          </button>

          <button
            onClick={() => setProviderFilter('gn-math')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              providerFilter === 'gn-math'
                ? 'bg-yellow-400 text-black shadow-[0_0_12px_rgba(250,204,21,0.6)]'
                : 'bg-stone-900 border border-stone-800 text-yellow-300 hover:border-yellow-400/50'
            }`}
          >
            <Ruler className="w-3.5 h-3.5" />
            <span>GN-MATH</span>
            <span className="opacity-70 text-[10px]">({counts.gn.toLocaleString()})</span>
          </button>

          <button
            onClick={() => setProviderFilter('ugs')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              providerFilter === 'ugs'
                ? 'bg-cyan-500 text-black shadow-[0_0_12px_rgba(6,182,212,0.6)]'
                : 'bg-stone-900 border border-stone-800 text-cyan-300 hover:border-cyan-400/50'
            }`}
          >
            <Save className="w-3.5 h-3.5" />
            <span>UGS STASH</span>
            <span className="opacity-70 text-[10px]">({counts.ugs.toLocaleString()})</span>
          </button>
        </div>

        {/* Dedicated Independent Games Search Input */}
        <div className="relative flex items-center">
          <Search className="absolute left-4 w-5 h-5 text-yellow-400 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search all 4,000+ games in alphabetical order (1v1.LoL, Slope, Retro Bowl, Cuphead...)"
            className="w-full pl-12 pr-12 py-3.5 rounded-xl bg-black border-2 border-orange-500/60 text-white placeholder-stone-500 font-mono text-sm sm:text-base focus:outline-none focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/40 shadow-inner"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3.5 p-1 rounded bg-stone-800 text-stone-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* A-Z Letter Navigation Bar */}
        <div className="flex items-center gap-1 overflow-x-auto mt-3 pt-2 scrollbar-none text-[11px] font-mono">
          <span className="text-stone-500 font-bold shrink-0 mr-1">INDEX:</span>
          {alphabet.map((letter) => (
            <button
              key={letter}
              onClick={() => setActiveLetter(letter)}
              className={`px-2 py-1 rounded transition-colors shrink-0 cursor-pointer font-bold ${
                activeLetter === letter
                  ? 'bg-yellow-400 text-black shadow-[0_0_10px_#eab308]'
                  : 'text-stone-400 hover:text-yellow-300 hover:bg-stone-800'
              }`}
            >
              {letter}
            </button>
          ))}
        </div>
      </div>

      {/* Games Grid:
          - No games matched shows Cheese 🧀 symbol instead of fire
          - Each card top right shows provider badge:
            - GN-MATH: Ruler symbol
            - UGS: Floppy disc symbol
            - Truffled: Mushroom symbol
      */}
      {filteredGames.length === 0 ? (
        <div className="p-16 text-center bg-black/60 rounded-2xl border-2 border-stone-800 flex flex-col items-center justify-center">
          <span className="text-6xl block mb-4 animate-bounce" role="img" aria-label="cheese">
            🧀
          </span>
          <h3 className="font-orbitron font-bold text-xl text-yellow-400 mb-1">NO GAMES MATCHED</h3>
          <p className="text-stone-400 text-xs font-mono">
            Clear your search term or select another letter in the index.
          </p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {visibleGames.map((game) => {
              const firstLetter = game.title.trim().charAt(0).toUpperCase() || '?';
              const hasThumbnail = Boolean(game.thumbnail && game.thumbnail.trim());

              return (
                <button
                  key={game.id}
                  onClick={() => onSelectGame(game)}
                  className="group relative aspect-[4/5] w-full rounded-xl overflow-hidden border-2 border-stone-800 hover:border-yellow-400 transition-all duration-200 transform hover:-translate-y-1 hover:shadow-[0_8px_25px_rgba(234,179,8,0.4)] cursor-pointer text-left block focus:outline-none bg-stone-950"
                >
                  {/* Provider Symbol & Name Badge on Top Right */}
                  <div className="absolute top-2 right-2 z-20 flex items-center gap-1 px-1.5 py-0.5 rounded bg-black/90 backdrop-blur-md border border-stone-700 group-hover:border-yellow-400 text-[10px] font-mono font-bold shadow-md">
                    {game.provider === 'gn-math' && (
                      <>
                        <Ruler className="w-3 h-3 text-yellow-400 shrink-0" />
                        <span className="text-yellow-300 text-[9px]">GN-MATH</span>
                      </>
                    )}
                    {game.provider === 'truffled' && (
                      <>
                        {/* Clean Solid Mushroom Symbol (No dots, no faces) */}
                        <svg className="w-3 h-3 text-red-400 shrink-0 fill-current" viewBox="0 0 24 24">
                          <path d="M12 3c-4.97 0-9 3.58-9 8 0 1.25.32 2.42.88 3.44C4.6 15.7 5.76 16.5 7.1 16.85V20c0 .55.45 1 1 1h7.8c.55 0 1-.45 1-1v-3.15c1.34-.35 2.5-1.15 3.22-2.41.56-1.02.88-2.19.88-3.44 0-4.42-4.03-8-9-8z" />
                        </svg>
                        <span className="text-red-300 text-[9px]">TRUFFLED</span>
                      </>
                    )}
                    {(!game.provider || game.provider === 'ugs') && (
                      <>
                        {/* Floppy Disc Symbol */}
                        <Save className="w-3 h-3 text-cyan-400 shrink-0" />
                        <span className="text-cyan-300 text-[9px]">UGS</span>
                      </>
                    )}
                  </div>

                  {/* For games with NO thumbnail: Make the first letter of their game name prominent */}
                  {!hasThumbnail ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-stone-900 via-stone-950 to-black p-3 text-center">
                      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-black/90 border-2 border-yellow-400 flex items-center justify-center shadow-[0_0_20px_rgba(250,204,21,0.35)] group-hover:scale-110 group-hover:border-yellow-300 group-hover:shadow-[0_0_30px_rgba(250,204,21,0.6)] transition-all">
                        <span className="font-orbitron font-black text-3xl sm:text-4xl text-yellow-400 select-none">
                          {firstLetter}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <>
                      {/* Stylized background fallback if image fails */}
                      <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-stone-900 via-stone-950 to-black">
                        <span className="font-orbitron font-black text-5xl text-yellow-500/20 select-none">
                          {firstLetter}
                        </span>
                      </div>

                      {/* Game Image */}
                      <img
                        src={game.thumbnail}
                        alt={game.title}
                        className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                        loading="lazy"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />

                      {/* Corner badge showing first letter of the game */}
                      <div className="absolute top-2 left-2 z-10 w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-black/90 border border-yellow-400 flex items-center justify-center shadow-[0_0_10px_rgba(250,204,21,0.6)] backdrop-blur-sm">
                        <span className="font-orbitron font-black text-xs sm:text-sm text-yellow-400">
                          {firstLetter}
                        </span>
                      </div>
                    </>
                  )}

                  {/* Dark gradient overlay for title legibility */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent group-hover:via-black/20 transition-colors pointer-events-none" />

                  {/* Play Hover Icon */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none">
                    <div className="w-11 h-11 rounded-full bg-yellow-400 text-black flex items-center justify-center shadow-[0_0_20px_#facc15]">
                      <Play className="w-5 h-5 fill-black translate-x-0.5" />
                    </div>
                  </div>

                  {/* Name at the bottom of the button as requested */}
                  <div className="absolute bottom-0 inset-x-0 p-2.5 z-10 bg-gradient-to-t from-black via-black/90 to-transparent">
                    <h4 className="font-orbitron font-black text-xs text-white leading-tight truncate group-hover:text-yellow-300 transition-colors">
                      {game.title}
                    </h4>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Load More Button */}
          {displayLimit < filteredGames.length && (
            <div className="flex flex-col items-center justify-center mt-10 gap-2">
              <button
                onClick={handleLoadMore}
                className="px-8 py-3.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-orbitron font-black text-sm uppercase tracking-wider flex items-center gap-2 shadow-[0_0_25px_rgba(250,204,21,0.5)] transition-all cursor-pointer hover:scale-103"
              >
                <span>LOAD MORE GAMES</span>
                <ChevronDown className="w-4 h-4" />
              </button>
              <span className="text-xs font-mono text-stone-400">
                Showing {displayLimit.toLocaleString()} of {filteredGames.length.toLocaleString()} games (A–Z)
              </span>
            </div>
          )}
        </>
      )}
    </div>
  );
};
