import React, { useState } from 'react';
import { ExternalLink, Search, Globe, LayoutGrid, Zap } from 'lucide-react';

interface AppItem {
  id: string;
  name: string;
  url: string;
  domain: string;
  category: string;
  description: string;
}

const APPS_LIST: AppItem[] = [
  {
    id: 'github',
    name: 'GitHub',
    url: 'https://github.com',
    domain: 'github.com',
    category: 'Developer',
    description: 'Code repositories, open-source projects, and developer tools.'
  },
  {
    id: 'youtube',
    name: 'YouTube',
    url: 'https://www.youtube.com',
    domain: 'youtube.com',
    category: 'Streaming & Video',
    description: 'Watch videos, game streams, music, and tutorials unblocked.'
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    url: 'https://www.tiktok.com',
    domain: 'tiktok.com',
    category: 'Social',
    description: 'Trending short videos, entertainment, and comedy streams.'
  },
  {
    id: 'spotify',
    name: 'Spotify',
    url: 'https://open.spotify.com',
    domain: 'spotify.com',
    category: 'Music',
    description: 'Stream music, playlists, and podcasts in class without restrictions.'
  },
  {
    id: 'snapchat',
    name: 'Snapchat',
    url: 'https://web.snapchat.com',
    domain: 'snapchat.com',
    category: 'Messaging',
    description: 'Web messaging, chat with friends, and lenses.'
  },
  {
    id: 'discord',
    name: 'Discord',
    url: 'https://discord.com/app',
    domain: 'discord.com',
    category: 'Community & Chat',
    description: 'Voice, text servers, gaming communities, and DMs.'
  },
  {
    id: 'nvidia',
    name: 'NVIDIA',
    url: 'https://play.geforcenow.com',
    domain: 'geforcenow.com',
    category: 'Cloud Gaming',
    description: 'GeForce NOW cloud gaming rig on any Chromebook or browser.'
  },
  {
    id: 'poki',
    name: 'Poki',
    url: 'https://poki.com',
    domain: 'poki.com',
    category: 'Gaming',
    description: 'Instant web games, multiplayer battles, and casual arcade hits.'
  },
  {
    id: 'crazygames',
    name: 'CrazyGames',
    url: 'https://www.crazygames.com',
    domain: 'crazygames.com',
    category: 'Gaming',
    description: 'Thousands of free online games across all popular genres.'
  },
  {
    id: 'paramount',
    name: 'Paramount',
    url: 'https://www.paramountplus.com',
    domain: 'paramountplus.com',
    category: 'Entertainment',
    description: 'Movies, sports, CBS shows, and live TV.'
  },
  {
    id: 'netflix',
    name: 'Netflix',
    url: 'https://www.netflix.com',
    domain: 'netflix.com',
    category: 'Entertainment',
    description: 'Stream world-famous movies, anime, documentaries, and TV series.'
  },
  {
    id: 'instagram',
    name: 'Instagram',
    url: 'https://www.instagram.com',
    domain: 'instagram.com',
    category: 'Social',
    description: 'Feeds, stories, reels, and messaging with friends.'
  }
];

interface AppsViewProps {
  onOpenApp: (url: string, name: string, favicon: string) => void;
}

export const AppsView: React.FC<AppsViewProps> = ({ onOpenApp }) => {
  const [search, setSearch] = useState('');

  const filteredApps = APPS_LIST.filter((app) =>
    app.name.toLowerCase().includes(search.toLowerCase()) ||
    app.category.toLowerCase().includes(search.toLowerCase()) ||
    app.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 animate-fadeIn select-none">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-yellow-950/60 border border-yellow-500/40 text-yellow-400 text-xs font-mono mb-2">
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>UNBLOCKED APPS PORTAL</span>
          </div>
          <h2 className="font-orbitron font-black text-2xl sm:text-4xl text-white tracking-wider">
            WEB <span className="text-yellow-400">APPS</span>
          </h2>
          <p className="text-xs sm:text-sm font-mono text-stone-400 mt-1">
            Fast one-click launch powered by Scramjet v2 proxy routing
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search web apps..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black border border-stone-800 focus:border-yellow-400 text-white placeholder-stone-500 text-xs font-mono focus:outline-none transition-all shadow-inner"
          />
        </div>
      </div>

      {/* Grid of Apps */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredApps.map((app) => {
          const faviconUrl = `https://www.google.com/s2/favicons?domain=${app.domain}&sz=128`;
          return (
            <div
              key={app.id}
              onClick={() => onOpenApp(app.url, app.name, faviconUrl)}
              className="group relative bg-[#0d0b10] border-2 border-stone-800 hover:border-yellow-400 rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_0_30px_rgba(255,234,0,0.25)] cursor-pointer overflow-hidden"
            >
              {/* Subtle Ambient Hover Glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/0 via-transparent to-orange-500/0 group-hover:from-yellow-500/10 group-hover:to-orange-500/5 transition-all pointer-events-none" />

              <div>
                <div className="flex items-center justify-between mb-4">
                  {/* App Favicon */}
                  <div className="w-14 h-14 rounded-2xl bg-black border border-stone-700 group-hover:border-yellow-400 p-2.5 flex items-center justify-center transition-all group-hover:scale-105 shadow-md">
                    <img
                      src={faviconUrl}
                      alt={app.name}
                      className="w-9 h-9 object-contain rounded-md"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>

                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-stone-900 border border-stone-800 text-stone-400 group-hover:text-yellow-400 group-hover:border-yellow-400/50 transition-colors uppercase tracking-wider">
                    {app.category}
                  </span>
                </div>

                <h3 className="font-orbitron font-black text-lg text-white group-hover:text-yellow-400 transition-colors mb-3 flex items-center gap-1.5">
                  <span>{app.name}</span>
                </h3>
              </div>

              {/* Launch Button */}
              <button
                type="button"
                className="w-full py-2.5 px-3 rounded-xl bg-stone-900 group-hover:bg-yellow-400 text-stone-300 group-hover:text-black font-mono font-bold text-xs flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-yellow-400 group-hover:text-black fill-current" />
                <span>Launch in Proxy</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
