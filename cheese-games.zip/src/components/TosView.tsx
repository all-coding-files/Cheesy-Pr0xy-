import React from 'react';
import { ScrollText, ShieldAlert, CheckCircle2 } from 'lucide-react';

export const TosView: React.FC = () => {
  const terms = [
    "We are not responsible for any trouble you get in using this site.",
    "You will not rat us out to any teachers.",
    "You understand we have the right to rat you out at any time.",
    "You understand that we do not need to remove any content that seems \"unfit\" to you.",
    "You will not look up anything that can be seen as inappropriate.",
    "You will respect the creators and owners of Cheese."
  ];

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8 animate-fadeIn select-none">
      <div className="bg-[#0c0a10] border-2 border-yellow-400 rounded-3xl p-6 sm:p-10 shadow-[0_0_35px_rgba(255,234,0,0.25)] relative overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute -top-24 -right-24 w-72 h-72 rounded-full bg-yellow-500/10 blur-[80px] pointer-events-none" />

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-2xl bg-yellow-400/10 border border-yellow-400/30 text-yellow-400">
            <ScrollText className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-mono text-yellow-400 font-bold uppercase tracking-widest">
              OFFICIAL POLICY
            </span>
            <h1 className="font-orbitron font-black text-2xl sm:text-4xl text-white tracking-wider">
              TERMS OF <span className="text-yellow-400">SERVICE</span>
            </h1>
          </div>
        </div>

        <p className="font-mono text-sm sm:text-base text-stone-300 leading-relaxed mb-6 border-b border-stone-800 pb-4">
          You understand that using <strong className="text-yellow-400">Cheese</strong> means you understand and agree to the following conditions:
        </p>

        {/* Terms list */}
        <ul className="space-y-4 mb-8">
          {terms.map((term, idx) => (
            <li
              key={idx}
              className="flex items-start gap-3 p-3.5 rounded-xl bg-black border border-stone-800 hover:border-yellow-400/50 transition-colors"
            >
              <CheckCircle2 className="w-5 h-5 text-yellow-400 shrink-0 mt-0.5" />
              <span className="font-mono text-xs sm:text-sm text-stone-200 leading-relaxed">
                {term}
              </span>
            </li>
          ))}
        </ul>

        {/* Notice Footer */}
        <div className="flex items-center gap-3 p-4 rounded-xl bg-yellow-950/40 border border-yellow-500/30 text-yellow-300 text-xs font-mono">
          <ShieldAlert className="w-5 h-5 text-yellow-400 shrink-0" />
          <span>
            By browsing or playing on Cheese, you acknowledge these terms in full. Stay safe and keep it drippy.
          </span>
        </div>
      </div>
    </div>
  );
};
