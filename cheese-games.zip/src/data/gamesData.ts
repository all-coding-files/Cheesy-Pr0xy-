import { Game } from '../types';

export const CURATED_GAMES: Game[] = [
  {
    id: '1v1lol',
    title: '1v1.LoL',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/58.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/58-fix2.html',
    type: 'iframe'
  },
  {
    id: 'bad-parenting-1',
    title: 'Bad Parenting 1',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/650.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/650-fix2.html',
    type: 'iframe'
  },
  {
    id: 'baldis-basics',
    title: "Baldi's Basics Plus",
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/18.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/18-fix2.html',
    type: 'iframe'
  },
  {
    id: 'basket-random',
    title: 'Basket Random',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/45.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/45-fix2.html',
    type: 'iframe'
  },
  {
    id: 'bendy',
    title: 'Bendy and the Ink Machine',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/142.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/142-fix2.html',
    type: 'iframe'
  },
  {
    id: 'bitlife',
    title: 'Bitlife Simulator',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/12.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/12-fix2.html',
    type: 'iframe'
  },
  {
    id: 'bowmasters',
    title: 'Bowmasters',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/0.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/0-fix2.html',
    type: 'iframe'
  },
  {
    id: 'buckshot-roulette',
    title: 'Buckshot Roulette',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/552.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/552-fix2.html',
    type: 'iframe'
  },
  {
    id: 'celeste',
    title: 'Celeste',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/110.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/110-fix2.html',
    type: 'iframe'
  },
  {
    id: 'cookie-clicker',
    title: 'Cookie Clicker',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/25.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/25-fix2.html',
    type: 'iframe'
  },
  {
    id: 'cuphead',
    title: 'Cuphead',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/117.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/117-fix2.html',
    type: 'iframe'
  },
  {
    id: 'drive-mad',
    title: 'Drive Mad',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/15.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/15-fix2.html',
    type: 'iframe'
  },
  {
    id: 'eggy-car',
    title: 'Eggy Car',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/54.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/54-fix2.html',
    type: 'iframe'
  },
  {
    id: 'fnaf',
    title: 'Five Nights at Freddy’s',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/74.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/74-fix2.html',
    type: 'iframe'
  },
  {
    id: 'geometry-dash',
    title: 'Geometry Dash',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/67.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/67-fix2.html',
    type: 'iframe'
  },
  {
    id: 'happy-wheels',
    title: 'Happy Wheels',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/77.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/77-fix2.html',
    type: 'iframe'
  },
  {
    id: 'moto-x3m',
    title: 'Moto X3M',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/27.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/27-fix2.html',
    type: 'iframe'
  },
  {
    id: 'ovo',
    title: 'OvO',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/1.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/1-fix2.html',
    type: 'iframe'
  },
  {
    id: 'paper-io-2',
    title: 'Paper.io 2',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/38.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/38-fix2.html',
    type: 'iframe'
  },
  {
    id: 'retro-bowl',
    title: 'Retro Bowl',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/33.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/33-fix2.html',
    type: 'iframe'
  },
  {
    id: 'run-3',
    title: 'Run 3',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/61.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/61-fix2.html',
    type: 'iframe'
  },
  {
    id: 'slope',
    title: 'Slope 3D',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/198.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/198-fix2.html',
    type: 'iframe'
  },
  {
    id: 'smash-karts',
    title: 'Smash Karts',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/50.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/50-fix2.html',
    type: 'iframe'
  },
  {
    id: 'subway-surfers',
    title: 'Subway Surfers',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/44.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/44-fix2.html',
    type: 'iframe'
  },
  {
    id: 'tiny-fishing',
    title: 'Tiny Fishing',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/36.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/36-fix2.html',
    type: 'iframe'
  },
  {
    id: 'tunnel-rush',
    title: 'Tunnel Rush',
    thumbnail: 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main/35.png',
    embedUrl: 'https://cdn.jsdelivr.net/gh/freebuisness/html@main/35-fix2.html',
    type: 'iframe'
  }
];

// Sort in alphabetical order as requested
CURATED_GAMES.sort((a, b) =>
  a.title.localeCompare(b.title, undefined, { sensitivity: 'base', numeric: true })
);

export function formatUgsTitle(raw: string): string {
  let name = raw;
  if (name.startsWith('cl')) name = name.slice(2);
  name = name.replace(/([a-z])([A-Z0-9])/g, '$1 $2');
  name = name.replace(/([0-9])([A-Za-z])/g, '$1 $2');
  return name.trim();
}
