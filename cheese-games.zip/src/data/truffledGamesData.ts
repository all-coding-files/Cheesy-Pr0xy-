import { Game } from "../types";

export const TRUFFLED_GAMES: Game[] = [
  {
    "id": "truffled-0-1",
    "title": "1",
    "thumbnail": "https://truffled.lol/png/games/1.webp",
    "embedUrl": "https://truffled.lol/games/1/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-1-1-on-1-soccer",
    "title": "1 on 1 Soccer",
    "thumbnail": "https://truffled.lol/png/games/12.webp",
    "embedUrl": "https://truffled.lol/games/1on1soccer/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-2-1v1-lol",
    "title": "1v1.lol",
    "thumbnail": "https://truffled.lol/png/games/1v1.webp",
    "embedUrl": "https://truffled.lol/gamefile/1v1.html",
    "type": "iframe"
  },
  {
    "id": "truffled-3-3",
    "title": "-3",
    "thumbnail": "https://truffled.lol/png/games/minus3.webp",
    "embedUrl": "https://truffled.lol/games/minus3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-4-10-minutes-till-dawn",
    "title": "10 Minutes Till Dawn",
    "thumbnail": "https://truffled.lol/png/games/10.webp",
    "embedUrl": "https://truffled.lol/games/10minutestilldawn/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-5-20-minutes-till-dawn",
    "title": "20 Minutes Till Dawn",
    "thumbnail": "https://truffled.lol/png/games/20mtd.webp",
    "embedUrl": "https://truffled.lol/games/20minutesbog/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-6-30",
    "title": "30",
    "thumbnail": "https://truffled.lol/png/games/30.webp",
    "embedUrl": "https://truffled.lol/games/30dolar/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-7-60-seconds-webport",
    "title": "60 Seconds, Webport",
    "thumbnail": "https://truffled.lol/png/games/60.webp",
    "embedUrl": "https://truffled.lol/games/60/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-8-2048",
    "title": "2048",
    "thumbnail": "https://truffled.lol/png/games/2048.webp",
    "embedUrl": "https://truffled.lol/games/2048/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-9-academytale-webport",
    "title": "Academytale, Webport",
    "thumbnail": "https://truffled.lol/png/games/academytale.webp",
    "embedUrl": "https://truffled.lol/games/academytale/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-10-achievement-unlocked",
    "title": "Achievement Unlocked",
    "thumbnail": "https://truffled.lol/png/games/achieve.webp",
    "embedUrl": "https://truffled.lol/games/achieveunlocked/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-11-achievement-unlocked-2",
    "title": "Achievement Unlocked 2",
    "thumbnail": "https://truffled.lol/png/games/au2.webp",
    "embedUrl": "https://truffled.lol/games/achivement2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-12-achievement-unlocked-3",
    "title": "Achievement Unlocked 3",
    "thumbnail": "https://truffled.lol/png/games/au3.webp",
    "embedUrl": "https://truffled.lol/games/achivement3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-13-a-difficult-game-about-climbing-webport",
    "title": "A Difficult Game About Climbing, Webport",
    "thumbnail": "https://truffled.lol/png/games/adgac.webp",
    "embedUrl": "https://truffled.lol/gamefile/adgac.html",
    "type": "iframe"
  },
  {
    "id": "truffled-14-adofai",
    "title": "ADOFAI",
    "thumbnail": "https://truffled.lol/png/games/adofai.webp",
    "embedUrl": "https://truffled.lol/games/a-dance-of-fire-and-ice/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-15-adventure-capitalist",
    "title": "Adventure Capitalist",
    "thumbnail": "https://truffled.lol/png/games/adventure.webp",
    "embedUrl": "https://truffled.lol/games/adventure/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-16-a-game-about-feeding-a-blackhole",
    "title": "A Game About Feeding A Blackhole",
    "thumbnail": "https://truffled.lol/png/games/blackhole.webp",
    "embedUrl": "https://truffled.lol/gamefile/blackhole.html",
    "type": "iframe"
  },
  {
    "id": "truffled-17-ages-of-conflict-webport",
    "title": "Ages Of Conflict, Webport",
    "thumbnail": "https://truffled.lol/png/games/aoc.webp",
    "embedUrl": "https://truffled.lol/games/agesofconflict/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-18-alien-hominid",
    "title": "Alien Hominid",
    "thumbnail": "https://truffled.lol/png/games/alien.webp",
    "embedUrl": "https://truffled.lol/games/alien/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-19-amanda-the-adventurer-webport",
    "title": "Amanda the adventurer, Webport",
    "thumbnail": "https://truffled.lol/png/games/aman.webp",
    "embedUrl": "https://truffled.lol/games/amanda-the-adventurer/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-20-amaze",
    "title": "Amaze",
    "thumbnail": "https://truffled.lol/png/games/amaze.webp",
    "embedUrl": "https://truffled.lol/games/amaze/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-21-among-us",
    "title": "Among us",
    "thumbnail": "https://truffled.lol/png/games/among.webp",
    "embedUrl": "https://truffled.lol/games/sussy/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-22-angry-birds",
    "title": "Angry Birds",
    "thumbnail": "https://truffled.lol/png/games/angry.webp",
    "embedUrl": "https://truffled.lol/gamefile/Angrybirds.html",
    "type": "iframe"
  },
  {
    "id": "truffled-23-angry-birds-2",
    "title": "Angry Birds 2",
    "thumbnail": "https://truffled.lol/png/games/ab2.webp",
    "embedUrl": "https://truffled.lol/games/angrybirds2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-24-angry-birds-epic-webport",
    "title": "Angry Birds Epic, Webport",
    "thumbnail": "https://truffled.lol/png/games/epic.webp",
    "embedUrl": "https://truffled.lol/games/Epic/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-25-angry-birds-online",
    "title": "Angry Birds Online",
    "thumbnail": "https://truffled.lol/png/games/angrybirdsonline.webp",
    "embedUrl": "https://truffled.lol/gamefile/angrybirdsonline.html",
    "type": "iframe"
  },
  {
    "id": "truffled-26-animal-crossing-population-growing-webport",
    "title": "Animal Crossing Population: Growing!, Webport",
    "thumbnail": "https://truffled.lol/png/games/acpg.webp",
    "embedUrl": "https://truffled.lol/games/slider/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-27-animal-crossing-wild-world",
    "title": "Animal Crossing Wild World",
    "thumbnail": "https://truffled.lol/png/games/acww.webp",
    "embedUrl": "https://truffled.lol/gamefile/acww.html",
    "type": "iframe"
  },
  {
    "id": "truffled-28-antonblast",
    "title": "Antonblast",
    "thumbnail": "https://truffled.lol/png/games/anton.webp",
    "embedUrl": "https://truffled.lol/games/antonblast/runner.html",
    "type": "iframe"
  },
  {
    "id": "truffled-29-antonblast-64-webport",
    "title": "Antonblast 64, Webport",
    "thumbnail": "https://truffled.lol/png/games/an64.webp",
    "embedUrl": "https://truffled.lol/games/antonblast64/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-30-apes-vs-helium-webport",
    "title": "Apes Vs Helium, Webport",
    "thumbnail": "https://truffled.lol/png/games/avh.webp",
    "embedUrl": "https://truffled.lol/games/AVHPort/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-31-apotheon-webport",
    "title": "Apotheon, Webport",
    "thumbnail": "https://truffled.lol/png/games/apotheon.webp",
    "embedUrl": "https://truffled.lol/games/Apotheon/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-32-arthur-s-nightmare-webport",
    "title": "Arthur's Nightmare, Webport",
    "thumbnail": "https://truffled.lol/png/games/arthursnight.webp",
    "embedUrl": "https://truffled.lol/gamefile/arthur.html",
    "type": "iframe"
  },
  {
    "id": "truffled-33-a-small-world-cup",
    "title": "A Small World Cup",
    "thumbnail": "https://truffled.lol/png/games/worldcup.webp",
    "embedUrl": "https://truffled.lol/gamefile/aswc.html",
    "type": "iframe"
  },
  {
    "id": "truffled-34-b",
    "title": "-b",
    "thumbnail": "https://truffled.lol/png/games/qq.webp",
    "embedUrl": "https://truffled.lol/games/minusbog/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-35-bad-icecream-1",
    "title": "Bad Icecream 1",
    "thumbnail": "https://truffled.lol/png/games/badice1.webp",
    "embedUrl": "https://truffled.lol/gamefile/badice1.html",
    "type": "iframe"
  },
  {
    "id": "truffled-36-bad-icecream-2",
    "title": "Bad Icecream 2",
    "thumbnail": "https://truffled.lol/png/games/badice2.webp",
    "embedUrl": "https://truffled.lol/gamefile/badice2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-37-bad-icecream-3",
    "title": "Bad Icecream 3",
    "thumbnail": "https://truffled.lol/png/games/badice3.webp",
    "embedUrl": "https://truffled.lol/gamefile/badice3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-38-bad-parenting-webport",
    "title": "Bad Parenting, Webport",
    "thumbnail": "https://truffled.lol/png/games/bad.webp",
    "embedUrl": "https://truffled.lol/games/bad/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-39-bad-piggies",
    "title": "Bad Piggies",
    "thumbnail": "https://truffled.lol/png/games/badp.webp",
    "embedUrl": "https://truffled.lol/gamefile/piggies.html",
    "type": "iframe"
  },
  {
    "id": "truffled-40-bad-time-simulator",
    "title": "Bad time Simulator",
    "thumbnail": "https://truffled.lol/png/games/badt.webp",
    "embedUrl": "https://truffled.lol/games/bts/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-41-balatro-modded-webport",
    "title": "Balatro Modded, Webport",
    "thumbnail": "https://truffled.lol/png/games/balatromodded.webp",
    "embedUrl": "https://truffled.lol/games/balatromodded/",
    "type": "iframe"
  },
  {
    "id": "truffled-42-balatro-webport",
    "title": "Balatro, Webport",
    "thumbnail": "https://truffled.lol/png/games/bal.webp",
    "embedUrl": "https://truffled.lol/games/balatro/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-43-baldi-s-basics",
    "title": "Baldi's Basics",
    "thumbnail": "https://truffled.lol/png/games/baldi.webp",
    "embedUrl": "https://truffled.lol/games/baldis-basics/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-44-baldi-s-basics-birthday-bash-webport",
    "title": "Baldi's Basics Birthday Bash, Webport",
    "thumbnail": "https://truffled.lol/png/games/bday.webp",
    "embedUrl": "https://truffled.lol/games/bday/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-45-baldi-s-basics-classic-remastered-webport",
    "title": "Baldi's Basics Classic Remastered, Webport",
    "thumbnail": "https://truffled.lol/png/games/baldire.webp",
    "embedUrl": "https://truffled.lol/games/BBCR/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-46-baldi-s-basics-plus-webport",
    "title": "Baldi's Basics Plus, Webport",
    "thumbnail": "https://truffled.lol/png/games/baldiplus.webp",
    "embedUrl": "https://truffled.lol/gamefile/bbp.html",
    "type": "iframe"
  },
  {
    "id": "truffled-47-baldi-s-basics-ultra-decompile",
    "title": "Baldi's Basics Ultra Decompile",
    "thumbnail": "https://truffled.lol/png/games/bbudc.webp",
    "embedUrl": "https://truffled.lol/gamefile/baldidecomp.html",
    "type": "iframe"
  },
  {
    "id": "truffled-48-baldi-s-fun-new-school-plus-ultimate-edition",
    "title": "Baldi's Fun New School Plus Ultimate Edition",
    "thumbnail": "https://truffled.lol/png/games/bfs.webp",
    "embedUrl": "https://truffled.lol/games/bfs/",
    "type": "iframe"
  },
  {
    "id": "truffled-49-baldurs-gate-2-webport",
    "title": "Baldurs Gate 2, Webport",
    "thumbnail": "https://truffled.lol/png/games/gate2.webp",
    "embedUrl": "https://truffled.lol/games/baldurs-gate-2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-50-banjo-kazooie",
    "title": "Banjo Kazooie",
    "thumbnail": "https://truffled.lol/png/games/banjokazooie.webp",
    "embedUrl": "https://truffled.lol/gamefile/banjokazooie.html",
    "type": "iframe"
  },
  {
    "id": "truffled-51-bart-bash",
    "title": "Bart Bash",
    "thumbnail": "https://truffled.lol/png/games/bartbash.webp",
    "embedUrl": "https://truffled.lol/gamefile/bartbash.html",
    "type": "iframe"
  },
  {
    "id": "truffled-52-bart-blast",
    "title": "Bart Blast",
    "thumbnail": "https://truffled.lol/png/games/bart.webp",
    "embedUrl": "https://truffled.lol/gamefile/bart.html",
    "type": "iframe"
  },
  {
    "id": "truffled-53-baseball-bros",
    "title": "Baseball Bros",
    "thumbnail": "https://truffled.lol/png/games/basebros.webp",
    "embedUrl": "https://truffled.lol/games/baseballbros/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-54-basketball-stars",
    "title": "Basketball stars",
    "thumbnail": "https://truffled.lol/png/games/basketstars.webp",
    "embedUrl": "https://truffled.lol/games/basketballstars/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-55-basket-bros",
    "title": "Basket Bros",
    "thumbnail": "https://truffled.lol/png/games/basketbro.webp",
    "embedUrl": "https://truffled.lol/gamefile/basket.html",
    "type": "iframe"
  },
  {
    "id": "truffled-56-basket-random",
    "title": "Basket Random",
    "thumbnail": "https://truffled.lol/png/games/basket.webp",
    "embedUrl": "https://truffled.lol/games/basket-random/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-57-beatblock-webport",
    "title": "Beatblock, Webport",
    "thumbnail": "https://truffled.lol/png/games/beatblock.webp",
    "embedUrl": "https://truffled.lol/games/beatblock/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-58-bee-movie-game",
    "title": "Bee Movie Game",
    "thumbnail": "https://truffled.lol/png/games/bee.webp",
    "embedUrl": "https://truffled.lol/games/beemovie/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-59-bendy-and-the-ink-machine-webport",
    "title": "Bendy And The Ink Machine, Webport",
    "thumbnail": "https://truffled.lol/png/games/bendy.webp",
    "embedUrl": "https://truffled.lol/games/bendy/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-60-bergentruck-webport",
    "title": "Bergentruck, Webport",
    "thumbnail": "https://truffled.lol/png/games/ber.webp",
    "embedUrl": "https://truffled.lol/games/bergentruck/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-61-bfdia-5b",
    "title": "Bfdia 5b",
    "thumbnail": "https://truffled.lol/png/games/bfdia5b.webp",
    "embedUrl": "https://truffled.lol/games/bfdia 5b/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-62-big-tower-tiny-square",
    "title": "Big Tower Tiny Square",
    "thumbnail": "https://truffled.lol/png/games/btt.webp",
    "embedUrl": "https://truffled.lol/games/btts/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-63-bitlife",
    "title": "Bitlife",
    "thumbnail": "https://truffled.lol/png/games/bit.webp",
    "embedUrl": "https://truffled.lol/games/bitlife/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-64-black-hole-fishing",
    "title": "Black Hole Fishing",
    "thumbnail": "https://truffled.lol/png/games/bhf.webp",
    "embedUrl": "https://truffled.lol/games/bhf/single.html",
    "type": "iframe"
  },
  {
    "id": "truffled-65-black-jack",
    "title": "Black Jack",
    "thumbnail": "https://truffled.lol/png/games/blackjack.webp",
    "embedUrl": "https://truffled.lol/gamefile/BlackJack.html",
    "type": "iframe"
  },
  {
    "id": "truffled-66-block-blast",
    "title": "Block Blast",
    "thumbnail": "https://truffled.lol/png/games/unnamed.webp",
    "embedUrl": "https://truffled.lol/games/block-blast/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-67-bloodmoney-webport",
    "title": "Bloodmoney, Webport",
    "thumbnail": "https://truffled.lol/png/games/blood.webp",
    "embedUrl": "https://truffled.lol/games/bloodmoney/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-68-bloons-td5",
    "title": "Bloons TD5",
    "thumbnail": "https://truffled.lol/png/games/blo5.webp",
    "embedUrl": "https://truffled.lol/games/btd5/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-69-bloons-td6",
    "title": "Bloons TD6",
    "thumbnail": "https://truffled.lol/png/games/blo6.webp",
    "embedUrl": "https://truffled.lol/games/btd6/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-70-bloons-td-battles-2",
    "title": "Bloons TD Battles 2",
    "thumbnail": "https://truffled.lol/png/games/bloonstdb2.webp",
    "embedUrl": "https://nowgg.fun/apps/ninja-kiwi/1403/bloons-td-battles-2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-71-bloon-td1",
    "title": "Bloon TD1",
    "thumbnail": "https://truffled.lol/png/games/bloons.webp",
    "embedUrl": "https://truffled.lol/games/bloonstd/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-72-bloon-td2",
    "title": "Bloon TD2",
    "thumbnail": "https://truffled.lol/png/games/blo2.webp",
    "embedUrl": "https://truffled.lol/games/bloonstd2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-73-bloon-td3",
    "title": "Bloon TD3",
    "thumbnail": "https://truffled.lol/png/games/blo3.webp",
    "embedUrl": "https://truffled.lol/games/btd3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-74-bloon-td4",
    "title": "Bloon TD4",
    "thumbnail": "https://truffled.lol/png/games/btd4.webp",
    "embedUrl": "https://truffled.lol/gamefile/bloonstd4.html",
    "type": "iframe"
  },
  {
    "id": "truffled-75-bloxors",
    "title": "Bloxors",
    "thumbnail": "https://truffled.lol/png/games/bloxorz.webp",
    "embedUrl": "https://truffled.lol/games/bloxors/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-76-bombmerman",
    "title": "Bombmerman",
    "thumbnail": "https://truffled.lol/png/games/bomberman.webp",
    "embedUrl": "https://truffled.lol/gamefile/bomberman.html",
    "type": "iframe"
  },
  {
    "id": "truffled-77-bombmerman-2",
    "title": "Bombmerman 2",
    "thumbnail": "https://truffled.lol/png/games/bomberman2.webp",
    "embedUrl": "https://truffled.lol/gamefile/bomberman2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-78-bonk-io",
    "title": "Bonk.io",
    "thumbnail": "https://truffled.lol/png/games/bonkio.webp",
    "embedUrl": "https://bonk.io/",
    "type": "iframe"
  },
  {
    "id": "truffled-79-boxing-random",
    "title": "Boxing Random",
    "thumbnail": "https://truffled.lol/png/games/boxing.webp",
    "embedUrl": "https://truffled.lol/gamefile/boxing.html",
    "type": "iframe"
  },
  {
    "id": "truffled-80-brawlhalla-webport",
    "title": "Brawlhalla, Webport",
    "thumbnail": "https://truffled.lol/png/games/brawlhalla.webp",
    "embedUrl": "https://truffled.lol/games/brawlhalla/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-81-brotato-paws-and-claws-webport",
    "title": "Brotato Paws And Claws, Webport",
    "thumbnail": "https://truffled.lol/png/games/paws.webp",
    "embedUrl": "https://truffled.lol/games/brotato/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-82-buckshot-roulette-webport",
    "title": "Buckshot Roulette, Webport",
    "thumbnail": "https://truffled.lol/png/games/buck.webp",
    "embedUrl": "https://truffled.lol/games/buckshot/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-83-burrito-bison",
    "title": "Burrito Bison",
    "thumbnail": "https://truffled.lol/png/games/burrito.webp",
    "embedUrl": "https://truffled.lol/games/burrito/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-84-burrito-bison-revenge",
    "title": "Burrito Bison Revenge",
    "thumbnail": "https://truffled.lol/png/games/bbe.webp",
    "embedUrl": "https://truffled.lol/gamefile/bbe.html",
    "type": "iframe"
  },
  {
    "id": "truffled-85-call-of-duty-4-modern-warfare",
    "title": "Call of Duty 4 Modern Warfare",
    "thumbnail": "https://truffled.lol/png/games/cod4mw.webp",
    "embedUrl": "https://truffled.lol/games/cod4mw/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-86-call-of-duty-mobile",
    "title": "Call of Duty Mobile",
    "thumbnail": "https://truffled.lol/png/games/codmobile.webp",
    "embedUrl": "https://nowgg.fun/apps/a/10008/b.html",
    "type": "iframe"
  },
  {
    "id": "truffled-87-capuchin-webport",
    "title": "Capuchin, Webport",
    "thumbnail": "https://truffled.lol/png/games/capuchin.webp",
    "embedUrl": "https://truffled.lol/games/CapuchinBog/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-88-caseohs-basics-in-eating-and-fast-food-webport",
    "title": "CaseOhs Basics in Eating and Fast Food, Webport",
    "thumbnail": "https://truffled.lol/png/games/caseoh.webp",
    "embedUrl": "https://truffled.lol/gamefile/caseoh.html",
    "type": "iframe"
  },
  {
    "id": "truffled-89-castle-crashers-webport",
    "title": "Castle Crashers, Webport",
    "thumbnail": "https://truffled.lol/png/games/castlecrash.webp",
    "embedUrl": "https://truffled.lol/games/castle/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-90-cat-goes-fishing",
    "title": "Cat Goes Fishing",
    "thumbnail": "https://truffled.lol/png/games/catgoesfishing.webp",
    "embedUrl": "https://truffled.lol/games/catfish/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-91-celeste-3d-webport",
    "title": "Celeste 3D, Webport",
    "thumbnail": "https://truffled.lol/png/games/celeste3d.webp",
    "embedUrl": "https://truffled.lol/games/celeste3d/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-92-celeste-64-webport",
    "title": "Celeste 64, Webport",
    "thumbnail": "https://truffled.lol/png/games/celeste64.webp",
    "embedUrl": "https://truffled.lol/games/celeste64/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-93-celeste-webport",
    "title": "Celeste, Webport",
    "thumbnail": "https://truffled.lol/png/games/celeste.webp",
    "embedUrl": "https://truffled.lol/games/celeste/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-94-cheese-rolling-webport",
    "title": "Cheese Rolling, Webport",
    "thumbnail": "https://truffled.lol/png/games/cheeser.webp",
    "embedUrl": "https://truffled.lol/gamefile/cheese.html",
    "type": "iframe"
  },
  {
    "id": "truffled-95-chess-com",
    "title": "Chess.com",
    "thumbnail": "https://truffled.lol/png/games/chess.webp",
    "embedUrl": "https://chess.com",
    "type": "iframe"
  },
  {
    "id": "truffled-96-christmas-massacre-webport",
    "title": "Christmas Massacre, Webport",
    "thumbnail": "https://truffled.lol/png/games/christmas.webp",
    "embedUrl": "https://truffled.lol/gamefile/christmas.html",
    "type": "iframe"
  },
  {
    "id": "truffled-97-class-of-09-flipside-webport",
    "title": "Class Of 09 Flipside, Webport",
    "thumbnail": "https://truffled.lol/png/games/flip.webp",
    "embedUrl": "https://truffled.lol/games/C09FS/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-98-class-of-09-re-up-webport",
    "title": "Class Of 09 Re-Up, Webport",
    "thumbnail": "https://truffled.lol/png/games/reup.webp",
    "embedUrl": "https://truffled.lol/games/C09RU/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-99-class-of-09-webport",
    "title": "Class Of 09, Webport",
    "thumbnail": "https://truffled.lol/png/games/class.webp",
    "embedUrl": "https://truffled.lol/games/C09/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-100-clover-pit",
    "title": "Clover Pit",
    "thumbnail": "https://truffled.lol/png/games/clover.webp",
    "embedUrl": "https://truffled.lol/gamefile/cloverpit.html",
    "type": "iframe"
  },
  {
    "id": "truffled-101-cluster-truck-webport",
    "title": "Cluster Truck, Webport",
    "thumbnail": "https://truffled.lol/png/games/cluster.webp",
    "embedUrl": "https://truffled.lol/games/clustertruck/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-102-coffee-talk",
    "title": "Coffee Talk",
    "thumbnail": "https://truffled.lol/png/games/coffee.webp",
    "embedUrl": "https://truffled.lol/games/coffee/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-103-cookie-clicker",
    "title": "Cookie Clicker",
    "thumbnail": "https://truffled.lol/png/games/cookie.webp",
    "embedUrl": "https://truffled.lol/games/cookie-clicker/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-104-cookie-run-kingdom",
    "title": "Cookie Run Kingdom",
    "thumbnail": "https://truffled.lol/png/games/crk.webp",
    "embedUrl": "https://nowgg.fun/apps/a/10019/b.html",
    "type": "iframe"
  },
  {
    "id": "truffled-105-cooking-mama",
    "title": "Cooking Mama",
    "thumbnail": "https://truffled.lol/png/games/cookingmama.webp",
    "embedUrl": "https://truffled.lol/gamefile/cookingmama.html",
    "type": "iframe"
  },
  {
    "id": "truffled-106-cooking-mama-2",
    "title": "Cooking Mama 2",
    "thumbnail": "https://truffled.lol/png/games/cookingmama2.webp",
    "embedUrl": "https://truffled.lol/gamefile/cookingmama2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-107-cooking-mama-3",
    "title": "Cooking Mama 3",
    "thumbnail": "https://truffled.lol/png/games/cookingmama3.webp",
    "embedUrl": "https://truffled.lol/gamefile/cookingmama3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-108-counter-stike-0-8",
    "title": "Counter Stike 0.8",
    "thumbnail": "https://truffled.lol/png/games/cs08.webp",
    "embedUrl": "https://truffled.lol/games/psp/cs/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-109-crash-bandicoot-1",
    "title": "Crash Bandicoot 1",
    "thumbnail": "https://truffled.lol/png/games/crash1.webp",
    "embedUrl": "https://truffled.lol/gamefile/crash1.html",
    "type": "iframe"
  },
  {
    "id": "truffled-110-crash-bandicoot-2",
    "title": "Crash Bandicoot 2",
    "thumbnail": "https://truffled.lol/png/games/crash2.webp",
    "embedUrl": "https://truffled.lol/gamefile/crash2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-111-crash-bandicoot-3",
    "title": "Crash Bandicoot 3",
    "thumbnail": "https://truffled.lol/png/games/crash3.webp",
    "embedUrl": "https://truffled.lol/gamefile/crash3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-112-crashout-crew-webport",
    "title": "Crashout Crew, Webport",
    "thumbnail": "https://truffled.lol/png/games/crash.webp",
    "embedUrl": "https://truffled.lol/games/crashout/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-113-crazy-balls",
    "title": "Crazy Balls",
    "thumbnail": "https://truffled.lol/png/games/balls.webp",
    "embedUrl": "https://truffled.lol/gamefile/balls.html",
    "type": "iframe"
  },
  {
    "id": "truffled-114-crazycattle3d-webport",
    "title": "CrazyCattle3D, Webport",
    "thumbnail": "https://truffled.lol/png/games/crazyca.webp",
    "embedUrl": "https://truffled.lol/games/cattle3d/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-115-crossy-roads",
    "title": "Crossy Roads",
    "thumbnail": "https://truffled.lol/png/games/crossy.webp",
    "embedUrl": "https://truffled.lol/gamefile/crossy.html",
    "type": "iframe"
  },
  {
    "id": "truffled-116-cruelty-squad-webport",
    "title": "Cruelty Squad, Webport",
    "thumbnail": "https://truffled.lol/png/games/cruelty.webp",
    "embedUrl": "https://truffled.lol/games/cruelty/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-117-csgo-clicker",
    "title": "Csgo Clicker",
    "thumbnail": "https://truffled.lol/png/games/csbox.webp",
    "embedUrl": "https://truffled.lol/games/csgo-clicker/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-118-cuphead-webport",
    "title": "Cuphead, Webport",
    "thumbnail": "https://truffled.lol/png/games/cup.webp",
    "embedUrl": "https://truffled.lol/games/Cuphead/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-119-customer-support-webport",
    "title": "Customer Support, Webport",
    "thumbnail": "https://truffled.lol/png/games/cus.webp",
    "embedUrl": "https://truffled.lol/games/CustomerSupport/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-120-cut-the-rope",
    "title": "Cut The Rope",
    "thumbnail": "https://truffled.lol/png/games/cut1.webp",
    "embedUrl": "https://truffled.lol/gamefile/cut.html",
    "type": "iframe"
  },
  {
    "id": "truffled-121-cut-the-rope-holiday",
    "title": "Cut The Rope Holiday",
    "thumbnail": "https://truffled.lol/png/games/cut2.webp",
    "embedUrl": "https://truffled.lol/gamefile/hol.html",
    "type": "iframe"
  },
  {
    "id": "truffled-122-cut-the-rope-time-travel",
    "title": "Cut The Rope : Time Travel",
    "thumbnail": "https://truffled.lol/png/games/time.webp",
    "embedUrl": "https://truffled.lol/gamefile/time.html",
    "type": "iframe"
  },
  {
    "id": "truffled-123-dadish",
    "title": "Dadish",
    "thumbnail": "https://truffled.lol/png/games/dadish.webp",
    "embedUrl": "https://truffled.lol/gamefile/dadish.html",
    "type": "iframe"
  },
  {
    "id": "truffled-124-dadish-2",
    "title": "Dadish 2",
    "thumbnail": "https://truffled.lol/png/games/dadish2.webp",
    "embedUrl": "https://truffled.lol/gamefile/dadish2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-125-dadish-3",
    "title": "Dadish 3",
    "thumbnail": "https://truffled.lol/png/games/dadish3.webp",
    "embedUrl": "https://truffled.lol/gamefile/dadish3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-126-dadish-3d",
    "title": "Dadish 3d",
    "thumbnail": "https://truffled.lol/png/games/dadish3d.webp",
    "embedUrl": "https://truffled.lol/gamefile/dadish3d.html",
    "type": "iframe"
  },
  {
    "id": "truffled-127-dadish-daily",
    "title": "Dadish Daily",
    "thumbnail": "https://truffled.lol/png/games/daily.webp",
    "embedUrl": "https://truffled.lol/gamefile/daily.html",
    "type": "iframe"
  },
  {
    "id": "truffled-128-danganronpa",
    "title": "Danganronpa",
    "thumbnail": "https://truffled.lol/png/games/dan.webp",
    "embedUrl": "https://truffled.lol/games/danganronpa/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-129-dead-plate-webport",
    "title": "DEAD PLATE, Webport",
    "thumbnail": "https://truffled.lol/png/games/deadp.webp",
    "embedUrl": "https://truffled.lol/gamefile/dead.html",
    "type": "iframe"
  },
  {
    "id": "truffled-130-deadseat-webport",
    "title": "Deadseat, Webport",
    "thumbnail": "https://truffled.lol/png/games/deadseat.webp",
    "embedUrl": "https://truffled.lol/games/deadseat/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-131-dead-tapes",
    "title": "Dead Tapes",
    "thumbnail": "https://truffled.lol/png/games/deadta.webp",
    "embedUrl": "https://truffled.lol/games/deadtapesfinal/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-132-death-run-3d",
    "title": "Death Run 3D",
    "thumbnail": "https://truffled.lol/png/games/death.webp",
    "embedUrl": "https://truffled.lol/games/death-run-3d/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-133-deltarune-webport",
    "title": "Deltarune, Webport",
    "thumbnail": "https://truffled.lol/png/games/deltarune.webp",
    "embedUrl": "https://truffled.lol/games/deltarune/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-134-deltatraveler-webport",
    "title": "Deltatraveler, Webport",
    "thumbnail": "https://truffled.lol/png/games/deltatr.webp",
    "embedUrl": "https://truffled.lol/gamefile/deltatr.html",
    "type": "iframe"
  },
  {
    "id": "truffled-135-dewdrop-dynasty-webport",
    "title": "Dewdrop Dynasty, Webport",
    "thumbnail": "https://truffled.lol/png/games/dewrop.webp",
    "embedUrl": "https://truffled.lol/games/dewdrop/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-136-diablo",
    "title": "Diablo",
    "thumbnail": "https://truffled.lol/png/games/diablo.webp",
    "embedUrl": "https://truffled.lol/games/diablo/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-137-dice-a-million-webport",
    "title": "Dice A Million, Webport",
    "thumbnail": "https://truffled.lol/png/games/diceamillion.webp",
    "embedUrl": "https://truffled.lol/gamefile/diceamillion.html",
    "type": "iframe"
  },
  {
    "id": "truffled-138-dinosaur",
    "title": "Dinosaur",
    "thumbnail": "https://truffled.lol/png/games/dino.webp",
    "embedUrl": "https://truffled.lol/games/dinosaur/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-139-doge-miner",
    "title": "Doge Miner",
    "thumbnail": "https://truffled.lol/png/games/doge.webp",
    "embedUrl": "https://truffled.lol/gamefile/Doge Miner.html",
    "type": "iframe"
  },
  {
    "id": "truffled-140-doge-miner-2",
    "title": "Doge Miner 2",
    "thumbnail": "https://truffled.lol/png/games/dogeminer2.webp",
    "embedUrl": "https://truffled.lol/gamefile/dm2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-141-dome-keeper-webport",
    "title": "Dome Keeper, Webport",
    "thumbnail": "https://truffled.lol/png/games/domekeeper.webp",
    "embedUrl": "https://truffled.lol/games/domekeeper/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-142-do-not-take-this-cat-home-webport",
    "title": "Do Not Take This Cat Home, Webport",
    "thumbnail": "https://truffled.lol/png/games/dont.webp",
    "embedUrl": "https://truffled.lol/games/donottakethiscathome/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-143-dont-bite-me-bro-webport",
    "title": "Dont Bite Me Bro!, Webport",
    "thumbnail": "https://truffled.lol/png/games/dbmb.webp",
    "embedUrl": "https://truffled.lol/games/dbmb/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-144-doodle-jump",
    "title": "Doodle Jump",
    "thumbnail": "https://truffled.lol/png/games/doodle.webp",
    "embedUrl": "https://truffled.lol/gamefile/Doodle Jump.html",
    "type": "iframe"
  },
  {
    "id": "truffled-145-doom",
    "title": "Doom",
    "thumbnail": "https://truffled.lol/png/games/doom.webp",
    "embedUrl": "https://truffled.lol/games/doom/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-146-doom-2",
    "title": "Doom 2",
    "thumbnail": "https://truffled.lol/png/games/doom2.webp",
    "embedUrl": "https://truffled.lol/gamefile/doom2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-147-doom-3",
    "title": "Doom 3",
    "thumbnail": "https://truffled.lol/png/games/doom3.webp",
    "embedUrl": "https://truffled.lol/games/doom3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-148-doom-64",
    "title": "Doom 64",
    "thumbnail": "https://truffled.lol/png/games/doom64.webp",
    "embedUrl": "https://truffled.lol/gamefile/doom64.html",
    "type": "iframe"
  },
  {
    "id": "truffled-149-dreadhead-parkour",
    "title": "Dreadhead Parkour",
    "thumbnail": "https://truffled.lol/png/games/dread.webp",
    "embedUrl": "https://truffled.lol/gamefile/dread.html",
    "type": "iframe"
  },
  {
    "id": "truffled-150-drift-boss",
    "title": "Drift Boss",
    "thumbnail": "https://truffled.lol/png/games/driftboss.webp",
    "embedUrl": "https://truffled.lol/games/drift-boss/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-151-drift-hunter",
    "title": "Drift Hunter",
    "thumbnail": "https://truffled.lol/png/games/hunt.webp",
    "embedUrl": "https://truffled.lol/gamefile/drift.html",
    "type": "iframe"
  },
  {
    "id": "truffled-152-drive-mad",
    "title": "Drive Mad",
    "thumbnail": "https://truffled.lol/png/games/drive.webp",
    "embedUrl": "https://truffled.lol/games/drive-mad/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-153-dr-mario",
    "title": "Dr. Mario",
    "thumbnail": "https://truffled.lol/png/games/drmario.webp",
    "embedUrl": "https://truffled.lol/gamefile/drmario.html",
    "type": "iframe"
  },
  {
    "id": "truffled-154-duck-life-1",
    "title": "Duck Life 1",
    "thumbnail": "https://truffled.lol/png/games/duck1.webp",
    "embedUrl": "https://truffled.lol/games/ducklife1/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-155-duck-life-2",
    "title": "Duck Life 2",
    "thumbnail": "https://truffled.lol/png/games/duck2.webp",
    "embedUrl": "https://truffled.lol/games/ducklife2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-156-duck-life-3",
    "title": "Duck Life 3",
    "thumbnail": "https://truffled.lol/png/games/duck3.webp",
    "embedUrl": "https://truffled.lol/games/ducklife3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-157-duck-life-4",
    "title": "Duck Life 4",
    "thumbnail": "https://truffled.lol/png/games/duck4.webp",
    "embedUrl": "https://truffled.lol/games/ducklife4/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-158-duck-life-5",
    "title": "Duck Life 5",
    "thumbnail": "https://truffled.lol/png/games/duck5.webp",
    "embedUrl": "https://truffled.lol/games/ducklife5/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-159-duck-life-6",
    "title": "Duck Life 6",
    "thumbnail": "https://truffled.lol/png/games/ducklife6.webp",
    "embedUrl": "https://truffled.lol/games/ducklife6/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-160-duck-life-7",
    "title": "Duck Life 7",
    "thumbnail": "https://truffled.lol/png/games/ducklife7.webp",
    "embedUrl": "https://truffled.lol/games/ducklife7/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-161-duck-life-8-webport",
    "title": "Duck Life 8, Webport",
    "thumbnail": "https://truffled.lol/png/games/ducklifeadc.webp",
    "embedUrl": "https://truffled.lol/games/ducklifeadv/",
    "type": "iframe"
  },
  {
    "id": "truffled-162-dumb-ways-to-die",
    "title": "Dumb Ways To Die",
    "thumbnail": "https://truffled.lol/png/games/dumb.webp",
    "embedUrl": "https://truffled.lol/games/dumb/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-163-dune",
    "title": "Dune",
    "thumbnail": "https://truffled.lol/png/games/dune.webp",
    "embedUrl": "https://truffled.lol/games/dune/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-164-ea-sports-fc-mobile-24-soccer",
    "title": "EA SPORTS FC MOBILE 24 SOCCER",
    "thumbnail": "https://truffled.lol/png/games/easportsmobile.webp",
    "embedUrl": "https://nowgg.fun/apps/electronic-arts/1353/ea-sports-fc-mobile-24-soccer.html",
    "type": "iframe"
  },
  {
    "id": "truffled-165-eggy-car",
    "title": "Eggy Car",
    "thumbnail": "https://truffled.lol/png/games/eggycar.webp",
    "embedUrl": "https://truffled.lol/gamefile/eggycar.html",
    "type": "iframe"
  },
  {
    "id": "truffled-166-emily-is-away",
    "title": "Emily Is Away",
    "thumbnail": "https://truffled.lol/png/games/emily.webp",
    "embedUrl": "https://truffled.lol/games/emily/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-167-endacopia-webport",
    "title": "Endacopia, Webport",
    "thumbnail": "https://truffled.lol/png/games/endacopia.webp",
    "embedUrl": "https://truffled.lol/games/endacopia/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-168-endoparasitic",
    "title": "Endoparasitic",
    "thumbnail": "https://truffled.lol/png/games/endo1.webp",
    "embedUrl": "https://truffled.lol/games/endoparasitic/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-169-endoparasitic-2",
    "title": "Endoparasitic 2",
    "thumbnail": "https://truffled.lol/png/games/endo2.webp",
    "embedUrl": "https://truffled.lol/games/endoparasitic2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-170-escape-road",
    "title": "Escape Road",
    "thumbnail": "https://truffled.lol/png/games/road.webp",
    "embedUrl": "https://truffled.lol/gamefile/escape.html",
    "type": "iframe"
  },
  {
    "id": "truffled-171-escape-road-2",
    "title": "Escape Road 2",
    "thumbnail": "https://truffled.lol/png/games/escape2.webp",
    "embedUrl": "https://truffled.lol/gamefile/road2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-172-escape-road-3",
    "title": "Escape Road 3",
    "thumbnail": "https://truffled.lol/png/games/escape3.webp",
    "embedUrl": "https://truffled.lol/gamefile/escape3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-173-escape-road-city-2",
    "title": "Escape Road City 2",
    "thumbnail": "https://truffled.lol/png/games/roadcity.webp",
    "embedUrl": "https://truffled.lol/gamefile/roadcity2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-174-falling-fred",
    "title": "Falling Fred",
    "thumbnail": "https://truffled.lol/png/games/super-falling-fred.webp",
    "embedUrl": "https://truffled.lol/games/falling/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-175-fallout",
    "title": "Fallout",
    "thumbnail": "https://truffled.lol/png/games/fallout.webp",
    "embedUrl": "https://truffled.lol/gamefile/falloutt.html",
    "type": "iframe"
  },
  {
    "id": "truffled-176-fallout-2-webport",
    "title": "Fallout 2, Webport",
    "thumbnail": "https://truffled.lol/png/games/fallout2.webp",
    "embedUrl": "https://truffled.lol/games/fo2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-177-fancy-pants-adventures",
    "title": "Fancy Pants Adventures",
    "thumbnail": "https://truffled.lol/png/games/fpa1.webp",
    "embedUrl": "https://truffled.lol/games/fancypantsadventures/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-178-fancy-pants-adventures-2",
    "title": "Fancy Pants Adventures 2",
    "thumbnail": "https://truffled.lol/png/games/fancy2.webp",
    "embedUrl": "https://truffled.lol/games/fancypantsadventures2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-179-fancy-pants-adventures-3",
    "title": "Fancy Pants Adventures 3",
    "thumbnail": "https://truffled.lol/png/games/fpa3.webp",
    "embedUrl": "https://truffled.lol/gamefile/fpa3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-180-fears-to-fathom-home-alone-webport",
    "title": "Fears To Fathom: Home Alone, Webport",
    "thumbnail": "https://truffled.lol/png/games/fear.webp",
    "embedUrl": "https://truffled.lol/games/ftf/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-181-fez-webport",
    "title": "FEZ, Webport",
    "thumbnail": "https://truffled.lol/png/games/fez.webp",
    "embedUrl": "https://truffled.lol/games/FEZ/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-182-final-fantasy-vii",
    "title": "Final Fantasy VII",
    "thumbnail": "https://truffled.lol/png/games/ffvii.webp",
    "embedUrl": "https://truffled.lol/gamefile/ffvii.html",
    "type": "iframe"
  },
  {
    "id": "truffled-183-fireboy-and-watergirl",
    "title": "Fireboy and Watergirl",
    "thumbnail": "https://truffled.lol/png/games/fire1.webp",
    "embedUrl": "https://truffled.lol/games/watergirl-1/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-184-fireboy-and-watergirl-2",
    "title": "Fireboy and Watergirl 2",
    "thumbnail": "https://truffled.lol/png/games/fire2.webp",
    "embedUrl": "https://truffled.lol/games/watergirl-2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-185-fireboy-and-watergirl-3",
    "title": "Fireboy and Watergirl 3",
    "thumbnail": "https://truffled.lol/png/games/fire3.webp",
    "embedUrl": "https://truffled.lol/games/watergirl-3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-186-fireboy-and-watergirl-4",
    "title": "Fireboy and Watergirl 4",
    "thumbnail": "https://truffled.lol/png/games/fire4.webp",
    "embedUrl": "https://truffled.lol/games/watergirl-4/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-187-fish-webport",
    "title": "FISH, Webport",
    "thumbnail": "https://truffled.lol/png/games/fish.webp",
    "embedUrl": "https://truffled.lol/gamefile/fish.html",
    "type": "iframe"
  },
  {
    "id": "truffled-188-fister",
    "title": "Fister",
    "thumbnail": "https://truffled.lol/png/games/fister.webp",
    "embedUrl": "https://fister.fun",
    "type": "iframe"
  },
  {
    "id": "truffled-189-five-nights-at-candys",
    "title": "Five Nights At Candys",
    "thumbnail": "https://truffled.lol/png/games/fnac.webp",
    "embedUrl": "https://truffled.lol/gamefile/fnac.html",
    "type": "iframe"
  },
  {
    "id": "truffled-190-five-nights-at-candys-2",
    "title": "Five Nights At Candys 2",
    "thumbnail": "https://truffled.lol/png/games/fnac2.webp",
    "embedUrl": "https://truffled.lol/gamefile/fnac2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-191-five-nights-at-epsteins-webport",
    "title": "Five Nights At Epsteins, Webport",
    "thumbnail": "https://truffled.lol/png/games/fnae.webp",
    "embedUrl": "https://truffled.lol/gamefile/fnae.html",
    "type": "iframe"
  },
  {
    "id": "truffled-192-five-nights-at-frickbears-3-webport",
    "title": "Five Nights At Frickbears 3, Webport",
    "thumbnail": "https://truffled.lol/png/games/fnafb3.webp",
    "embedUrl": "https://truffled.lol/games/fb3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-193-five-nights-at-last-breath-webport",
    "title": "Five Nights At Last Breath, Webport",
    "thumbnail": "https://truffled.lol/png/games/breath.webp",
    "embedUrl": "https://truffled.lol/gamefile/breath.html",
    "type": "iframe"
  },
  {
    "id": "truffled-194-flappy-bird",
    "title": "Flappy bird",
    "thumbnail": "https://truffled.lol/png/games/flapp.webp",
    "embedUrl": "https://truffled.lol/games/flappybird/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-195-flying-gorilla-webport",
    "title": "Flying Gorilla, Webport",
    "thumbnail": "https://truffled.lol/png/games/flying.webp",
    "embedUrl": "https://truffled.lol/gamefile/gorilla.html",
    "type": "iframe"
  },
  {
    "id": "truffled-196-fnaf",
    "title": "FNAF",
    "thumbnail": "https://truffled.lol/png/games/splash.webp",
    "embedUrl": "https://truffled.lol/games/fnaf/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-197-fnaf2",
    "title": "FNAF2",
    "thumbnail": "https://truffled.lol/png/games/fnaf2.webp",
    "embedUrl": "https://truffled.lol/games/2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-198-fnaf3",
    "title": "FNAF3",
    "thumbnail": "https://truffled.lol/png/games/3f.webp",
    "embedUrl": "https://truffled.lol/games/3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-199-fnaf4",
    "title": "FNAF4",
    "thumbnail": "https://truffled.lol/png/games/fnaf4.webp",
    "embedUrl": "https://truffled.lol/games/fnaf4/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-200-fnaf4-halloween",
    "title": "FNAF4 Halloween",
    "thumbnail": "https://truffled.lol/png/games/hollowween.webp",
    "embedUrl": "https://truffled.lol/gamefile/ween.html",
    "type": "iframe"
  },
  {
    "id": "truffled-201-fnaf-sisters-location",
    "title": "FNAF Sisters Location",
    "thumbnail": "https://truffled.lol/png/games/sister.webp",
    "embedUrl": "https://truffled.lol/gamefile/fnafs.html",
    "type": "iframe"
  },
  {
    "id": "truffled-202-fnaf-ultimate-custom-night",
    "title": "FNAF Ultimate Custom Night",
    "thumbnail": "https://truffled.lol/png/games/custom.webp",
    "embedUrl": "https://truffled.lol/gamefile/fnafu.html",
    "type": "iframe"
  },
  {
    "id": "truffled-203-fnaf-world",
    "title": "FNAF World",
    "thumbnail": "https://truffled.lol/png/games/fnafworld.webp",
    "embedUrl": "https://truffled.lol/gamefile/fnafw.html",
    "type": "iframe"
  },
  {
    "id": "truffled-204-fnaf-world-refreshed",
    "title": "FNAF World Refreshed",
    "thumbnail": "https://truffled.lol/png/games/fne.webp",
    "embedUrl": "https://truffled.lol/games/fnw/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-205-fnaw",
    "title": "FNAW",
    "thumbnail": "https://truffled.lol/png/games/fnaw.webp",
    "embedUrl": "https://truffled.lol/gamefile/fnaw.html",
    "type": "iframe"
  },
  {
    "id": "truffled-206-fnf-friday-night-funkin",
    "title": "FNF, Friday Night Funkin",
    "thumbnail": "https://truffled.lol/png/games/fnf.webp",
    "embedUrl": "https://truffled.lol/games/fnf/fnfog.html",
    "type": "iframe"
  },
  {
    "id": "truffled-207-football-bros",
    "title": "Football Bros",
    "thumbnail": "https://truffled.lol/png/games/footbros.webp",
    "embedUrl": "https://truffled.lol/games/footballbros/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-208-fortnite",
    "title": "Fortnite",
    "thumbnail": "https://truffled.lol/png/games/fortnite.webp",
    "embedUrl": "https://nowgg.fun/apps/aptoide/5874/aptoide.html?deep_link=aptoidesearch://com.epicgames.fortnite",
    "type": "iframe"
  },
  {
    "id": "truffled-209-friday-night-funkin-aethos",
    "title": "Friday Night Funkin Aethos",
    "thumbnail": "https://truffled.lol/png/games/aethos.webp",
    "embedUrl": "https://truffled.lol/games/fnf/aethos.html",
    "type": "iframe"
  },
  {
    "id": "truffled-210-friday-night-funkin-atrocity",
    "title": "Friday Night Funkin Atrocity",
    "thumbnail": "https://truffled.lol/png/games/atrocity.webp",
    "embedUrl": "https://truffled.lol/games/fnf/atrocity.html",
    "type": "iframe"
  },
  {
    "id": "truffled-211-friday-night-funkin-bfdi-26",
    "title": "Friday Night Funkin BFDI 26",
    "thumbnail": "https://truffled.lol/png/games/bfdi26.webp",
    "embedUrl": "https://truffled.lol/games/fnf/bfdi26.html",
    "type": "iframe"
  },
  {
    "id": "truffled-212-friday-night-funkin-bop-city",
    "title": "Friday Night Funkin Bop City",
    "thumbnail": "https://truffled.lol/png/games/bopcity.webp",
    "embedUrl": "https://truffled.lol/games/fnf/bopcity.html",
    "type": "iframe"
  },
  {
    "id": "truffled-213-friday-night-funkin-for-a-bfdi",
    "title": "Friday Night Funkin For A BFDI",
    "thumbnail": "https://truffled.lol/png/games/ffabfdi.webp",
    "embedUrl": "https://truffled.lol/games/fnf/ffabfdi.html",
    "type": "iframe"
  },
  {
    "id": "truffled-214-friday-night-funkin-garcello",
    "title": "Friday Night Funkin Garcello",
    "thumbnail": "https://truffled.lol/png/games/garcello.webp",
    "embedUrl": "https://truffled.lol/games/fnf/garcello.html",
    "type": "iframe"
  },
  {
    "id": "truffled-215-friday-night-funkin-get-digging",
    "title": "Friday Night Funkin Get Digging",
    "thumbnail": "https://truffled.lol/png/games/getdigging.webp",
    "embedUrl": "https://truffled.lol/games/fnf/getdigging.html",
    "type": "iframe"
  },
  {
    "id": "truffled-216-friday-night-funkin-hatsune-miku",
    "title": "Friday Night Funkin Hatsune Miku",
    "thumbnail": "https://truffled.lol/png/games/miku.webp",
    "embedUrl": "https://truffled.lol/games/fnf/miku.html",
    "type": "iframe"
  },
  {
    "id": "truffled-217-friday-night-funkin-hex",
    "title": "Friday Night Funkin Hex",
    "thumbnail": "https://truffled.lol/png/games/hex.webp",
    "embedUrl": "https://truffled.lol/games/fnf/hex.html",
    "type": "iframe"
  },
  {
    "id": "truffled-218-friday-night-funkin-horkglorpgloop",
    "title": "Friday Night Funkin Horkglorpgloop",
    "thumbnail": "https://truffled.lol/png/games/infinite.webp",
    "embedUrl": "https://truffled.lol/games/fnf/horkglorpgloop.html",
    "type": "iframe"
  },
  {
    "id": "truffled-219-friday-night-funkin-infinite-irida",
    "title": "Friday Night Funkin Infinite Irida",
    "thumbnail": "https://truffled.lol/png/games/hork.webp",
    "embedUrl": "https://truffled.lol/games/fnf/infiniteiridra.html",
    "type": "iframe"
  },
  {
    "id": "truffled-220-friday-night-funkin-kapi",
    "title": "Friday Night Funkin Kapi",
    "thumbnail": "https://truffled.lol/png/games/kapi.webp",
    "embedUrl": "https://truffled.lol/games/fnf/kapi.html",
    "type": "iframe"
  },
  {
    "id": "truffled-221-friday-night-funkin-mario-madness",
    "title": "Friday Night Funkin Mario Madness",
    "thumbnail": "https://truffled.lol/png/games/mario.webp",
    "embedUrl": "https://truffled.lol/games/fnf/mariomadness.html",
    "type": "iframe"
  },
  {
    "id": "truffled-222-friday-night-funkin-nonsense",
    "title": "Friday Night Funkin Nonsense",
    "thumbnail": "https://truffled.lol/png/games/nonsense.webp",
    "embedUrl": "https://truffled.lol/games/fnf/nonsense.html",
    "type": "iframe"
  },
  {
    "id": "truffled-223-friday-night-funkin-rewrite",
    "title": "Friday Night Funkin Rewrite",
    "thumbnail": "https://truffled.lol/png/games/rewrite.webp",
    "embedUrl": "https://truffled.lol/games/fnf/rewrite.html",
    "type": "iframe"
  },
  {
    "id": "truffled-224-friday-night-funkin-rewrite-2",
    "title": "Friday Night Funkin Rewrite 2",
    "thumbnail": "https://truffled.lol/png/games/rewrite2.webp",
    "embedUrl": "https://truffled.lol/games/fnf/rewrite2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-225-friday-night-funkin-ron",
    "title": "Friday Night Funkin Ron",
    "thumbnail": "https://truffled.lol/png/games/ron.webp",
    "embedUrl": "https://truffled.lol/games/fnf/ron.html",
    "type": "iframe"
  },
  {
    "id": "truffled-226-friday-night-funkin-shaggy",
    "title": "Friday Night Funkin Shaggy",
    "thumbnail": "https://truffled.lol/png/games/shaggy.webp",
    "embedUrl": "https://truffled.lol/games/fnf/shaggy.html",
    "type": "iframe"
  },
  {
    "id": "truffled-227-friday-night-funkin-shaggy-x-matt",
    "title": "Friday Night Funkin Shaggy X Matt",
    "thumbnail": "https://truffled.lol/png/games/sxm.webp",
    "embedUrl": "https://truffled.lol/games/fnf/shaggyxmatt.html",
    "type": "iframe"
  },
  {
    "id": "truffled-228-friday-night-funkin-shucks-v2",
    "title": "Friday Night Funkin Shucks V2",
    "thumbnail": "https://truffled.lol/png/games/shucksv2.webp",
    "embedUrl": "https://truffled.lol/games/fnf/shucksv2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-229-friday-night-funkin-tricky",
    "title": "Friday Night Funkin Tricky",
    "thumbnail": "https://truffled.lol/png/games/tricky.webp",
    "embedUrl": "https://truffled.lol/games/fnf/tricky.html",
    "type": "iframe"
  },
  {
    "id": "truffled-230-friday-night-funkin-twiddlefinger",
    "title": "Friday Night Funkin TWIDDLEFINGER",
    "thumbnail": "https://truffled.lol/png/games/twiddle.webp",
    "embedUrl": "https://truffled.lol/games/fnf/TWIDDLEFINGER.html",
    "type": "iframe"
  },
  {
    "id": "truffled-231-friday-night-funkin-vs-tord",
    "title": "Friday Night Funkin Vs. Tord",
    "thumbnail": "https://truffled.lol/png/games/tord.webp",
    "embedUrl": "https://truffled.lol/games/fnf/tord.html",
    "type": "iframe"
  },
  {
    "id": "truffled-232-friday-night-funkin-whitty",
    "title": "Friday Night Funkin Whitty",
    "thumbnail": "https://truffled.lol/png/games/whitty.webp",
    "embedUrl": "https://truffled.lol/games/fnf/whitty.html",
    "type": "iframe"
  },
  {
    "id": "truffled-233-friday-night-funkin-zardy",
    "title": "Friday Night Funkin Zardy",
    "thumbnail": "https://truffled.lol/png/games/zardy.webp",
    "embedUrl": "https://truffled.lol/games/fnf/zardy.html",
    "type": "iframe"
  },
  {
    "id": "truffled-234-fruit-ninja",
    "title": "Fruit Ninja",
    "thumbnail": "https://truffled.lol/png/games/ninja.webp",
    "embedUrl": "https://truffled.lol/games/fruitninja/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-235-fused240",
    "title": "Fused240",
    "thumbnail": "https://truffled.lol/png/games/fused240.webp",
    "embedUrl": "https://truffled.lol/games/fused240/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-236-gabriel-s-awesome-schoolhouse-webport",
    "title": "Gabriel's Awesome Schoolhouse, Webport",
    "thumbnail": "https://truffled.lol/png/games/gabriel.webp",
    "embedUrl": "https://truffled.lol/gamefile/gash.html",
    "type": "iframe"
  },
  {
    "id": "truffled-237-gacha-life",
    "title": "Gacha Life",
    "thumbnail": "https://truffled.lol/png/games/gachalife.webp",
    "embedUrl": "https://truffled.lol/gamefile/life.html",
    "type": "iframe"
  },
  {
    "id": "truffled-238-gacha-verse",
    "title": "Gacha Verse",
    "thumbnail": "https://truffled.lol/png/games/gachaverse.webp",
    "embedUrl": "https://truffled.lol/gamefile/verse.html",
    "type": "iframe"
  },
  {
    "id": "truffled-239-gamble-with-your-friends-webport",
    "title": "Gamble With Your Friends, Webport",
    "thumbnail": "https://truffled.lol/png/games/gamble.webp",
    "embedUrl": "https://truffled.lol/games/gamble/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-240-gang-beasts-webport",
    "title": "Gang Beasts, Webport",
    "thumbnail": "https://truffled.lol/png/games/gangbeats.webp",
    "embedUrl": "https://truffled.lol/games/gangbeasts/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-241-genshin-impact",
    "title": "Genshin Impact",
    "thumbnail": "https://truffled.lol/png/games/genshin.webp",
    "embedUrl": "https://nowgg.fun/apps/cognosphere-pte-ltd-/1773/genshin-impact.html",
    "type": "iframe"
  },
  {
    "id": "truffled-242-geoguessr",
    "title": "Geoguessr",
    "thumbnail": "https://truffled.lol/png/games/geoguess.webp",
    "embedUrl": "https://www.geoguessr.com/",
    "type": "iframe"
  },
  {
    "id": "truffled-243-geometry-dash-webport",
    "title": "Geometry Dash, Webport",
    "thumbnail": "https://truffled.lol/png/games/gd.webp",
    "embedUrl": "https://truffled.lol/games/geo/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-244-getaway-shootout",
    "title": "Getaway Shootout",
    "thumbnail": "https://truffled.lol/png/games/getaway.webp",
    "embedUrl": "https://truffled.lol/games/getaway-shootout/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-245-getting-over-it-webport",
    "title": "Getting Over It, Webport",
    "thumbnail": "https://truffled.lol/png/games/gettin.webp",
    "embedUrl": "https://truffled.lol/gamefile/goi.html",
    "type": "iframe"
  },
  {
    "id": "truffled-246-gladihoppers",
    "title": "Gladihoppers",
    "thumbnail": "https://truffled.lol/png/games/glad.webp",
    "embedUrl": "https://truffled.lol/gamefile/Gladihoppers.html",
    "type": "iframe"
  },
  {
    "id": "truffled-247-goober-dash",
    "title": "Goober Dash",
    "thumbnail": "https://truffled.lol/png/games/goober.webp",
    "embedUrl": "https://gooberdash.winterpixel.io/",
    "type": "iframe"
  },
  {
    "id": "truffled-248-google-baseball",
    "title": "Google Baseball",
    "thumbnail": "https://truffled.lol/png/games/google.webp",
    "embedUrl": "https://truffled.lol/gamefile/gbase.html",
    "type": "iframe"
  },
  {
    "id": "truffled-249-gorilla-tag-webport",
    "title": "Gorilla Tag, Webport",
    "thumbnail": "https://truffled.lol/png/games/gtag.webp",
    "embedUrl": "https://truffled.lol/games/gtag/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-250-go-to-bed-webport",
    "title": "Go to bed, Webport",
    "thumbnail": "https://truffled.lol/png/games/gotobed.webp",
    "embedUrl": "https://truffled.lol/games/GTB/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-251-granny",
    "title": "Granny",
    "thumbnail": "https://truffled.lol/png/games/granny.webp",
    "embedUrl": "https://truffled.lol/gamefile/granny.html",
    "type": "iframe"
  },
  {
    "id": "truffled-252-granny-2",
    "title": "Granny 2",
    "thumbnail": "https://truffled.lol/png/games/gran2.webp",
    "embedUrl": "https://truffled.lol/gamefile/Granny 2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-253-granny-3",
    "title": "Granny 3",
    "thumbnail": "https://truffled.lol/png/games/gran3.webp",
    "embedUrl": "https://truffled.lol/games/granny3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-254-gravity-run",
    "title": "Gravity run",
    "thumbnail": "https://truffled.lol/png/games/gravity.webp",
    "embedUrl": "https://truffled.lol/games/gravity-run/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-255-greybox",
    "title": "Greybox",
    "thumbnail": "https://truffled.lol/png/games/grey.webp",
    "embedUrl": "https://truffled.lol/games/graybox/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-256-gta-i",
    "title": "GTA I",
    "thumbnail": "https://truffled.lol/png/games/gta.webp",
    "embedUrl": "https://truffled.lol/games/gta/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-257-gta-ii",
    "title": "GTA II",
    "thumbnail": "https://truffled.lol/png/games/gta2.webp",
    "embedUrl": "https://truffled.lol/games/gta2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-258-gta-iii",
    "title": "GTA III",
    "thumbnail": "https://truffled.lol/png/games/gta3.webp",
    "embedUrl": "https://truffled.lol/gamefile/gta3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-259-gta-san-andreas",
    "title": "GTA San Andreas",
    "thumbnail": "https://truffled.lol/png/games/gtasan.webp",
    "embedUrl": "https://truffled.lol/games/gtasan/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-260-gta-vice-city-webport",
    "title": "GTA Vice City, Webport",
    "thumbnail": "https://truffled.lol/png/games/vice.webp",
    "embedUrl": "https://truffled.lol/games/vicecity/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-261-gun-mayhem",
    "title": "Gun Mayhem",
    "thumbnail": "https://truffled.lol/png/games/gun.webp",
    "embedUrl": "https://truffled.lol/games/funmayhem/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-262-gun-mayhem-2",
    "title": "Gun Mayhem 2",
    "thumbnail": "https://truffled.lol/png/games/gun2.webp",
    "embedUrl": "https://truffled.lol/games/funmayhem2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-263-gun-mayhem-redux",
    "title": "Gun Mayhem Redux",
    "thumbnail": "https://truffled.lol/png/games/gun3.webp",
    "embedUrl": "https://truffled.lol/games/funmayhemredux/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-264-gunspin",
    "title": "Gunspin",
    "thumbnail": "https://truffled.lol/png/games/guns.webp",
    "embedUrl": "https://truffled.lol/games/gunspin/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-265-half-life",
    "title": "Half life",
    "thumbnail": "https://truffled.lol/png/games/halflife.webp",
    "embedUrl": "https://truffled.lol/games/hl-main/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-266-half-life-opposing-force",
    "title": "Half life: Opposing Force",
    "thumbnail": "https://truffled.lol/png/games/hlof.webp",
    "embedUrl": "https://truffled.lol/gamefile/hlof.html",
    "type": "iframe"
  },
  {
    "id": "truffled-267-happy-wheels",
    "title": "Happy Wheels",
    "thumbnail": "https://truffled.lol/png/games/happy.webp",
    "embedUrl": "https://truffled.lol/games/happywheels/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-268-helltaker-webport",
    "title": "Helltaker, Webport",
    "thumbnail": "https://truffled.lol/png/games/helltaker.webp",
    "embedUrl": "https://truffled.lol/gamefile/helltaker.html",
    "type": "iframe"
  },
  {
    "id": "truffled-269-hill-climb-racing-webport",
    "title": "Hill Climb Racing, Webport",
    "thumbnail": "https://truffled.lol/png/games/hill.webp",
    "embedUrl": "https://truffled.lol/games/hcr/",
    "type": "iframe"
  },
  {
    "id": "truffled-270-hobo-1",
    "title": "Hobo 1",
    "thumbnail": "https://truffled.lol/png/games/hobo.webp",
    "embedUrl": "https://truffled.lol/gamefile/hobo1.html",
    "type": "iframe"
  },
  {
    "id": "truffled-271-hobo-2",
    "title": "Hobo 2",
    "thumbnail": "https://truffled.lol/png/games/hobo2.webp",
    "embedUrl": "https://truffled.lol/gamefile/hobo2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-272-hobo-3",
    "title": "Hobo 3",
    "thumbnail": "https://truffled.lol/png/games/hobo3.webp",
    "embedUrl": "https://truffled.lol/gamefile/hobo3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-273-hobo-4",
    "title": "Hobo 4",
    "thumbnail": "https://truffled.lol/png/games/hobo4.webp",
    "embedUrl": "https://truffled.lol/gamefile/hobo4.html",
    "type": "iframe"
  },
  {
    "id": "truffled-274-hobo-5",
    "title": "Hobo 5",
    "thumbnail": "https://truffled.lol/png/games/hobo5.webp",
    "embedUrl": "https://truffled.lol/gamefile/hobo5.html",
    "type": "iframe"
  },
  {
    "id": "truffled-275-hobo-6",
    "title": "Hobo 6",
    "thumbnail": "https://truffled.lol/png/games/hobo6.webp",
    "embedUrl": "https://truffled.lol/gamefile/hobo6.html",
    "type": "iframe"
  },
  {
    "id": "truffled-276-hobo-7",
    "title": "Hobo 7",
    "thumbnail": "https://truffled.lol/png/games/hobo7.webp",
    "embedUrl": "https://truffled.lol/gamefile/hobo7.html",
    "type": "iframe"
  },
  {
    "id": "truffled-277-hollow-knight-webport",
    "title": "Hollow Knight, Webport",
    "thumbnail": "https://truffled.lol/png/games/hollow.webp",
    "embedUrl": "https://truffled.lol/games/newesthk/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-278-honkai-star-rail",
    "title": "Honkai: Star Rail",
    "thumbnail": "https://truffled.lol/png/games/honkai.webp",
    "embedUrl": "https://nowgg.fun/apps/cognosphere-pte-ltd/1591/honkai-star-rail.html",
    "type": "iframe"
  },
  {
    "id": "truffled-279-horsey-game-webport",
    "title": "Horsey Game, Webport",
    "thumbnail": "https://truffled.lol/png/games/horesygame.webp",
    "embedUrl": "https://truffled.lol/games/HorseyGameWeb/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-280-hotline-miami-2-webport",
    "title": "Hotline Miami 2, Webport",
    "thumbnail": "https://truffled.lol/png/games/hlm2.webp",
    "embedUrl": "https://truffled.lol/games/hlm2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-281-hotline-miami-webport",
    "title": "Hotline Miami, Webport",
    "thumbnail": "https://truffled.lol/png/games/hot.webp",
    "embedUrl": "https://truffled.lol/games/whores/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-282-house-of-hazards",
    "title": "House Of Hazards",
    "thumbnail": "https://truffled.lol/png/games/house.webp",
    "embedUrl": "https://truffled.lol/games/houseofhazards/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-283-how-to-fish-webport",
    "title": "How To Fish, Webport",
    "thumbnail": "https://truffled.lol/png/games/htf.webp",
    "embedUrl": "https://truffled.lol/games/htf/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-284-human-expenditure-program-webport",
    "title": "HUMAN EXPENDITURE PROGRAM, Webport",
    "thumbnail": "https://truffled.lol/png/games/human.webp",
    "embedUrl": "https://truffled.lol/gamefile/human.html",
    "type": "iframe"
  },
  {
    "id": "truffled-285-ice-baby-quest-2",
    "title": "Ice Baby Quest 2",
    "thumbnail": "https://truffled.lol/png/games/icebaby2.webp",
    "embedUrl": "https://truffled.lol/games/icebaby2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-286-idle-breakout",
    "title": "Idle Breakout",
    "thumbnail": "https://truffled.lol/png/games/idle.webp",
    "embedUrl": "https://truffled.lol/games/idle-breakout/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-287-into-space-1",
    "title": "Into Space 1",
    "thumbnail": "https://truffled.lol/png/games/intospace1.webp",
    "embedUrl": "https://truffled.lol/games/is1/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-288-into-space-2",
    "title": "Into Space 2",
    "thumbnail": "https://truffled.lol/png/games/intospace2.webp",
    "embedUrl": "https://truffled.lol/games/is2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-289-into-space-3",
    "title": "Into Space 3",
    "thumbnail": "https://truffled.lol/png/games/intospace3.webp",
    "embedUrl": "https://truffled.lol/games/is3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-290-iron-lung-webport",
    "title": "Iron Lung, Webport",
    "thumbnail": "https://truffled.lol/png/games/iroonlung.webp",
    "embedUrl": "https://truffled.lol/games/ironlung/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-291-i-wanna-be-the-guy-webport",
    "title": "I Wanna Be The Guy, Webport",
    "thumbnail": "https://truffled.lol/png/games/iwbtg.webp",
    "embedUrl": "https://truffled.lol/games/iwbtg/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-292-jeffrey-epstein-basics-in-education-and-kidnapping-webport",
    "title": "Jeffrey Epstein Basics In Education And Kidnapping, Webport",
    "thumbnail": "https://truffled.lol/png/games/jeb.webp",
    "embedUrl": "https://truffled.lol/gamefile/jeb.html",
    "type": "iframe"
  },
  {
    "id": "truffled-293-jeffys-basics-webport",
    "title": "Jeffys Basics, Webport",
    "thumbnail": "https://truffled.lol/png/games/jeffys.webp",
    "embedUrl": "https://truffled.lol/games/JeffysBasicsBog/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-294-jelly-drift",
    "title": "Jelly Drift",
    "thumbnail": "https://truffled.lol/png/games/jelly.webp",
    "embedUrl": "https://truffled.lol/gamefile/jelly.html",
    "type": "iframe"
  },
  {
    "id": "truffled-295-jetpack-joyride",
    "title": "Jetpack Joyride",
    "thumbnail": "https://truffled.lol/png/games/jet.webp",
    "embedUrl": "https://truffled.lol/games/jetpackjoyride/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-296-jumbo-mario",
    "title": "Jumbo Mario",
    "thumbnail": "https://truffled.lol/png/games/jumbo.webp",
    "embedUrl": "https://truffled.lol/games/JumboMario/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-297-karlson2d-webport",
    "title": "Karlson2D, Webport",
    "thumbnail": "https://truffled.lol/png/games/karlson2d.webp",
    "embedUrl": "https://truffled.lol/games/karlson2d/truffledkarlson2d/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-298-karlson-webport",
    "title": "Karlson, Webport",
    "thumbnail": "https://truffled.lol/png/games/karlson.webp",
    "embedUrl": "https://truffled.lol/gamefile/Karlson.html",
    "type": "iframe"
  },
  {
    "id": "truffled-299-kerbal-space-program-webport",
    "title": "Kerbal Space Program, Webport",
    "thumbnail": "https://truffled.lol/png/games/ksp.webp",
    "embedUrl": "https://truffled.lol/games/ksp/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-300-kick-the-buddy-webport",
    "title": "Kick The Buddy, Webport",
    "thumbnail": "https://truffled.lol/png/games/ktb.webp",
    "embedUrl": "https://truffled.lol/games/kickthebuddy/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-301-kindergarten-1-webport",
    "title": "Kindergarten 1, Webport",
    "thumbnail": "https://truffled.lol/png/games/kind1.webp",
    "embedUrl": "https://truffled.lol/games/kindergarten/1/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-302-kindergarten-2-webport",
    "title": "Kindergarten 2, Webport",
    "thumbnail": "https://truffled.lol/png/games/kind2.webp",
    "embedUrl": "https://truffled.lol/games/kindergarten/2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-303-kindergarten-3-webport",
    "title": "Kindergarten 3, Webport",
    "thumbnail": "https://truffled.lol/png/games/kind3.webp",
    "embedUrl": "https://truffled.lol/games/Kindergarten3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-304-kinito-pet-webport",
    "title": "Kinito Pet, Webport",
    "thumbnail": "https://truffled.lol/png/games/kinto.webp",
    "embedUrl": "https://truffled.lol/games/kinitopet/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-305-kirby-soft-and-wet-webport",
    "title": "Kirby Soft And Wet, Webport",
    "thumbnail": "https://truffled.lol/png/games/kirbysoftandwet.webp",
    "embedUrl": "https://truffled.lol/gamefile/kirbysoftandwet.html",
    "type": "iframe"
  },
  {
    "id": "truffled-306-klifur",
    "title": "Klifur",
    "thumbnail": "https://truffled.lol/png/games/kil.webp",
    "embedUrl": "https://truffled.lol/games/kilfur/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-307-knife-hit",
    "title": "Knife Hit",
    "thumbnail": "https://truffled.lol/png/games/knife.webp",
    "embedUrl": "https://truffled.lol/games/knifehit/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-308-krunker",
    "title": "Krunker",
    "thumbnail": "https://truffled.lol/png/games/krunker.webp",
    "embedUrl": "https://truffled.lol/games/krunker/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-309-lacey-s-flash-games-webport",
    "title": "Lacey's Flash Games, Webport",
    "thumbnail": "https://truffled.lol/png/games/lacey.webp",
    "embedUrl": "https://truffled.lol/gamefile/lacy.html",
    "type": "iframe"
  },
  {
    "id": "truffled-310-la-madriguera",
    "title": "La Madriguera",
    "thumbnail": "https://truffled.lol/png/games/labear.webp",
    "embedUrl": "https://truffled.lol/games/lamadriguera/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-311-learn-to-fly",
    "title": "Learn To Fly",
    "thumbnail": "https://truffled.lol/png/games/learn1.webp",
    "embedUrl": "https://truffled.lol/games/learntofly/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-312-learn-to-fly-2",
    "title": "Learn To Fly 2",
    "thumbnail": "https://truffled.lol/png/games/learn2.webp",
    "embedUrl": "https://truffled.lol/games/learntofly2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-313-learn-to-fly-3",
    "title": "Learn To Fly 3",
    "thumbnail": "https://truffled.lol/png/games/learn3.webp",
    "embedUrl": "https://truffled.lol/games/ltf3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-314-learn-to-fly-idle",
    "title": "Learn To Fly Idle",
    "thumbnail": "https://truffled.lol/png/games/learni.webp",
    "embedUrl": "https://truffled.lol/games/learntoflyidle/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-315-lego-star-wars",
    "title": "Lego Star Wars",
    "thumbnail": "https://truffled.lol/png/games/legostarwars.webp",
    "embedUrl": "https://truffled.lol/gamefile/legostarwars.html",
    "type": "iframe"
  },
  {
    "id": "truffled-316-lethal-ape-webport",
    "title": "Lethal Ape, Webport",
    "thumbnail": "https://truffled.lol/png/games/lethalape.webp",
    "embedUrl": "https://truffled.lol/games/lethalape/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-317-lethal-company-webport",
    "title": "Lethal Company, Webport",
    "thumbnail": "https://truffled.lol/png/games/lethal.webp",
    "embedUrl": "https://truffled.lol/games/lethal/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-318-level-devil",
    "title": "Level Devil",
    "thumbnail": "https://truffled.lol/png/games/level.webp",
    "embedUrl": "https://truffled.lol/games/lvldevil/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-319-limbo",
    "title": "Limbo",
    "thumbnail": "https://truffled.lol/png/games/limbo.webp",
    "embedUrl": "https://truffled.lol/games/limbo/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-320-line-rider",
    "title": "Line Rider",
    "thumbnail": "https://truffled.lol/png/games/line.webp",
    "embedUrl": "https://truffled.lol/games/linerider/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-321-little-alchemy",
    "title": "Little Alchemy",
    "thumbnail": "https://truffled.lol/png/games/lil.webp",
    "embedUrl": "https://truffled.lol/games/littlealchemy/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-322-little-alchemy-2",
    "title": "Little Alchemy 2",
    "thumbnail": "https://truffled.lol/png/games/little2.webp",
    "embedUrl": "https://truffled.lol/gamefile/little2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-323-little-big-planet",
    "title": "Little Big Planet",
    "thumbnail": "https://truffled.lol/png/games/lbp.webp",
    "embedUrl": "https://truffled.lol/games/lbp/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-324-lobotomy-corporation-webport",
    "title": "Lobotomy Corporation, Webport",
    "thumbnail": "https://truffled.lol/png/games/lobotomycorp.webp",
    "embedUrl": "https://truffled.lol/games/lobcorp/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-325-lolbeans-io",
    "title": "Lolbeans.io",
    "thumbnail": "https://truffled.lol/png/games/lolbeans.webp",
    "embedUrl": "https://lolbeans.io/",
    "type": "iframe"
  },
  {
    "id": "truffled-326-machine-party",
    "title": "Machine Party",
    "thumbnail": "https://truffled.lol/png/games/machineparty.webp",
    "embedUrl": "https://truffled.lol/games/mp/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-327-madden-nfl-24-mobile-football",
    "title": "Madden NFL 24 Mobile Football",
    "thumbnail": "https://truffled.lol/png/games/madden24.webp",
    "embedUrl": "https://nowgg.fun/apps/electronic-arts/1731/madden-nfl-24-mobile-football.html",
    "type": "iframe"
  },
  {
    "id": "truffled-328-madness-accelerant",
    "title": "Madness Accelerant",
    "thumbnail": "https://truffled.lol/png/games/madnessaccelerant.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnessaccelerant.html",
    "type": "iframe"
  },
  {
    "id": "truffled-329-madness-ambulation",
    "title": "Madness Ambulation",
    "thumbnail": "https://truffled.lol/png/games/madnessambulation.webp",
    "embedUrl": "https://truffled.lol/games/madnessambulation/madnessambulation.html",
    "type": "iframe"
  },
  {
    "id": "truffled-330-madness-combat-defense",
    "title": "Madness Combat Defense",
    "thumbnail": "https://truffled.lol/png/games/madnesscombatdefense.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnesscombatdefense.html",
    "type": "iframe"
  },
  {
    "id": "truffled-331-madness-combat-fps-fueled-by-hot-dogs",
    "title": "Madness Combat FPS Fueled by Hot Dogs",
    "thumbnail": "https://truffled.lol/png/games/madnesscfpsfbhd.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnesscfpsfbhd.html",
    "type": "iframe"
  },
  {
    "id": "truffled-332-madness-gemini",
    "title": "Madness Gemini",
    "thumbnail": "https://truffled.lol/png/games/madnessgemini.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnessgemini.html",
    "type": "iframe"
  },
  {
    "id": "truffled-333-madness-hydraulic",
    "title": "Madness Hydraulic",
    "thumbnail": "https://truffled.lol/png/games/madnesshydraulic.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnesshydraulic.html",
    "type": "iframe"
  },
  {
    "id": "truffled-334-madness-interactive",
    "title": "Madness Interactive",
    "thumbnail": "https://truffled.lol/png/games/madnessinteractive.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnessinteractive.html",
    "type": "iframe"
  },
  {
    "id": "truffled-335-madness-melee",
    "title": "Madness Melee",
    "thumbnail": "https://truffled.lol/png/games/madness.webp",
    "embedUrl": "https://truffled.lol/games/bogtruffled/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-336-madness-off-color",
    "title": "Madness Off Color",
    "thumbnail": "https://truffled.lol/png/games/madnessoffcolor.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnessoffcolor.html",
    "type": "iframe"
  },
  {
    "id": "truffled-337-madness-premediation",
    "title": "Madness Premediation",
    "thumbnail": "https://truffled.lol/png/games/madnesspremediation.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnesspremediation.html",
    "type": "iframe"
  },
  {
    "id": "truffled-338-madness-project-nexus",
    "title": "Madness Project Nexus",
    "thumbnail": "https://truffled.lol/png/games/madnesscombatnexus.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnesscombatnexus.html",
    "type": "iframe"
  },
  {
    "id": "truffled-339-madness-retaliation",
    "title": "Madness Retaliation",
    "thumbnail": "https://truffled.lol/png/games/madnessretaliation.webp",
    "embedUrl": "https://truffled.lol/gamefile/madnessretaliation.html",
    "type": "iframe"
  },
  {
    "id": "truffled-340-mario-kart-7",
    "title": "Mario Kart 7",
    "thumbnail": "https://truffled.lol/png/games/mk7.webp",
    "embedUrl": "https://truffled.lol/games/mk7/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-341-mario-kart-64",
    "title": "Mario Kart 64",
    "thumbnail": "https://truffled.lol/png/games/mk64.webp",
    "embedUrl": "https://truffled.lol/games/mk64/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-342-mario-kart-ds",
    "title": "Mario Kart DS",
    "thumbnail": "https://truffled.lol/png/games/mkds.webp",
    "embedUrl": "https://truffled.lol/games/mkds/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-343-mario-party-1",
    "title": "Mario Party 1",
    "thumbnail": "https://truffled.lol/png/games/marioparty1.webp",
    "embedUrl": "https://truffled.lol/gamefile/marioparty.html",
    "type": "iframe"
  },
  {
    "id": "truffled-344-mario-party-2",
    "title": "Mario Party 2",
    "thumbnail": "https://truffled.lol/png/games/marioparty2.webp",
    "embedUrl": "https://truffled.lol/gamefile/marioparty2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-345-mario-party-3",
    "title": "Mario Party 3",
    "thumbnail": "https://truffled.lol/png/games/marioparty3.webp",
    "embedUrl": "https://truffled.lol/gamefile/marioparty3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-346-megaman",
    "title": "Megaman",
    "thumbnail": "https://truffled.lol/png/games/megaman.webp",
    "embedUrl": "https://truffled.lol/gamefile/megaman.html",
    "type": "iframe"
  },
  {
    "id": "truffled-347-melon-playground",
    "title": "Melon Playground",
    "thumbnail": "https://truffled.lol/png/games/melon.webp",
    "embedUrl": "https://truffled.lol/games/melon-playground/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-348-melon-sandbox",
    "title": "Melon Sandbox",
    "thumbnail": "https://truffled.lol/png/games/melonsandbox.webp",
    "embedUrl": "https://truffled.lol/games/melon-playground/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-349-merge-rot",
    "title": "Merge Rot",
    "thumbnail": "https://truffled.lol/png/games/rot.webp",
    "embedUrl": "https://truffled.lol/games/mergerot/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-350-meowdoku-webport",
    "title": "Meowdoku, Webport",
    "thumbnail": "https://truffled.lol/png/games/mewodoku.webp",
    "embedUrl": "https://truffled.lol/games/md/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-351-milkman-karlson-webport",
    "title": "Milkman karlson, Webport",
    "thumbnail": "https://truffled.lol/png/games/milk.webp",
    "embedUrl": "https://truffled.lol/games/milk/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-352-mindustry-webport",
    "title": "Mindustry, Webport",
    "thumbnail": "https://truffled.lol/png/games/mindustry.webp",
    "embedUrl": "https://truffled.lol/gamefile/mindustry.html",
    "type": "iframe"
  },
  {
    "id": "truffled-353-minecraft",
    "title": "Minecraft",
    "thumbnail": "https://truffled.lol/png/games/mc.webp",
    "embedUrl": "https://truffled.lol/games/minecraft/",
    "type": "iframe"
  },
  {
    "id": "truffled-354-minecraft-legacy-console-edition-webport",
    "title": "Minecraft Legacy Console Edition, Webport",
    "thumbnail": "https://truffled.lol/png/games/mclce.webp",
    "embedUrl": "https://truffled.lol/games/mclce/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-355-minecraft-pocket-edition-webport",
    "title": "Minecraft Pocket Edition, Webport",
    "thumbnail": "https://truffled.lol/png/games/mcpe.webp",
    "embedUrl": "https://truffled.lol/games/mcpe/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-356-minecraft-story-mode-webport",
    "title": "Minecraft: Story Mode, Webport",
    "thumbnail": "https://truffled.lol/png/games/mcsm.webp",
    "embedUrl": "https://truffled.lol/games/mcsm/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-357-minesweeper-mania",
    "title": "Minesweeper Mania",
    "thumbnail": "https://truffled.lol/png/games/minese.webp",
    "embedUrl": "https://truffled.lol/gamefile/minesweepermania.html",
    "type": "iframe"
  },
  {
    "id": "truffled-358-minesweeper-plus-webport",
    "title": "Minesweeper Plus, Webport",
    "thumbnail": "https://truffled.lol/png/games/mineseplu.webp",
    "embedUrl": "https://truffled.lol/gamefile/mineplus.html",
    "type": "iframe"
  },
  {
    "id": "truffled-359-miside-webport",
    "title": "Miside, Webport",
    "thumbnail": "https://truffled.lol/png/games/miside.webp",
    "embedUrl": "https://truffled.lol/gamefile/miside.html",
    "type": "iframe"
  },
  {
    "id": "truffled-360-monkey-mart",
    "title": "Monkey Mart",
    "thumbnail": "https://truffled.lol/png/games/monkey.webp",
    "embedUrl": "https://truffled.lol/games/MonkeyMart/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-361-monster-tracks",
    "title": "Monster Tracks",
    "thumbnail": "https://truffled.lol/png/games/monster.webp",
    "embedUrl": "https://truffled.lol/games/monster-tracks/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-362-moto-x3m",
    "title": "Moto X3M",
    "thumbnail": "https://truffled.lol/png/games/moto.webp",
    "embedUrl": "https://truffled.lol/games/motox3m/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-363-my-singing-monsters",
    "title": "My Singing Monsters",
    "thumbnail": "https://truffled.lol/png/games/msm.webp",
    "embedUrl": "https://nowgg.fun/apps/big-blue/8811/singing-monsters.html",
    "type": "iframe"
  },
  {
    "id": "truffled-364-my-talking-baby-hippo-webport",
    "title": "My Talking Baby Hippo, Webport",
    "thumbnail": "https://truffled.lol/png/games/hippo.webp",
    "embedUrl": "https://truffled.lol/games/mtbh/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-365-my-teardrop-daniel",
    "title": "My teardrop, daniel",
    "thumbnail": "https://truffled.lol/png/games/mytear.webp",
    "embedUrl": "https://truffled.lol/gamefile/mytear.html",
    "type": "iframe"
  },
  {
    "id": "truffled-366-nazi-zombies-portable",
    "title": "Nazi Zombies: Portable",
    "thumbnail": "https://truffled.lol/png/games/nazi.webp",
    "embedUrl": "https://truffled.lol/gamefile/nzp.html",
    "type": "iframe"
  },
  {
    "id": "truffled-367-needy-streamer-overload-webport",
    "title": "Needy Streamer Overload, Webport",
    "thumbnail": "https://truffled.lol/png/games/nso.webp",
    "embedUrl": "https://truffled.lol/games/nso/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-368-new-super-mario-bros",
    "title": "New Super Mario Bros",
    "thumbnail": "https://truffled.lol/png/games/nsmb.webp",
    "embedUrl": "https://truffled.lol/games/nsmb/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-369-n-gon",
    "title": "n-gon",
    "thumbnail": "https://truffled.lol/png/games/ngon.webp",
    "embedUrl": "https://truffled.lol/games/n-gon/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-370-node-buster-webport",
    "title": "Node Buster, Webport",
    "thumbnail": "https://truffled.lol/png/games/nodebuster.webp",
    "embedUrl": "https://truffled.lol/games/nodebuster/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-371-noomiclone",
    "title": "Noomiclone",
    "thumbnail": "https://truffled.lol/png/games/noomiclone.webp",
    "embedUrl": "https://truffled.lol/games/noomi/",
    "type": "iframe"
  },
  {
    "id": "truffled-372-nubbys-number-factory-webport",
    "title": "Nubbys Number Factory, Webport",
    "thumbnail": "https://truffled.lol/png/games/nubby.webp",
    "embedUrl": "https://truffled.lol/gamefile/nubby.html",
    "type": "iframe"
  },
  {
    "id": "truffled-373-om-nom-run",
    "title": "Om Nom Run",
    "thumbnail": "https://truffled.lol/png/games/omnomrun.webp",
    "embedUrl": "https://truffled.lol/gamefile/omnomrun.html",
    "type": "iframe"
  },
  {
    "id": "truffled-374-omori-webport",
    "title": "OMORI, Webport",
    "thumbnail": "https://truffled.lol/png/games/omori.webp",
    "embedUrl": "https://truffled.lol/gamefile/OMORI.html",
    "type": "iframe"
  },
  {
    "id": "truffled-375-oneshot-webport",
    "title": "Oneshot, Webport",
    "thumbnail": "https://truffled.lol/png/games/oneshot.webp",
    "embedUrl": "https://truffled.lol/gamefile/oneshot.html",
    "type": "iframe"
  },
  {
    "id": "truffled-376-oneshot-world-machine-edition-webport",
    "title": "Oneshot World Machine Edition, Webport",
    "thumbnail": "https://truffled.lol/png/games/oneshotwm.webp",
    "embedUrl": "https://truffled.lol/games/worldmachine/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-377-orange-roulette",
    "title": "Orange Roulette",
    "thumbnail": "https://truffled.lol/png/games/orange.webp",
    "embedUrl": "https://truffled.lol/gamefile/orange.html",
    "type": "iframe"
  },
  {
    "id": "truffled-378-oshi-oshi-punch",
    "title": "Oshi Oshi Punch",
    "thumbnail": "https://truffled.lol/png/games/oshi.webp",
    "embedUrl": "https://truffled.lol/gamefile/onshi.html",
    "type": "iframe"
  },
  {
    "id": "truffled-379-osu",
    "title": "Osu!",
    "thumbnail": "https://truffled.lol/png/games/osu.webp",
    "embedUrl": "https://truffled.lol/games/osu/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-380-overburden-webport",
    "title": "Overburden, Webport",
    "thumbnail": "https://truffled.lol/png/games/overburden.webp",
    "embedUrl": "https://truffled.lol/gamefile/overburden.html",
    "type": "iframe"
  },
  {
    "id": "truffled-381-ovo",
    "title": "OvO",
    "thumbnail": "https://truffled.lol/png/games/ovo.webp",
    "embedUrl": "https://truffled.lol/games/ovo/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-382-ovo-2",
    "title": "OvO 2",
    "thumbnail": "https://truffled.lol/png/games/ovo2.webp",
    "embedUrl": "https://truffled.lol/games/OvO2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-383-ovo-dimensions",
    "title": "OvO Dimensions",
    "thumbnail": "https://truffled.lol/png/games/ovodi.webp",
    "embedUrl": "https://truffled.lol/games/OvoDimensions/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-384-pacman",
    "title": "Pacman",
    "thumbnail": "https://truffled.lol/png/games/pacman.webp",
    "embedUrl": "https://truffled.lol/games/pacman/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-385-pacman-world",
    "title": "Pacman World",
    "thumbnail": "https://truffled.lol/png/games/pacmanworld.webp",
    "embedUrl": "https://truffled.lol/gamefile/pacmanw.html",
    "type": "iframe"
  },
  {
    "id": "truffled-386-pacman-world-2",
    "title": "Pacman World 2",
    "thumbnail": "https://truffled.lol/png/games/pacmanworld2.webp",
    "embedUrl": "https://truffled.lol/gamefile/pacmanw2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-387-paint-gal-adventures",
    "title": "Paint Gal Adventures",
    "thumbnail": "https://truffled.lol/png/games/paintgal.webp",
    "embedUrl": "https://truffled.lol/games/paintbog/Paint Gal Adventures.html",
    "type": "iframe"
  },
  {
    "id": "truffled-388-papas-bakeria",
    "title": "Papas Bakeria",
    "thumbnail": "https://truffled.lol/png/games/bake.webp",
    "embedUrl": "https://truffled.lol/games/papasbakeria/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-389-papas-burgeria",
    "title": "Papas Burgeria",
    "thumbnail": "https://truffled.lol/png/games/burger.webp",
    "embedUrl": "https://truffled.lol/games/papasburgeria/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-390-papas-cheeseria",
    "title": "Papas Cheeseria",
    "thumbnail": "https://truffled.lol/png/games/cheese.webp",
    "embedUrl": "https://truffled.lol/games/papascheeseria/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-391-papas-donuteria",
    "title": "Papas Donuteria",
    "thumbnail": "https://truffled.lol/png/games/donut.webp",
    "embedUrl": "https://truffled.lol/games/papasdonuteria/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-392-papas-freezeria",
    "title": "Papas Freezeria",
    "thumbnail": "https://truffled.lol/png/games/freeze.webp",
    "embedUrl": "https://truffled.lol/games/papasfreezeria/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-393-papas-pizzaeria",
    "title": "Papas Pizzaeria",
    "thumbnail": "https://truffled.lol/png/games/pizza.webp",
    "embedUrl": "https://truffled.lol/games/papaspizza/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-394-paperio-2",
    "title": "Paperio 2",
    "thumbnail": "https://truffled.lol/png/games/paperio2.webp",
    "embedUrl": "https://truffled.lol/games/paperio2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-395-paper-mario",
    "title": "Paper Mario",
    "thumbnail": "https://truffled.lol/png/games/papermario.webp",
    "embedUrl": "https://truffled.lol/gamefile/papermario.html",
    "type": "iframe"
  },
  {
    "id": "truffled-396-papers-please",
    "title": "Papers, Please",
    "thumbnail": "https://truffled.lol/png/games/papers.webp",
    "embedUrl": "https://truffled.lol/gamefile/papers.html",
    "type": "iframe"
  },
  {
    "id": "truffled-397-parappa-the-rapper",
    "title": "Parappa The Rapper",
    "thumbnail": "https://truffled.lol/png/games/rapper.webp",
    "embedUrl": "https://truffled.lol/games/paps/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-398-parappa-the-rapper-2",
    "title": "Parappa The Rapper 2",
    "thumbnail": "https://truffled.lol/png/games/parappa2.webp",
    "embedUrl": "https://truffled.lol/games/parappa2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-399-patrick-s-parabox-webport",
    "title": "Patrick's Parabox, Webport",
    "thumbnail": "https://truffled.lol/png/games/parabox.webp",
    "embedUrl": "https://truffled.lol/games/bogparabox/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-400-peaks-of-yore-webport",
    "title": "Peaks of Yore, Webport",
    "thumbnail": "https://truffled.lol/png/games/peaksofyore.webp",
    "embedUrl": "https://truffled.lol/gamefile/peaksofyore.html",
    "type": "iframe"
  },
  {
    "id": "truffled-401-peak-webport",
    "title": "Peak, Webport",
    "thumbnail": "https://truffled.lol/png/games/peak.webp",
    "embedUrl": "https://truffled.lol/games/peak/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-402-peggle",
    "title": "Peggle",
    "thumbnail": "https://truffled.lol/png/games/peggle.webp",
    "embedUrl": "https://truffled.lol/gamefile/Peggle.html",
    "type": "iframe"
  },
  {
    "id": "truffled-403-peggle-deluxe",
    "title": "Peggle Deluxe",
    "thumbnail": "https://truffled.lol/png/games/pegdeluxe.webp",
    "embedUrl": "https://truffled.lol/games/pegg/deluxe/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-404-peggle-extreme",
    "title": "Peggle Extreme",
    "thumbnail": "https://truffled.lol/png/games/pegextreme.webp",
    "embedUrl": "https://truffled.lol/games/pegg/extreme/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-405-peggle-nights",
    "title": "Peggle Nights",
    "thumbnail": "https://truffled.lol/png/games/pegnights.webp",
    "embedUrl": "https://truffled.lol/games/pegg/nights/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-406-peggle-wow-edition",
    "title": "Peggle WoW Edition",
    "thumbnail": "https://truffled.lol/png/games/pegwow.webp",
    "embedUrl": "https://truffled.lol/games/pegg/wow/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-407-pego-prototype",
    "title": "Pego (Prototype)",
    "thumbnail": "https://truffled.lol/png/games/pegoo.webp",
    "embedUrl": "https://truffled.lol/games/pegg/pego/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-408-people-playground-webport",
    "title": "People Playground, Webport",
    "thumbnail": "https://truffled.lol/png/games/peoplepg.webp",
    "embedUrl": "https://truffled.lol/games/ppg/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-409-phineas-and-ferb-transport-inators-of-doom-webport",
    "title": "Phineas and Ferb: Transport-inators of Doom, Webport",
    "thumbnail": "https://truffled.lol/png/games/dooom.webp",
    "embedUrl": "https://truffled.lol/games/dooom/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-410-pikmin-webport",
    "title": "Pikmin, Webport",
    "thumbnail": "https://truffled.lol/png/games/pikmin.webp",
    "embedUrl": "https://truffled.lol/games/pikmin/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-411-pikuniku-webport",
    "title": "Pikuniku, Webport",
    "thumbnail": "https://truffled.lol/png/games/piku.webp",
    "embedUrl": "https://truffled.lol/games/pikubog/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-412-pixel-gun-3d",
    "title": "Pixel Gun 3D",
    "thumbnail": "https://truffled.lol/png/games/pixelgun.webp",
    "embedUrl": "https://truffled.lol/games/pixl/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-413-pizza-tower-scoutdigo",
    "title": "Pizza Tower: Scoutdigo",
    "thumbnail": "https://truffled.lol/png/games/pts.webp",
    "embedUrl": "https://truffled.lol/gamefile/pts.html",
    "type": "iframe"
  },
  {
    "id": "truffled-414-pizza-tower-webport",
    "title": "Pizza Tower, Webport",
    "thumbnail": "https://truffled.lol/png/games/pizzatower.webp",
    "embedUrl": "https://truffled.lol/games/NoiseUpdate/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-415-pizzatron-3000",
    "title": "Pizzatron 3000",
    "thumbnail": "https://truffled.lol/png/games/pizza3.webp",
    "embedUrl": "https://truffled.lol/games/pizza/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-416-plague-inc",
    "title": "Plague Inc.",
    "thumbnail": "https://truffled.lol/png/games/plagueinc.webp",
    "embedUrl": "https://truffled.lol/games/PlagueInc/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-417-plants-vs-zombies",
    "title": "Plants VS Zombies",
    "thumbnail": "https://truffled.lol/png/games/pvz.webp",
    "embedUrl": "https://truffled.lol/gamefile/pvs.html",
    "type": "iframe"
  },
  {
    "id": "truffled-418-plants-vs-zombies-garden-endless",
    "title": "Plants VS Zombies Garden Endless",
    "thumbnail": "https://truffled.lol/png/games/pvz2.webp",
    "embedUrl": "https://truffled.lol/games/pvzge/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-419-plauge-inc-webport",
    "title": "Plauge Inc, Webport",
    "thumbnail": "https://truffled.lol/png/games/plaugeinc.webp",
    "embedUrl": "https://truffled.lol/games/PlagueInc/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-420-pokemon-academy-life-forever",
    "title": "Pokemon Academy Life Forever",
    "thumbnail": "https://truffled.lol/png/games/pokemonacademy.webp",
    "embedUrl": "https://truffled.lol/gamefile/pokemonacademy.html",
    "type": "iframe"
  },
  {
    "id": "truffled-421-pokemon-blue",
    "title": "Pokemon Blue",
    "thumbnail": "https://truffled.lol/png/games/blue.webp",
    "embedUrl": "https://truffled.lol/gamefile/blue.html",
    "type": "iframe"
  },
  {
    "id": "truffled-422-pokemon-crystal",
    "title": "Pokemon Crystal",
    "thumbnail": "https://truffled.lol/png/games/crystal.webp",
    "embedUrl": "https://truffled.lol/gamefile/blob.html",
    "type": "iframe"
  },
  {
    "id": "truffled-423-pokemon-emerald",
    "title": "Pokemon Emerald",
    "thumbnail": "https://truffled.lol/png/games/em.webp",
    "embedUrl": "https://truffled.lol/gamefile/em.html",
    "type": "iframe"
  },
  {
    "id": "truffled-424-pokemon-gold",
    "title": "Pokemon Gold",
    "thumbnail": "https://truffled.lol/png/games/gold.webp",
    "embedUrl": "https://truffled.lol/gamefile/gold.html",
    "type": "iframe"
  },
  {
    "id": "truffled-425-pokemon-red",
    "title": "Pokemon Red",
    "thumbnail": "https://truffled.lol/png/games/pokemonfirered.webp",
    "embedUrl": "https://truffled.lol/gamefile/red.html",
    "type": "iframe"
  },
  {
    "id": "truffled-426-pokemon-stadium",
    "title": "Pokemon Stadium",
    "thumbnail": "https://truffled.lol/png/games/pokestad.webp",
    "embedUrl": "https://truffled.lol/gamefile/pokestad.html",
    "type": "iframe"
  },
  {
    "id": "truffled-427-pokemon-stadium-2",
    "title": "Pokemon Stadium 2",
    "thumbnail": "https://truffled.lol/png/games/pokestad2.webp",
    "embedUrl": "https://truffled.lol/gamefile/pokestad2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-428-polytrack",
    "title": "Polytrack",
    "thumbnail": "https://truffled.lol/png/games/poly.webp",
    "embedUrl": "https://truffled.lol/games/polytrack/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-429-portal",
    "title": "Portal",
    "thumbnail": "https://truffled.lol/png/games/portal.webp",
    "embedUrl": "https://truffled.lol/games/portal/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-430-portal-2",
    "title": "Portal 2",
    "thumbnail": "https://truffled.lol/png/games/p2.webp",
    "embedUrl": "https://truffled.lol/games/portal2/portal2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-431-postal-webport",
    "title": "Postal, Webport",
    "thumbnail": "https://truffled.lol/png/games/postal.webp",
    "embedUrl": "https://truffled.lol/gamefile/postal.html",
    "type": "iframe"
  },
  {
    "id": "truffled-432-potion-craft-alchemy-simulator-webport",
    "title": "Potion Craft Alchemy Simulator, Webport",
    "thumbnail": "https://truffled.lol/png/games/pcraft.webp",
    "embedUrl": "https://truffled.lol/games/pcraft/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-433-pretend-its-not-there-webport",
    "title": "Pretend its not there, Webport",
    "thumbnail": "https://truffled.lol/png/games/pre.webp",
    "embedUrl": "https://truffled.lol/games/pretenditsnotthere/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-434-prodigy",
    "title": "Prodigy",
    "thumbnail": "https://truffled.lol/png/games/prodigy.webp",
    "embedUrl": "https://truffled.lol/games/prodigy/select/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-435-pubg-mobile-aftermath",
    "title": "PUBG Mobile: Aftermath",
    "thumbnail": "https://truffled.lol/png/games/pubgmobile.webp",
    "embedUrl": "https://nowgg.fun/apps/proxima-beta/2609/pubg-mobile-resistance.html",
    "type": "iframe"
  },
  {
    "id": "truffled-436-quake",
    "title": "Quake",
    "thumbnail": "https://truffled.lol/png/games/quake.webp",
    "embedUrl": "https://truffled.lol/games/quake/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-437-quake-ii",
    "title": "Quake II",
    "thumbnail": "https://truffled.lol/png/games/quakeii.webp",
    "embedUrl": "https://truffled.lol/games/quakeii/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-438-quake-iii",
    "title": "Quake III",
    "thumbnail": "https://truffled.lol/png/games/quakeiii.webp",
    "embedUrl": "https://truffled.lol/games/quakeiii/Quake3.htm",
    "type": "iframe"
  },
  {
    "id": "truffled-439-rabbids-alive-and-kicking",
    "title": "Rabbids Alive And Kicking",
    "thumbnail": "https://truffled.lol/png/games/rabbidalive.webp",
    "embedUrl": "https://truffled.lol/games/rabbidsa/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-440-rabbids-travel-in-time",
    "title": "Rabbids Travel In Time",
    "thumbnail": "https://truffled.lol/png/games/rabbidstravel.webp",
    "embedUrl": "https://truffled.lol/games/rabbidst/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-441-raft-wars",
    "title": "Raft Wars",
    "thumbnail": "https://truffled.lol/png/games/raft1.webp",
    "embedUrl": "https://truffled.lol/games/raft-wars/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-442-raft-wars-2",
    "title": "Raft Wars 2",
    "thumbnail": "https://truffled.lol/png/games/raft2.webp",
    "embedUrl": "https://truffled.lol/games/raft-wars-2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-443-raft-webport",
    "title": "RAFT, Webport",
    "thumbnail": "https://truffled.lol/png/games/raft.webp",
    "embedUrl": "https://truffled.lol/games/raft/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-444-ragdoll-archers",
    "title": "Ragdoll Archers",
    "thumbnail": "https://truffled.lol/png/games/archer.webp",
    "embedUrl": "https://truffled.lol/games/ragdoll-archers/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-445-ragdoll-hit",
    "title": "Ragdoll Hit",
    "thumbnail": "https://truffled.lol/png/games/hit.webp",
    "embedUrl": "https://truffled.lol/games/ragdoll/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-446-rain-world-webport",
    "title": "Rain World, Webport",
    "thumbnail": "https://truffled.lol/png/games/rainworld.webp",
    "embedUrl": "https://truffled.lol/games/RainWorld/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-447-raldi-s-crack-house",
    "title": "Raldi's Crack House",
    "thumbnail": "https://truffled.lol/png/games/raldi.webp",
    "embedUrl": "https://truffled.lol/games/raldi/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-448-rayman",
    "title": "Rayman",
    "thumbnail": "https://truffled.lol/png/games/rayman.webp",
    "embedUrl": "https://truffled.lol/gamefile/rayman.html",
    "type": "iframe"
  },
  {
    "id": "truffled-449-repo-webport",
    "title": "REPO, Webport",
    "thumbnail": "https://truffled.lol/png/games/repo.webp",
    "embedUrl": "https://truffled.lol/games/repo/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-450-re-run-webport",
    "title": "RE:RUN, Webport",
    "thumbnail": "https://truffled.lol/png/games/rerun.webp",
    "embedUrl": "https://truffled.lol/games/rerun/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-451-resident-evil-1",
    "title": "Resident Evil 1",
    "thumbnail": "https://truffled.lol/png/games/res1.webp",
    "embedUrl": "https://truffled.lol/gamefile/res1.html",
    "type": "iframe"
  },
  {
    "id": "truffled-452-resident-evil-2",
    "title": "Resident Evil 2",
    "thumbnail": "https://truffled.lol/png/games/res2.webp",
    "embedUrl": "https://truffled.lol/gamefile/res2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-453-retro-bowl",
    "title": "Retro Bowl",
    "thumbnail": "https://truffled.lol/png/games/retro.webp",
    "embedUrl": "https://truffled.lol/games/retro-bowl/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-454-retro-bowl-college",
    "title": "Retro Bowl College",
    "thumbnail": "https://truffled.lol/png/games/retroc.webp",
    "embedUrl": "https://truffled.lol/games/rbcollege/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-455-rhythm-heaven",
    "title": "Rhythm Heaven",
    "thumbnail": "https://truffled.lol/png/games/rhythm.webp",
    "embedUrl": "https://truffled.lol/gamefile/rhythm.html",
    "type": "iframe"
  },
  {
    "id": "truffled-456-rhythm-hell",
    "title": "Rhythm Hell",
    "thumbnail": "https://truffled.lol/png/games/rhythmhell.webp",
    "embedUrl": "https://truffled.lol/games/rhythm-hell/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-457-riddle-school",
    "title": "Riddle School",
    "thumbnail": "https://truffled.lol/png/games/riddle1.webp",
    "embedUrl": "https://truffled.lol/games/riddleschool/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-458-riddle-school-2",
    "title": "Riddle School 2",
    "thumbnail": "https://truffled.lol/png/games/riddle2.webp",
    "embedUrl": "https://truffled.lol/games/sriddleschool2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-459-riddle-school-3",
    "title": "Riddle School 3",
    "thumbnail": "https://truffled.lol/png/games/riddle3.webp",
    "embedUrl": "https://truffled.lol/games/riddleschool3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-460-riddle-school-4",
    "title": "Riddle School 4",
    "thumbnail": "https://truffled.lol/png/games/riddle4.webp",
    "embedUrl": "https://truffled.lol/games/riddleschool4/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-461-riddle-school-5",
    "title": "Riddle School 5",
    "thumbnail": "https://truffled.lol/png/games/riddle5.webp",
    "embedUrl": "https://truffled.lol/games/riddleschool5/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-462-riddle-school-transfer",
    "title": "Riddle School Transfer",
    "thumbnail": "https://truffled.lol/png/games/riddletr.webp",
    "embedUrl": "https://truffled.lol/games/riddleschooltransfer/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-463-riddle-school-transfer-2",
    "title": "Riddle School Transfer 2",
    "thumbnail": "https://truffled.lol/png/games/riddletr2.webp",
    "embedUrl": "https://truffled.lol/games/riddleschooltransfer2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-464-rimworld-webport",
    "title": "Rimworld, Webport",
    "thumbnail": "https://truffled.lol/png/games/rimword.webp",
    "embedUrl": "https://truffled.lol/games/rimworld/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-465-roblox",
    "title": "Roblox",
    "thumbnail": "https://truffled.lol/png/games/roblox.webp",
    "embedUrl": "https://nowgg.fun/apps/a/19900/b.html",
    "type": "iframe"
  },
  {
    "id": "truffled-466-rocket-league-sideswipe",
    "title": "Rocket League Sideswipe",
    "thumbnail": "https://truffled.lol/png/games/rrs.webp",
    "embedUrl": "https://nowgg.fun/apps/psyonix-studios/4656/rocket-league.html",
    "type": "iframe"
  },
  {
    "id": "truffled-467-rooftop-snipers",
    "title": "Rooftop Snipers",
    "thumbnail": "https://truffled.lol/png/games/roof2.webp",
    "embedUrl": "https://truffled.lol/games/rooftop-snipers/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-468-rooftop-snipers-2",
    "title": "Rooftop Snipers 2",
    "thumbnail": "https://truffled.lol/png/games/roof1.webp",
    "embedUrl": "https://truffled.lol/games/rooftop-snipers-2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-469-rounds-webport",
    "title": "ROUNDS, Webport",
    "thumbnail": "https://truffled.lol/png/games/rounds.webp",
    "embedUrl": "https://truffled.lol/games/rounds/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-470-run",
    "title": "Run",
    "thumbnail": "https://truffled.lol/png/games/run1.webp",
    "embedUrl": "https://truffled.lol/gamefile/run.html",
    "type": "iframe"
  },
  {
    "id": "truffled-471-run-2",
    "title": "Run 2",
    "thumbnail": "https://truffled.lol/png/games/run2.webp",
    "embedUrl": "https://truffled.lol/gamefile/run2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-472-run-3",
    "title": "Run 3",
    "thumbnail": "https://truffled.lol/png/games/run3.webp",
    "embedUrl": "https://truffled.lol/gamefile/run3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-473-running-fred-webport",
    "title": "Running Fred, Webport",
    "thumbnail": "https://truffled.lol/png/games/fred.webp",
    "embedUrl": "https://truffled.lol/games/fred/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-474-saihate-station-webport",
    "title": "Saihate Station, Webport",
    "thumbnail": "https://truffled.lol/png/games/saihatestation.webp",
    "embedUrl": "https://truffled.lol/gamefile/saihatestation.html",
    "type": "iframe"
  },
  {
    "id": "truffled-475-sandboxels",
    "title": "Sandboxels",
    "thumbnail": "https://truffled.lol/png/games/sand.webp",
    "embedUrl": "https://truffled.lol/gamefile/Sandboxels.html",
    "type": "iframe"
  },
  {
    "id": "truffled-476-sanic-ball-webport",
    "title": "Sanic Ball, Webport",
    "thumbnail": "https://truffled.lol/png/games/sanicball.webp",
    "embedUrl": "https://truffled.lol/games/ball/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-477-scary-path",
    "title": "Scary Path",
    "thumbnail": "https://truffled.lol/png/games/path.webp",
    "embedUrl": "https://truffled.lol/games/scary-path/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-478-scary-teacher-3d",
    "title": "Scary Teacher 3D",
    "thumbnail": "https://truffled.lol/png/games/scary.webp",
    "embedUrl": "https://truffled.lol/gamefile/scary.html",
    "type": "iframe"
  },
  {
    "id": "truffled-479-schoolboy-runaway-webport",
    "title": "Schoolboy Runaway, Webport",
    "thumbnail": "https://truffled.lol/png/games/runaway.webp",
    "embedUrl": "https://truffled.lol/gamefile/runaway.html",
    "type": "iframe"
  },
  {
    "id": "truffled-480-scp-secret-laboratory-webport",
    "title": "SCP: Secret Laboratory, Webport",
    "thumbnail": "https://truffled.lol/png/games/scp.webp",
    "embedUrl": "https://truffled.lol/games/scp/scp.html",
    "type": "iframe"
  },
  {
    "id": "truffled-481-shift-at-midnight-webport",
    "title": "Shift At Midnight, Webport",
    "thumbnail": "https://truffled.lol/png/games/shift.webp",
    "embedUrl": "https://truffled.lol/gamefile/shift.html",
    "type": "iframe"
  },
  {
    "id": "truffled-482-shrimp-io-webport",
    "title": "Shrimp.io, Webport",
    "thumbnail": "https://truffled.lol/png/games/shrimpio.webp",
    "embedUrl": "https://truffled.lol/games/shrimpio/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-483-silksong-webport",
    "title": "Silksong, Webport",
    "thumbnail": "https://truffled.lol/png/games/silk.webp",
    "embedUrl": "https://truffled.lol/games/silk/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-484-skibidi-shooter",
    "title": "Skibidi Shooter",
    "thumbnail": "https://truffled.lol/png/games/ski.webp",
    "embedUrl": "https://truffled.lol/games/skibidi-shooter/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-485-skiing-fred",
    "title": "Skiing Fred",
    "thumbnail": "https://truffled.lol/png/games/skiing.webp",
    "embedUrl": "https://truffled.lol/games/skiing/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-486-skribbl-io",
    "title": "Skribbl.io",
    "thumbnail": "https://truffled.lol/png/games/skribblio.webp",
    "embedUrl": "https://skribbl.io/",
    "type": "iframe"
  },
  {
    "id": "truffled-487-slay-the-spire-webport",
    "title": "Slay The Spire, Webport",
    "thumbnail": "https://truffled.lol/png/games/sts.webp",
    "embedUrl": "https://truffled.lol/games/sts/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-488-slender-the-8-pages-webport",
    "title": "Slender: The 8 Pages, Webport",
    "thumbnail": "https://truffled.lol/png/games/slender.webp",
    "embedUrl": "https://truffled.lol/games/slender/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-489-slendytubbies-ii-2d-webport",
    "title": "Slendytubbies II 2D, Webport",
    "thumbnail": "https://truffled.lol/png/games/slendy2d.webp",
    "embedUrl": "https://truffled.lol/games/slendy2d/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-490-slendytubbies-ii-webport",
    "title": "Slendytubbies II, Webport",
    "thumbnail": "https://truffled.lol/png/games/slendy.webp",
    "embedUrl": "https://truffled.lol/games/slendy/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-491-slendytubbies-i-webport",
    "title": "Slendytubbies I, Webport",
    "thumbnail": "https://truffled.lol/png/games/slendy1.webp",
    "embedUrl": "https://truffled.lol/gamefile/slendy1.html",
    "type": "iframe"
  },
  {
    "id": "truffled-492-slient-hill",
    "title": "Slient Hill",
    "thumbnail": "https://truffled.lol/png/games/slienthill.webp",
    "embedUrl": "https://truffled.lol/gamefile/slienthill.html",
    "type": "iframe"
  },
  {
    "id": "truffled-493-slime-ranchers-webport",
    "title": "Slime Ranchers, Webport",
    "thumbnail": "https://truffled.lol/png/games/slime.webp",
    "embedUrl": "https://truffled.lol/gamefile/slimeranchers.html",
    "type": "iframe"
  },
  {
    "id": "truffled-494-slither-io-webport",
    "title": "Slither.io, Webport",
    "thumbnail": "https://truffled.lol/png/games/sli.webp",
    "embedUrl": "https://truffled.lol/gamefile/sfge.html",
    "type": "iframe"
  },
  {
    "id": "truffled-495-slope",
    "title": "Slope",
    "thumbnail": "https://truffled.lol/png/games/slope.webp",
    "embedUrl": "https://truffled.lol/games/slope/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-496-slowroads",
    "title": "Slowroads",
    "thumbnail": "https://truffled.lol/png/games/slow.webp",
    "embedUrl": "https://truffled.lol/games/slowroads/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-497-smash-karts",
    "title": "Smash Karts",
    "thumbnail": "https://truffled.lol/png/games/smashkarts.webp",
    "embedUrl": "https://truffled.lol/games/smashkarts/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-498-snow-battle",
    "title": "Snow Battle",
    "thumbnail": "https://truffled.lol/png/games/snowio.webp",
    "embedUrl": "https://truffled.lol/gamefile/snow.html",
    "type": "iframe"
  },
  {
    "id": "truffled-499-snow-rider-3d",
    "title": "Snow Rider 3D",
    "thumbnail": "https://truffled.lol/png/games/snow.webp",
    "embedUrl": "https://truffled.lol/games/snowrider3D-main/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-500-soccer-bros",
    "title": "Soccer Bros",
    "thumbnail": "https://truffled.lol/png/games/soccer.webp",
    "embedUrl": "https://truffled.lol/games/soccerbros/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-501-soccer-random",
    "title": "Soccer Random",
    "thumbnail": "https://truffled.lol/png/games/soccerra.webp",
    "embedUrl": "https://truffled.lol/games/soccer-random/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-502-solar-smash",
    "title": "Solar Smash",
    "thumbnail": "https://truffled.lol/png/games/solar.webp",
    "embedUrl": "https://truffled.lol/gamefile/solar.html",
    "type": "iframe"
  },
  {
    "id": "truffled-503-solitaire",
    "title": "Solitaire",
    "thumbnail": "https://truffled.lol/png/games/soli.webp",
    "embedUrl": "https://truffled.lol/games/solitaire/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-504-sonic-1",
    "title": "Sonic 1",
    "thumbnail": "https://truffled.lol/png/games/sonic1.webp",
    "embedUrl": "https://truffled.lol/games/sonic/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-505-sonic-2",
    "title": "Sonic 2",
    "thumbnail": "https://truffled.lol/png/games/sonic2.webp",
    "embedUrl": "https://truffled.lol/games/sonic2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-506-sonic-3",
    "title": "Sonic 3",
    "thumbnail": "https://truffled.lol/png/games/sonic3.webp",
    "embedUrl": "https://truffled.lol/games/sonic3/sonic3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-507-sonic-3d-blast",
    "title": "Sonic 3D Blast",
    "thumbnail": "https://truffled.lol/png/games/sonic3dblast.webp",
    "embedUrl": "https://truffled.lol/gamefile/sonic3dblast.html",
    "type": "iframe"
  },
  {
    "id": "truffled-508-sonic-4",
    "title": "Sonic 4",
    "thumbnail": "https://truffled.lol/png/games/sonic4.webp",
    "embedUrl": "https://truffled.lol/games/sonic4/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-509-sonic-cd",
    "title": "Sonic CD",
    "thumbnail": "https://truffled.lol/png/games/soniccd.webp",
    "embedUrl": "https://truffled.lol/games/soniccd/soniccd.html",
    "type": "iframe"
  },
  {
    "id": "truffled-510-sonic-exe",
    "title": "Sonic EXE",
    "thumbnail": "https://truffled.lol/png/games/sonicexe.webp",
    "embedUrl": "https://truffled.lol/gamefile/sonicexe.html",
    "type": "iframe"
  },
  {
    "id": "truffled-511-sonic-jam",
    "title": "Sonic Jam",
    "thumbnail": "https://truffled.lol/png/games/sonicjam.webp",
    "embedUrl": "https://truffled.lol/gamefile/sonicjam.html",
    "type": "iframe"
  },
  {
    "id": "truffled-512-sonic-mania-webport",
    "title": "Sonic Mania, Webport",
    "thumbnail": "https://truffled.lol/png/games/mania.webp",
    "embedUrl": "https://truffled.lol/gamefile/sonic.html",
    "type": "iframe"
  },
  {
    "id": "truffled-513-sonic-r",
    "title": "Sonic R",
    "thumbnail": "https://truffled.lol/png/games/sonicr.webp",
    "embedUrl": "https://truffled.lol/gamefile/sonicr.html",
    "type": "iframe"
  },
  {
    "id": "truffled-514-sonic-robo-blast-2",
    "title": "Sonic Robo Blast 2",
    "thumbnail": "https://truffled.lol/png/games/robo.webp",
    "embedUrl": "https://truffled.lol/games/srb2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-515-sonic-robo-blast-2-kart",
    "title": "Sonic Robo Blast 2 KART",
    "thumbnail": "https://truffled.lol/png/games/kart.webp",
    "embedUrl": "https://truffled.lol/games/kart/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-516-sonic-world-next",
    "title": "Sonic World Next",
    "thumbnail": "https://truffled.lol/png/games/swn.webp",
    "embedUrl": "https://truffled.lol/games/swn/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-517-spaceflight-simulator-webport",
    "title": "Spaceflight Simulator, Webport",
    "thumbnail": "https://truffled.lol/png/games/ssim.webp",
    "embedUrl": "https://truffled.lol/games/spaceflightsim/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-518-space-waves",
    "title": "Space Waves",
    "thumbnail": "https://truffled.lol/png/games/space.webp",
    "embedUrl": "https://truffled.lol/gamefile/spacewaves.html",
    "type": "iframe"
  },
  {
    "id": "truffled-519-spank-the-monkey-bogs-favorites",
    "title": "Spank the monkey, bogs favorites",
    "thumbnail": "https://truffled.lol/png/games/monk.webp",
    "embedUrl": "https://truffled.lol/gamefile/monkey.html",
    "type": "iframe"
  },
  {
    "id": "truffled-520-speed-stars",
    "title": "Speed Stars",
    "thumbnail": "https://truffled.lol/png/games/speed.webp",
    "embedUrl": "https://truffled.lol/games/speed-stars/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-521-spelunky-classic-hd",
    "title": "Spelunky Classic HD",
    "thumbnail": "https://truffled.lol/png/games/spelunkyclassic.webp",
    "embedUrl": "https://truffled.lol/gamefile/spelunky.html",
    "type": "iframe"
  },
  {
    "id": "truffled-522-starbound-webport",
    "title": "Starbound, Webport",
    "thumbnail": "https://truffled.lol/png/games/starbound.webp",
    "embedUrl": "https://truffled.lol/games/Starbound/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-523-stardew-valley-webport",
    "title": "Stardew Valley, Webport",
    "thumbnail": "https://truffled.lol/png/games/stardew.webp",
    "embedUrl": "https://truffled.lol/games/stardew/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-524-stickman-hook",
    "title": "Stickman Hook",
    "thumbnail": "https://truffled.lol/png/games/stickman.webp",
    "embedUrl": "https://truffled.lol/games/stickman-hook/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-525-stick-war-legacy",
    "title": "Stick War: Legacy",
    "thumbnail": "https://truffled.lol/png/games/stickwar.webp",
    "embedUrl": "https://truffled.lol/gamefile/stickwar.html",
    "type": "iframe"
  },
  {
    "id": "truffled-526-stick-with-it-webport",
    "title": "Stick With It, Webport",
    "thumbnail": "https://truffled.lol/png/games/stick.webp",
    "embedUrl": "https://truffled.lol/games/stick/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-527-stumble-guys",
    "title": "Stumble Guys",
    "thumbnail": "https://truffled.lol/png/games/stumbleguys.webp",
    "embedUrl": "https://nowgg.fun/apps/a/10011/b.html",
    "type": "iframe"
  },
  {
    "id": "truffled-528-subway-surfers",
    "title": "Subway Surfers",
    "thumbnail": "https://truffled.lol/png/games/sub.webp",
    "embedUrl": "https://truffled.lol/games/subway-surfers/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-529-super-flight-webport",
    "title": "Super Flight, Webport",
    "thumbnail": "https://truffled.lol/png/games/superflight.webp",
    "embedUrl": "https://truffled.lol/games/superflight/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-530-super-hot",
    "title": "Super Hot",
    "thumbnail": "https://truffled.lol/png/games/superhot.webp",
    "embedUrl": "https://truffled.lol/games/superhot/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-531-super-mario-64-sm64",
    "title": "Super Mario 64, SM64",
    "thumbnail": "https://truffled.lol/png/games/sm64.webp",
    "embedUrl": "https://truffled.lol/games/sm64/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-532-super-mario-64-coop-dx",
    "title": "Super Mario 64 Coop DX",
    "thumbnail": "https://truffled.lol/png/games/sm64coop.avif",
    "embedUrl": "https://truffled.lol/games/sm64coop/sm64coopdx.html",
    "type": "iframe"
  },
  {
    "id": "truffled-533-super-mario-bros",
    "title": "Super Mario Bros",
    "thumbnail": "https://truffled.lol/png/games/smb.webp",
    "embedUrl": "https://truffled.lol/gamefile/smb.html",
    "type": "iframe"
  },
  {
    "id": "truffled-534-super-mario-galaxy",
    "title": "Super Mario Galaxy",
    "thumbnail": "https://truffled.lol/png/games/smg.webp",
    "embedUrl": "https://truffled.lol/games/smg/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-535-super-mario-galaxy-ds",
    "title": "Super Mario Galaxy DS",
    "thumbnail": "https://truffled.lol/png/games/smgds.webp",
    "embedUrl": "https://truffled.lol/gamefile/smgds.html",
    "type": "iframe"
  },
  {
    "id": "truffled-536-super-mario-sunshine-webport",
    "title": "Super Mario Sunshine, Webport",
    "thumbnail": "https://truffled.lol/png/games/sms.webp",
    "embedUrl": "https://truffled.lol/games/sms/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-537-super-meat-boy",
    "title": "Super Meat Boy",
    "thumbnail": "https://truffled.lol/png/games/meat.webp",
    "embedUrl": "https://truffled.lol/games/meatboy/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-538-super-monkey-ball-1-2",
    "title": "Super Monkey Ball 1 & 2",
    "thumbnail": "https://truffled.lol/png/games/monkb.webp",
    "embedUrl": "https://truffled.lol/gamefile/monk.html",
    "type": "iframe"
  },
  {
    "id": "truffled-539-super-monkey-ball-jr",
    "title": "Super Monkey Ball JR",
    "thumbnail": "https://truffled.lol/png/games/supermonkey.webp",
    "embedUrl": "https://truffled.lol/gamefile/supermonkey.html",
    "type": "iframe"
  },
  {
    "id": "truffled-540-super-oliver-world",
    "title": "Super Oliver World",
    "thumbnail": "https://truffled.lol/png/games/superoliverworld.webp",
    "embedUrl": "https://truffled.lol/gamefile/superoliverworld.html",
    "type": "iframe"
  },
  {
    "id": "truffled-541-super-smash-bros",
    "title": "Super Smash Bros",
    "thumbnail": "https://truffled.lol/png/games/ssm.webp",
    "embedUrl": "https://truffled.lol/gamefile/ssm.html",
    "type": "iframe"
  },
  {
    "id": "truffled-542-super-smash-flash",
    "title": "Super Smash Flash",
    "thumbnail": "https://truffled.lol/png/games/supersmash.webp",
    "embedUrl": "https://truffled.lol/gamefile/ssf.html",
    "type": "iframe"
  },
  {
    "id": "truffled-543-super-smash-flash-2",
    "title": "Super Smash Flash 2",
    "thumbnail": "https://truffled.lol/png/games/ssf2.webp",
    "embedUrl": "https://truffled.lol/gamefile/ssf2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-544-super-tux-kart",
    "title": "Super Tux Kart",
    "thumbnail": "https://truffled.lol/png/games/supertuxkart.webp",
    "embedUrl": "https://truffled.lol/games/supertuxkart/SuperTuxKart.html",
    "type": "iframe"
  },
  {
    "id": "truffled-545-survivor-io-webport",
    "title": "Survivor.io, Webport",
    "thumbnail": "https://truffled.lol/png/games/survivorio.webp",
    "embedUrl": "https://truffled.lol/gamefile/survivor.html",
    "type": "iframe"
  },
  {
    "id": "truffled-546-taiko-no-tatsujini",
    "title": "Taiko No Tatsujini",
    "thumbnail": "https://truffled.lol/png/games/taiko.webp",
    "embedUrl": "https://truffled.lol/games/psp/tja/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-547-tanuki-sunset",
    "title": "Tanuki Sunset",
    "thumbnail": "https://truffled.lol/png/games/tanukisunset.webp",
    "embedUrl": "https://truffled.lol/games/tanukisunset/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-548-tattle-tail-webport",
    "title": "Tattle Tail, Webport",
    "thumbnail": "https://truffled.lol/png/games/tat.webp",
    "embedUrl": "https://truffled.lol/games/tattletail/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-549-tax-heaven-3000-webport",
    "title": "Tax Heaven 3000, Webport",
    "thumbnail": "https://truffled.lol/png/games/th3000.webp",
    "embedUrl": "https://truffled.lol/games/th3000/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-550-team-fortress-2-webport",
    "title": "Team Fortress 2, Webport",
    "thumbnail": "https://truffled.lol/png/games/tf2.webp",
    "embedUrl": "https://truffled.lol/games/tf2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-551-ten-basket",
    "title": "Ten Basket",
    "thumbnail": "https://truffled.lol/png/games/ten.webp",
    "embedUrl": "https://truffled.lol/games/ten-basket/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-552-terraria-webport",
    "title": "Terraria, Webport",
    "thumbnail": "https://truffled.lol/png/games/ter.webp",
    "embedUrl": "https://truffled.lol/games/terraria/terraria-wrapper.html",
    "type": "iframe"
  },
  {
    "id": "truffled-553-tetris",
    "title": "Tetris",
    "thumbnail": "https://truffled.lol/png/games/tet.webp",
    "embedUrl": "https://truffled.lol/games/tetris/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-554-tetrisweeper",
    "title": "Tetrisweeper",
    "thumbnail": "https://truffled.lol/png/games/tetriss.webp",
    "embedUrl": "https://truffled.lol/games/tetrisweeper/",
    "type": "iframe"
  },
  {
    "id": "truffled-555-thats-not-my-neighbor-webport",
    "title": "Thats Not My Neighbor, Webport",
    "thumbnail": "https://truffled.lol/png/games/thatsnot.webp",
    "embedUrl": "https://truffled.lol/gamefile/thatsnot.html",
    "type": "iframe"
  },
  {
    "id": "truffled-556-the-binding-of-isaac-wrath-of-the-lamb",
    "title": "The Binding Of Isaac Wrath Of The Lamb",
    "thumbnail": "https://truffled.lol/png/games/tboiw.webp",
    "embedUrl": "https://truffled.lol/gamefile/tboiw.html",
    "type": "iframe"
  },
  {
    "id": "truffled-557-the-binding-of-isaac-wrath-of-the-lamb-eternal",
    "title": "The Binding Of Isaac Wrath Of The Lamb: Eternal",
    "thumbnail": "https://truffled.lol/png/games/boilambeternal.webp",
    "embedUrl": "https://truffled.lol/gamefile/boilambeternal.html",
    "type": "iframe"
  },
  {
    "id": "truffled-558-the-binding-of-issac",
    "title": "The Binding Of Issac",
    "thumbnail": "https://truffled.lol/png/games/tboi.webp",
    "embedUrl": "https://truffled.lol/games/binding-of-isaac/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-559-the-binding-of-issac-rebirth-webport",
    "title": "The Binding Of Issac: Rebirth, Webport",
    "thumbnail": "https://truffled.lol/png/games/tboir.webp",
    "embedUrl": "https://truffled.lol/games/psp/tboir/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-560-the-binding-of-issac-repentance-webport",
    "title": "The Binding Of Issac: Repentance, Webport",
    "thumbnail": "https://truffled.lol/png/games/boir.webp",
    "embedUrl": "https://truffled.lol/games/boi/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-561-the-impossible-quiz",
    "title": "The Impossible Quiz",
    "thumbnail": "https://truffled.lol/png/games/quiz.webp",
    "embedUrl": "https://truffled.lol/games/theimpossiblequiz/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-562-the-impossible-quiz-2",
    "title": "The Impossible Quiz 2",
    "thumbnail": "https://truffled.lol/png/games/impos2.webp",
    "embedUrl": "https://truffled.lol/games/iq2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-563-the-legend-of-zelda-ocarina-of-time",
    "title": "The Legend of Zelda Ocarina of Time",
    "thumbnail": "https://truffled.lol/png/games/tloz.webp",
    "embedUrl": "https://truffled.lol/gamefile/tloz.html",
    "type": "iframe"
  },
  {
    "id": "truffled-564-the-legend-of-zelda-twilight-princess",
    "title": "The Legend of Zelda: Twilight Princess",
    "thumbnail": "https://truffled.lol/png/games/tpdusk.webp",
    "embedUrl": "https://truffled.lol/games/dusk/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-565-there-is-no-game",
    "title": "There Is No Game",
    "thumbnail": "https://truffled.lol/png/games/ting.webp",
    "embedUrl": "https://truffled.lol/games/there-is-no-game/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-566-the-sims-mobile",
    "title": "The Sims Mobile",
    "thumbnail": "https://truffled.lol/png/games/simsmobile.webp",
    "embedUrl": "https://nowgg.fun/apps/electronic-arts/2155/the-sims-mobile.html",
    "type": "iframe"
  },
  {
    "id": "truffled-567-time-shooter-1",
    "title": "Time Shooter 1",
    "thumbnail": "https://truffled.lol/png/games/tim1.webp",
    "embedUrl": "https://truffled.lol/gamefile/time1.html",
    "type": "iframe"
  },
  {
    "id": "truffled-568-time-shooter-2",
    "title": "Time Shooter 2",
    "thumbnail": "https://truffled.lol/png/games/tim2.webp",
    "embedUrl": "https://truffled.lol/games/timeshooter2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-569-time-shooter-3",
    "title": "Time Shooter 3",
    "thumbnail": "https://truffled.lol/png/games/tim3.webp",
    "embedUrl": "https://truffled.lol/games/timeshoot3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-570-tiny-fishing",
    "title": "Tiny Fishing",
    "thumbnail": "https://truffled.lol/png/games/tiny.webp",
    "embedUrl": "https://truffled.lol/games/tiny-fishing/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-571-tomb-of-the-mask",
    "title": "Tomb Of The Mask",
    "thumbnail": "https://truffled.lol/png/games/tomb.webp",
    "embedUrl": "https://truffled.lol/games/tombofthemask/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-572-tomodachi-collection",
    "title": "Tomodachi Collection",
    "thumbnail": "https://truffled.lol/png/games/tomo.webp",
    "embedUrl": "https://truffled.lol/gamefile/tomo.html",
    "type": "iframe"
  },
  {
    "id": "truffled-573-toss-the-turtle",
    "title": "Toss The Turtle",
    "thumbnail": "https://truffled.lol/png/games/ttt.webp",
    "embedUrl": "https://truffled.lol/games/tosstheturtle/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-574-totally-acturate-battle-simulator-webport",
    "title": "Totally Acturate Battle Simulator, Webport",
    "thumbnail": "https://truffled.lol/png/games/tabs.webp",
    "embedUrl": "https://truffled.lol/games/tabs/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-575-to-the-core-webport",
    "title": "To The Core, Webport",
    "thumbnail": "https://truffled.lol/png/games/to.webp",
    "embedUrl": "https://truffled.lol/games/tothecore/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-576-touhou-1-touhou-reiiden",
    "title": "Touhou 1 Touhou-Reiiden",
    "thumbnail": "https://truffled.lol/png/games/touhou1.webp",
    "embedUrl": "https://truffled.lol/gamefile/touhou.html",
    "type": "iframe"
  },
  {
    "id": "truffled-577-touhou-2-touhou-fuumaroku",
    "title": "Touhou 2 Touhou-Fuumaroku",
    "thumbnail": "https://truffled.lol/png/games/touhou2.webp",
    "embedUrl": "https://truffled.lol/gamefile/touhou2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-578-touhou-3-touhou-yumejikuu",
    "title": "Touhou 3 Touhou-Yumejikuu",
    "thumbnail": "https://truffled.lol/png/games/touhou3.webp",
    "embedUrl": "https://truffled.lol/gamefile/touhou3.html",
    "type": "iframe"
  },
  {
    "id": "truffled-579-touhou-4-touhou-gensokyou",
    "title": "Touhou 4 Touhou-Gensokyou",
    "thumbnail": "https://truffled.lol/png/games/touhou4.webp",
    "embedUrl": "https://truffled.lol/gamefile/touhou4.html",
    "type": "iframe"
  },
  {
    "id": "truffled-580-touhou-5-touhou-kaikidan",
    "title": "Touhou 5 Touhou-Kaikidan",
    "thumbnail": "https://truffled.lol/png/games/touhou5.webp",
    "embedUrl": "https://truffled.lol/gamefile/touhou5.html",
    "type": "iframe"
  },
  {
    "id": "truffled-581-touhou-mother-webport",
    "title": "Touhou Mother, Webport",
    "thumbnail": "https://truffled.lol/png/games/touhou.webp",
    "embedUrl": "https://truffled.lol/games/touhoumother/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-582-tree-hates-you-webport",
    "title": "Tree Hates You, Webport",
    "thumbnail": "https://truffled.lol/png/games/treehatesyou.webp",
    "embedUrl": "https://truffled.lol/games/treehatesyou/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-583-trombone-champ-webport",
    "title": "Trombone Champ, Webport",
    "thumbnail": "https://truffled.lol/png/games/tchamp.webp",
    "embedUrl": "https://truffled.lol/games/tchamp/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-584-tube-jumpers",
    "title": "Tube Jumpers",
    "thumbnail": "https://truffled.lol/png/games/tube.webp",
    "embedUrl": "https://truffled.lol/gamefile/tube.html",
    "type": "iframe"
  },
  {
    "id": "truffled-585-tung-tung-basics-webport",
    "title": "Tung Tung Basics, Webport",
    "thumbnail": "https://truffled.lol/png/games/tungtungbasics.webp",
    "embedUrl": "https://truffled.lol/games/tungtungbog/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-586-tung-tung-horror",
    "title": "Tung Tung Horror",
    "thumbnail": "https://truffled.lol/png/games/tung.webp",
    "embedUrl": "https://truffled.lol/gamefile/tung.html",
    "type": "iframe"
  },
  {
    "id": "truffled-587-ultrakill-webport",
    "title": "Ultrakill, Webport",
    "thumbnail": "https://truffled.lol/png/games/ultra.webp",
    "embedUrl": "https://truffled.lol/games/thkill/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-588-ultrapool-webport",
    "title": "Ultrapool, Webport",
    "thumbnail": "https://truffled.lol/png/games/ultrapool.webp",
    "embedUrl": "https://truffled.lol/gamefile/ultrapool.html",
    "type": "iframe"
  },
  {
    "id": "truffled-589-um-jammer-lammy",
    "title": "Um Jammer Lammy",
    "thumbnail": "https://truffled.lol/png/games/jammer.webp",
    "embedUrl": "https://truffled.lol/gamefile/jemmer.html",
    "type": "iframe"
  },
  {
    "id": "truffled-590-undertale-10th-anniversary-webport",
    "title": "Undertale 10th Anniversary, Webport",
    "thumbnail": "https://truffled.lol/png/games/undertale10.webp",
    "embedUrl": "https://truffled.lol/games/10th/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-591-undertale-last-breath",
    "title": "Undertale Last Breath",
    "thumbnail": "https://truffled.lol/png/games/udlb.webp",
    "embedUrl": "https://truffled.lol/gamefile/udlb.html",
    "type": "iframe"
  },
  {
    "id": "truffled-592-undertale-webport",
    "title": "Undertale, Webport",
    "thumbnail": "https://truffled.lol/png/games/uertale.webp",
    "embedUrl": "https://truffled.lol/gamefile/undertale.html",
    "type": "iframe"
  },
  {
    "id": "truffled-593-undertale-yellow-webport",
    "title": "Undertale Yellow, Webport",
    "thumbnail": "https://truffled.lol/png/games/udy.webp",
    "embedUrl": "https://truffled.lol/games/uty/play.html",
    "type": "iframe"
  },
  {
    "id": "truffled-594-untitled-goose-game-webport",
    "title": "Untitled Goose Game, Webport",
    "thumbnail": "https://truffled.lol/png/games/untitled.webp",
    "embedUrl": "https://truffled.lol/games/UntitledGooseGameBog/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-595-vampire-survivors-webport",
    "title": "Vampire Survivors, Webport",
    "thumbnail": "https://truffled.lol/png/games/vampire.webp",
    "embedUrl": "https://truffled.lol/games/vampire/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-596-venge-io",
    "title": "Venge.io",
    "thumbnail": "https://truffled.lol/png/games/vengoio.webp",
    "embedUrl": "https://iogamesio.org/vengeio.embed",
    "type": "iframe"
  },
  {
    "id": "truffled-597-vex",
    "title": "Vex",
    "thumbnail": "https://truffled.lol/png/games/vex.webp",
    "embedUrl": "https://truffled.lol/games/vex/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-598-vex-2",
    "title": "Vex 2",
    "thumbnail": "https://truffled.lol/png/games/vex2.webp",
    "embedUrl": "https://truffled.lol/gamefile/vex2.html",
    "type": "iframe"
  },
  {
    "id": "truffled-599-vex-3",
    "title": "Vex 3",
    "thumbnail": "https://truffled.lol/png/games/vex3.webp",
    "embedUrl": "https://truffled.lol/games/vex3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-600-vex-4",
    "title": "Vex 4",
    "thumbnail": "https://truffled.lol/png/games/vex4.webp",
    "embedUrl": "https://truffled.lol/games/vex4/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-601-vex-5",
    "title": "Vex 5",
    "thumbnail": "https://truffled.lol/png/games/vex5.webp",
    "embedUrl": "https://truffled.lol/games/vex5/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-602-vex-6",
    "title": "Vex 6",
    "thumbnail": "https://truffled.lol/png/games/vex6.webp",
    "embedUrl": "https://truffled.lol/gamefile/vex6.html",
    "type": "iframe"
  },
  {
    "id": "truffled-603-vex-7",
    "title": "Vex 7",
    "thumbnail": "https://truffled.lol/png/games/vex7.webp",
    "embedUrl": "https://truffled.lol/gamefile/vex7.html",
    "type": "iframe"
  },
  {
    "id": "truffled-604-vex-8",
    "title": "Vex 8",
    "thumbnail": "https://truffled.lol/png/games/vex8.webp",
    "embedUrl": "https://truffled.lol/gamefile/vex8.html",
    "type": "iframe"
  },
  {
    "id": "truffled-605-vib-ribbon-webport",
    "title": "Vib-Ribbon, Webport",
    "thumbnail": "https://truffled.lol/png/games/vib.webp",
    "embedUrl": "https://truffled.lol/gamefile/vib.html",
    "type": "iframe"
  },
  {
    "id": "truffled-606-volley-random",
    "title": "Volley Random",
    "thumbnail": "https://truffled.lol/games/volley-random/splash.png",
    "embedUrl": "https://truffled.lol/games/volley-random/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-607-wallkickers-webport",
    "title": "Wallkickers, Webport",
    "thumbnail": "https://truffled.lol/png/games/wallkickers.webp",
    "embedUrl": "https://truffled.lol/games/wallkickers/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-608-warioware-d-i-y",
    "title": "Warioware D.I.Y",
    "thumbnail": "https://truffled.lol/png/games/wariowarediy.webp",
    "embedUrl": "https://truffled.lol/gamefile/wariowarediy.html",
    "type": "iframe"
  },
  {
    "id": "truffled-609-webdashers",
    "title": "Webdashers",
    "thumbnail": "https://truffled.lol/png/games/webdashers.webp",
    "embedUrl": "https://truffled.lol/gamefile/gd.html",
    "type": "iframe"
  },
  {
    "id": "truffled-610-we-become-what-we-behold",
    "title": "We Become What We behold",
    "thumbnail": "https://truffled.lol/png/games/wbwwb.webp",
    "embedUrl": "https://truffled.lol/gamefile/wbwwb.html",
    "type": "iframe"
  },
  {
    "id": "truffled-611-webfishing-webport",
    "title": "Webfishing, Webport",
    "thumbnail": "https://truffled.lol/png/games/web.webp",
    "embedUrl": "https://truffled.lol/games/webfishing/",
    "type": "iframe"
  },
  {
    "id": "truffled-612-who-s-your-daddy-webport",
    "title": "Who's Your Daddy, Webport",
    "thumbnail": "https://truffled.lol/png/games/daddy.webp",
    "embedUrl": "https://truffled.lol/games/whoseyourdaddy/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-613-windowkill-webport",
    "title": "Windowkill, Webport",
    "thumbnail": "https://truffled.lol/png/games/windowkill.webp",
    "embedUrl": "https://truffled.lol/games/windowkill/",
    "type": "iframe"
  },
  {
    "id": "truffled-614-witch-s-heart-webport",
    "title": "Witch's Heart, Webport",
    "thumbnail": "https://truffled.lol/png/games/witches.webp",
    "embedUrl": "https://truffled.lol/gamefile/witches.html",
    "type": "iframe"
  },
  {
    "id": "truffled-615-woody-s-incredible-journey-to-the-escape-from-eternal-terror",
    "title": "Woody's Incredible Journey To The Escape From Eternal Terror",
    "thumbnail": "https://truffled.lol/png/games/WIJ.webp",
    "embedUrl": "https://truffled.lol/games/WIJ/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-616-wordle",
    "title": "Wordle",
    "thumbnail": "https://truffled.lol/png/games/world.webp",
    "embedUrl": "https://truffled.lol/games/wordle-unlimited/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-617-worldbox-sandbox-god-sim",
    "title": "WorldBox - Sandbox God Sim",
    "thumbnail": "https://truffled.lol/png/games/worldboxsandboxgodsim.webp",
    "embedUrl": "https://truffled.lol/games/worldbox/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-618-worlds-hardest-game",
    "title": "Worlds Hardest Game",
    "thumbnail": "https://truffled.lol/png/games/wrdd.webp",
    "embedUrl": "https://truffled.lol/gamefile/twhg.html",
    "type": "iframe"
  },
  {
    "id": "truffled-619-worlds-hardest-game-2",
    "title": "Worlds Hardest Game 2",
    "thumbnail": "https://truffled.lol/games/worlds-hardest-game-2/the-worlds-hardest-game-2.jpg",
    "embedUrl": "https://truffled.lol/games/worlds-hardest-game-2/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-620-worlds-hardest-game-3",
    "title": "Worlds Hardest Game 3",
    "thumbnail": "https://truffled.lol/png/games/3.webp",
    "embedUrl": "https://truffled.lol/games/worlds-hardest-game-3/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-621-worlds-hardest-game-4",
    "title": "Worlds Hardest Game 4",
    "thumbnail": "https://truffled.lol/png/games/whg4.webp",
    "embedUrl": "https://truffled.lol/games/worlds-hardest-game-4/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-622-yandere-simulator-webport",
    "title": "Yandere Simulator, Webport",
    "thumbnail": "https://truffled.lol/png/games/yandere.webp",
    "embedUrl": "https://truffled.lol/gamefile/yandere.html",
    "type": "iframe"
  },
  {
    "id": "truffled-623-yoked",
    "title": "Yoked",
    "thumbnail": "https://truffled.lol/png/games/yoked.webp",
    "embedUrl": "https://truffled.lol/gamefile/yoked.html",
    "type": "iframe"
  },
  {
    "id": "truffled-624-your-only-move-is-hustle-yomi-hustle-webport",
    "title": "Your Only Move Is HUSTLE, YOMI Hustle, Webport",
    "thumbnail": "https://truffled.lol/png/games/YOMI.webp",
    "embedUrl": "https://truffled.lol/games/YOMIHustle/index.html",
    "type": "iframe"
  },
  {
    "id": "truffled-625-yume-nikki-webport",
    "title": "Yume Nikki, Webport",
    "thumbnail": "https://truffled.lol/png/games/yumi.webp",
    "embedUrl": "https://truffled.lol/gamefile/yume.html",
    "type": "iframe"
  },
  {
    "id": "truffled-626-zombs-royale",
    "title": "Zombs Royale",
    "thumbnail": "https://truffled.lol/png/games/zombs.webp",
    "embedUrl": "https://zombsroyale.io/",
    "type": "iframe"
  },
  {
    "id": "truffled-627-zuma",
    "title": "Zuma",
    "thumbnail": "https://truffled.lol/png/games/zuma.webp",
    "embedUrl": "https://truffled.lol/games/zuma/index.html",
    "type": "iframe"
  }
];
