import { Game } from '../types';

let cachedGnMathGames: Game[] | null = null;

const ZONES_URL = 'https://cdn.jsdelivr.net/gh/freebuisness/assets@main/zones.json';
const COVER_URL = 'https://cdn.jsdelivr.net/gh/freebuisness/covers@main';
const HTML_URL = 'https://cdn.jsdelivr.net/gh/freebuisness/html@main';

interface GnZone {
  id: number | string;
  name: string;
  cover?: string;
  url: string;
  author?: string;
  authorLink?: string;
}

export async function fetchGnMathGames(): Promise<Game[]> {
  if (cachedGnMathGames && cachedGnMathGames.length > 0) {
    return cachedGnMathGames;
  }

  try {
    const res = await fetch(`${ZONES_URL}?t=${Date.now()}`);
    if (!res.ok) throw new Error('Failed to fetch GN-Math zones');
    const json: GnZone[] = await res.json();

    const games: Game[] = json
      .filter((z) => z.id !== -1 && z.name && !z.name.includes('.gg/')) // Filter out ads
      .map((z) => {
        // Resolve cover URL from GN-Math
        let coverImg = z.cover
          ? z.cover.replace('{COVER_URL}', COVER_URL).replace('{HTML_URL}', HTML_URL)
          : `${COVER_URL}/${z.id}.png`;

        // Clean up any double slashes
        coverImg = coverImg.replace(/([^:]\/)\/+/g, '$1');

        // Resolve game HTML URL
        let gameUrl = (z.url || '')
          .replace('{COVER_URL}', COVER_URL)
          .replace('{HTML_URL}', HTML_URL);
        gameUrl = gameUrl.replace(/([^:]\/)\/+/g, '$1');

        return {
          id: `gn-${z.id}`,
          title: z.name.trim(),
          thumbnail: coverImg,
          embedUrl: gameUrl,
          type: 'iframe'
        };
      });

    // Alphabetical order despite provider
    games.sort((a, b) =>
      a.title.localeCompare(b.title, undefined, { sensitivity: 'base', numeric: true })
    );

    cachedGnMathGames = games;
    return games;
  } catch (err) {
    console.warn('Could not load GN-Math zones:', err);
    return [];
  }
}
