import { Game } from '../types';
import { UGS_GAMES } from './ugsGamesData';

export async function fetchAllUgsGames(): Promise<Game[]> {
  return UGS_GAMES;
}
