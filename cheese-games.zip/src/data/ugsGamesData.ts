import { Game } from "../types";

export const UGS_GAMES: Game[] = [
  {
    "id": "ugs-0-cl1",
    "title": "1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1-cl100roomsofenemies",
    "title": "100 Rooms Of Enemies",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl100RoomsOfEnemies.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2-cl10bullets",
    "title": "10 bullets",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl10bullets.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-3-cl10minutestildawn",
    "title": "10 minutestildawn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl10minutestildawn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-4-cl10morebullets",
    "title": "10 morebullets",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl10morebullets.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-5-cl12minibattles",
    "title": "12 minibattles",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl12minibattles.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-6-cl13bones",
    "title": "13 bones",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl13bones.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-7-cl1on1soccer",
    "title": "1 on 1 soccer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl1on1soccer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-8-cl1v1lol",
    "title": "1 v 1 lol",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl1v1lol.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-9-cl1v1tennis",
    "title": "1 v 1 tennis",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl1v1tennis.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-10-cl2048",
    "title": "2048",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl2048.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-11-cl2048cupcakes",
    "title": "2048 cupcakes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl2048cupcakes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-12-cl20smallmazes",
    "title": "20 smallmazes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl20smallmazes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-13-cl234playergame",
    "title": "234 playergame",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl234playergame.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-14-cl2doom",
    "title": "2 doom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl2doom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-15-cl2dshooting",
    "title": "2 Dshooting",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl2Dshooting.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-16-cl3dash",
    "title": "3 dash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl3dash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-17-cl3dasheditor",
    "title": "3 dasheditor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl3dasheditor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-18-cl3dpinballspacecadet",
    "title": "3 dpinballspacecadet",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl3dpinballspacecadet.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-19-cl3pandas",
    "title": "3 pandas",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl3pandas.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-20-cl3pandasbrazil",
    "title": "3 pandasbrazil",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl3pandasbrazil.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-21-cl3pandasfantasy",
    "title": "3 pandasfantasy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl3pandasfantasy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-22-cl3pandasjapan",
    "title": "3 pandasjapan",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl3pandasjapan.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-23-cl3pandasnight",
    "title": "3 pandasnight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl3pandasnight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-24-cl3slices2",
    "title": "3 slices 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl3slices2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-25-cl40xescape",
    "title": "40 xescape",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl40xescape.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-26-cl4thandgoal",
    "title": "4 thandgoal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl4thandgoal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-27-cl500calibercontractz",
    "title": "500 calibercontractz",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl500calibercontractz.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-28-cl60secondsburgerrun",
    "title": "60 secondsburgerrun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl60secondsburgerrun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-29-cl60secondssantarun",
    "title": "60 secondssantarun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl60secondssantarun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-30-cl64in1nes",
    "title": "64 in 1 nes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl64in1nes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-31-cl8ballclassic",
    "title": "8 ballclassic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl8ballclassic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-32-cl8ballpool",
    "title": "8 ballpool",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl8ballpool.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-33-cl9007199254740992",
    "title": "9007199254740992",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl9007199254740992.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-34-cl90in1nes",
    "title": "90 in 1 nes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl90in1nes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-35-cl99balls",
    "title": "99 balls",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl99balls.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-36-cl99nightsitf",
    "title": "99 nightsitf",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl99nightsitf.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-37-cla-walk-in-the-forest--v10-",
    "title": "A Walk in The Forest (v 10)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clA%20Walk%20in%20The%20Forest%20(v10).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-38-clabandoned3",
    "title": "abandoned 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clabandoned3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-39-clabsolutemadness",
    "title": "absolutemadness",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clabsolutemadness.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-40-clacecombat2",
    "title": "acecombat 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clacecombat2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-41-clacecombat3",
    "title": "acecombat 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clacecombat3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-42-clacegangstertaxi",
    "title": "acegangstertaxi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clacegangstertaxi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-43-clachievementunlocked",
    "title": "achievementunlocked",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clachievementunlocked.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-44-clachievmentunlocked",
    "title": "achievmentunlocked",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clachievmentunlocked.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-45-clachievmentunlocked2",
    "title": "achievmentunlocked 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clachievmentunlocked2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-46-clachievmentunlocked3",
    "title": "achievmentunlocked 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clachievmentunlocked3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-47-clachillies",
    "title": "achillies",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clachillies.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-48-clachillies2",
    "title": "achillies 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clachillies2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-49-clacko-s-mach-bike-challenge--v10-",
    "title": "Acko s Mach Bike Challenge (v 10)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clAcko_s%20Mach%20Bike%20Challenge%20(v10).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-50-cladarkroom",
    "title": "ADark Room",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clADarkRoom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-51-cladatewithdeath",
    "title": "adatewithdeath",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cladatewithdeath.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-52-cladayintheoffice",
    "title": "adayintheoffice",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cladayintheoffice.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-53-cladofai",
    "title": "ADOFAI",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clADOFAI.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-54-cladvancewars",
    "title": "advancewars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cladvancewars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-55-cladvancewars2",
    "title": "advancewars 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cladvancewars2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-56-cladvancewarsdualstrike",
    "title": "advancewarsdualstrike",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cladvancewarsdualstrike.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-57-cladventneon",
    "title": "adventneon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cladventneon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-58-cladventurecapatalist",
    "title": "Adventure Capatalist",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clAdventureCapatalist.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-59-cladventurecapitalist",
    "title": "adventurecapitalist",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cladventurecapitalist.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-60-claflac",
    "title": "aflac",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/claflac.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-61-claftertheweek",
    "title": "aftertheweek",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/claftertheweek.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-62-clagariolite",
    "title": "agariolite",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clagariolite.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-63-clageofwar",
    "title": "ageofwar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clageofwar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-64-clageofwar2",
    "title": "ageofwar 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clageofwar2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-65-clagesofconflict",
    "title": "agesofconflict",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clagesofconflict.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-66-clagesofempire",
    "title": "agesofempire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clagesofempire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-67-clahoysurvival",
    "title": "ahoysurvival",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clahoysurvival.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-68-clai",
    "title": "ai",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clai.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-69-clairlinetycoonidle",
    "title": "airlinetycoonidle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clairlinetycoonidle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-70-clakoopasrevenge",
    "title": "akoopasrevenge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clakoopasrevenge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-71-clakoopasrevenge2",
    "title": "akoopasrevenge 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clakoopasrevenge2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-72-clakumanorgaiden",
    "title": "akumanorgaiden",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clakumanorgaiden.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-73-claladdinsnes",
    "title": "aladdinsnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/claladdinsnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-74-clalexkiddinmiracleworld",
    "title": "alexkiddinmiracleworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clalexkiddinmiracleworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-75-clalienhominid",
    "title": "alienhominid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clalienhominid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-76-clalienhominidgba",
    "title": "alienhominidgba",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clalienhominidgba.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-77-clalienskyinvasion",
    "title": "alienskyinvasion",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clalienskyinvasion.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-78-clalientransporter",
    "title": "alientransporter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clalientransporter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-79-clalienvspredator",
    "title": "alienvspredator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clalienvspredator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-80-clallbossesin1",
    "title": "allbossesin 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clallbossesin1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-81-clallocation",
    "title": "allocation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clallocation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-82-claltered-beast",
    "title": "Altered Beast",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clAltered%20Beast.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-83-clamaze",
    "title": "amaze",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamaze.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-84-clambulencearush",
    "title": "ambulencearush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clambulencearush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-85-clamidstthesky",
    "title": "amidstthesky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamidstthesky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-86-clamigopancho",
    "title": "amigopancho",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamigopancho.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-87-clamigopancho2",
    "title": "amigopancho 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamigopancho2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-88-clamigopancho3",
    "title": "amigopancho 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamigopancho3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-89-clamigopancho4",
    "title": "amigopancho 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamigopancho4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-90-clamigopancho5",
    "title": "amigopancho 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamigopancho5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-91-clamigopancho6",
    "title": "amigopancho 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamigopancho6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-92-clamigopancho7",
    "title": "amigopancho 7",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamigopancho7.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-93-clamongus",
    "title": "amongus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamongus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-94-clamorphous",
    "title": "amorphous",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clamorphous.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-95-clancientsins",
    "title": "ancientsins",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clancientsins.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-96-clanemonesfall",
    "title": "anemonesfall",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clanemonesfall.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-97-clangry-birdsspace",
    "title": "angry-birdsspace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clangry-birdsspace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-98-clangrybirds-space",
    "title": "angrybirds-space",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clangrybirds-space.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-99-clangrybirds",
    "title": "angrybirds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clangrybirds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-100-clangrybirdsshowdown",
    "title": "angrybirdsshowdown",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clangrybirdsshowdown.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-101-clangrybirdsspace",
    "title": "angrybirdsspace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clangrybirdsspace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-102-clanimalcrossingwildworld",
    "title": "animalcrossingwildworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clanimalcrossingwildworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-103-clanimalforestn64",
    "title": "animalforestn 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clanimalforestn64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-104-clannsmb",
    "title": "annsmb",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clannsmb.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-105-clanotherworld",
    "title": "anotherworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clanotherworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-106-clantarttycoon",
    "title": "antarttycoon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clantarttycoon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-107-clantimatterdimensions",
    "title": "antimatterdimensions",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clantimatterdimensions.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-108-clapesvshelium",
    "title": "apesvshelium",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clapesvshelium.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-109-clapotris",
    "title": "apotris",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clapotris.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-110-clappleshooter",
    "title": "appleshooter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clappleshooter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-111-clappleworm",
    "title": "appleworm",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clappleworm.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-112-claquaparkio",
    "title": "aquaparkio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/claquaparkio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-113-clarceuslegend",
    "title": "arceuslegend",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clarceuslegend.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-114-clarcheryworldtour",
    "title": "archeryworldtour",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clarcheryworldtour.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-115-clarchesspelago",
    "title": "archesspelago",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clarchesspelago.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-116-clarena",
    "title": "arena",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clarena.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-117-clarmormayhem2",
    "title": "armormayhem 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clarmormayhem2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-118-clarsonate",
    "title": "arsonate",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clarsonate.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-119-clarthursnightmare",
    "title": "arthursnightmare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clarthursnightmare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-120-clascent",
    "title": "ascent",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clascent.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-121-clasdutydemands",
    "title": "asdutydemands",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clasdutydemands.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-122-clasmallworldcup",
    "title": "asmallworldcup",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clasmallworldcup.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-123-classesmentexaminationque",
    "title": "assesmentexaminationque",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/classesmentexaminationque.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-124-classessmentexamination",
    "title": "assessmentexamination",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/classessmentexamination.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-125-clasteroids",
    "title": "asteroids",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clasteroids.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-126-clasteroidsalt",
    "title": "asteroids ALT",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clasteroidsALT.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-127-clasteroidsarcade",
    "title": "asteroidsarcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clasteroidsarcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-128-clastrosdreamland",
    "title": "Astros Dreamland",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clAstrosDreamland.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-129-clastynax",
    "title": "astynax",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clastynax.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-130-clatariadventure",
    "title": "atariadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clatariadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-131-clattackhole",
    "title": "attackhole",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clattackhole.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-132-clavalanche",
    "title": "avalanche",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clavalanche.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-133-claviamasters",
    "title": "aviamasters",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/claviamasters.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-134-claviamastersbuggy",
    "title": "aviamastersbuggy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/claviamastersbuggy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-135-clawesomepirates",
    "title": "Awesome Pirates",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clAwesomePirates.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-136-clawesomeplanes",
    "title": "awesomeplanes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clawesomeplanes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-137-clawesometanks",
    "title": "awesometanks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clawesometanks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-138-clawesometanks2",
    "title": "awesometanks 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clawesometanks2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-139-claxbattler",
    "title": "axbattler",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/claxbattler.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-140-claxisfootballleague",
    "title": "axisfootballleague",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/claxisfootballleague.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-141-clb3313",
    "title": "B3313",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clB3313.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-142-clb3313unabandoneda2",
    "title": "b 3313 unabandoned A2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clb3313unabandonedA2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-143-clb3313v102",
    "title": "b 3313 v 102",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clb3313v102.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-144-clbabeltower",
    "title": "babeltower",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbabeltower.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-145-clbabychiccoadventure",
    "title": "babychiccoadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbabychiccoadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-146-clbabykaizo",
    "title": "babykaizo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbabykaizo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-147-clbabysniperinvietnam",
    "title": "babysniperinvietnam",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbabysniperinvietnam.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-148-clbackrooms",
    "title": "backrooms",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbackrooms.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-149-clbackrooms2d",
    "title": "backrooms 2 D",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbackrooms2D.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-150-clbackyardbaseball",
    "title": "backyardbaseball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbackyardbaseball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-151-clbackyardbaseball09",
    "title": "backyardbaseball 09",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbackyardbaseball09.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-152-clbackyardbaseball10",
    "title": "backyardbaseball 10",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbackyardbaseball10.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-153-clbackyardfootball",
    "title": "backyardfootball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbackyardfootball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-154-clbackyardsoccer",
    "title": "backyardsoccer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbackyardsoccer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-155-clbaconmaydie",
    "title": "baconmaydie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaconmaydie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-156-clbadbodyguards",
    "title": "badbodyguards",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadbodyguards.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-157-clbadicecream",
    "title": "badicecream",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadicecream.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-158-clbadicecream2",
    "title": "badicecream 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadicecream2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-159-clbadicecream3",
    "title": "badicecream 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadicecream3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-160-clbadmondaysimulator",
    "title": "badmondaysimulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadmondaysimulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-161-clbadparenting",
    "title": "badparenting",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadparenting.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-162-clbadpiggies",
    "title": "badpiggies",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadpiggies.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-163-clbadpiggieslatest",
    "title": "badpiggieslatest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadpiggieslatest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-164-clbadtimesim",
    "title": "badtimesim",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadtimesim.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-165-clbadtimesimulator",
    "title": "badtimesimulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadtimesimulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-166-clbalatrogba",
    "title": "balatrogba",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbalatrogba.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-167-clbaldicaseoh",
    "title": "baldicaseoh",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaldicaseoh.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-168-clbaldidecomp",
    "title": "baldidecomp",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaldidecomp.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-169-clbaldiepstein",
    "title": "baldiepstein",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaldiepstein.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-170-clbaldisbasics",
    "title": "baldisbasics",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaldisbasics.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-171-clbaldisbasicsremaster",
    "title": "baldisbasicsremaster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaldisbasicsremaster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-172-clbaldisfunnewschoolultimate",
    "title": "baldisfunnewschoolultimate",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaldisfunnewschoolultimate.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-173-clballblast",
    "title": "ballblast",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clballblast.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-174-clballistic",
    "title": "ballistic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clballistic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-175-clballsandbricks",
    "title": "ballsandbricks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clballsandbricks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-176-clballsandbricksgood",
    "title": "ballsandbricksgood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clballsandbricksgood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-177-clballz",
    "title": "ballz",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clballz.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-178-clbananasimulator",
    "title": "bananasimulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbananasimulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-179-clbanbuds",
    "title": "banbuds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbanbuds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-180-clbanditgunslingers",
    "title": "banditgunslingers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbanditgunslingers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-181-clbanjokazooie",
    "title": "banjokazooie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbanjokazooie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-182-clbanjotooie",
    "title": "banjotooie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbanjotooie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-183-clbank-robbery",
    "title": "Bank Robbery",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clBank%20Robbery.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-184-clbankbreakout2",
    "title": "bankbreakout 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbankbreakout2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-185-clbankrobbery2",
    "title": "bankrobbery 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbankrobbery2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-186-clbarryhasasecret",
    "title": "barryhasasecret",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbarryhasasecret.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-187-clbartblast",
    "title": "bartblast",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbartblast.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-188-clbas",
    "title": "bas",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbas.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-189-clbaseballbros",
    "title": "baseballbros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaseballbros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-190-clbasketballfrvr",
    "title": "basketballfrvr",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketballfrvr.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-191-clbasketballlegends-1-",
    "title": "basketballlegends(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketballlegends(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-192-clbasketballlegends",
    "title": "basketballlegends",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketballlegends.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-193-clbasketballstars",
    "title": "basketballstars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketballstars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-194-clbasketballsuperstars",
    "title": "basketballsuperstars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketballsuperstars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-195-clbasketbattle",
    "title": "basketbattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketbattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-196-clbasketbros",
    "title": "basketbros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketbros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-197-clbasketrandom",
    "title": "basketrandom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketrandom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-198-clbasketrandomgood",
    "title": "basketrandomgood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketrandomgood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-199-clbasketslamdunk2",
    "title": "basketslamdunk 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbasketslamdunk2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-200-clbatterup",
    "title": "batterup",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbatterup.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-201-clbattlekarts",
    "title": "battlekarts",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbattlekarts.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-202-clbattles",
    "title": "battles",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbattles.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-203-clbattlesim",
    "title": "battlesim",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbattlesim.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-204-clbattlezone",
    "title": "battlezone",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbattlezone.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-205-clbazookaboy",
    "title": "bazookaboy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbazookaboy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-206-clbballlegend",
    "title": "bballlegend",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbballlegend.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-207-clbeachboxingsim",
    "title": "beachboxingsim",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbeachboxingsim.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-208-clbeamrider",
    "title": "beamrider",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbeamrider.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-209-clbearbarians",
    "title": "bearbarians",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbearbarians.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-210-clbearsus",
    "title": "bearsus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbearsus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-211-clbejeweledtwistds",
    "title": "bejeweledtwistds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbejeweledtwistds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-212-clbejeweledtwistflash",
    "title": "bejeweledtwistflash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbejeweledtwistflash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-213-clben10alienforce",
    "title": "ben 10 alienforce",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clben10alienforce.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-214-clben10omniverse",
    "title": "ben 10 omniverse",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clben10omniverse.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-215-clben10protector",
    "title": "ben 10 protector",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clben10protector.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-216-clben10racing",
    "title": "ben 10 racing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clben10racing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-217-clben10ultimatealien",
    "title": "ben 10 ultimatealien",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clben10ultimatealien.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-218-clbendrowned",
    "title": "bendrowned",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbendrowned.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-219-clbergentruck201x",
    "title": "bergentruck 201 x",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbergentruck201x.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-220-clbfdia5b",
    "title": "bfdia 5 b",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbfdia5b.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-221-clbfdibranches",
    "title": "BFDIBranches",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clBFDIBranches.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-222-clbigflappytowertinysquare",
    "title": "bigflappytowertinysquare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbigflappytowertinysquare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-223-clbigicetowertinysquare",
    "title": "bigicetowertinysquare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbigicetowertinysquare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-224-clbigneontowertinysquare",
    "title": "bigneontowertinysquare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbigneontowertinysquare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-225-clbigshotboxing2",
    "title": "bigshotboxing 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbigshotboxing2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-226-clbigtowertinysquare",
    "title": "bigtowertinysquare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbigtowertinysquare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-227-clbigtowertinysquare2",
    "title": "bigtowertinysquare 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbigtowertinysquare2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-228-clbigtowertinysquare2good",
    "title": "bigtowertinysquare 2 good",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbigtowertinysquare2good.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-229-clbig-time-butter-baron",
    "title": "Big Time Butter Baron",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clBig_Time_Butter_Baron.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-230-clbindingofisaccsheeptime",
    "title": "bindingofisaccsheeptime",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbindingofisaccsheeptime.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-231-clbioevil4",
    "title": "bioevil 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbioevil4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-232-clbitlife",
    "title": "bitlife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbitlife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-233-clbitlifeencrypted",
    "title": "bitlifeencrypted",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbitlifeencrypted.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-234-clbitplanes",
    "title": "bitplanes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbitplanes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-235-clblackjack",
    "title": "blackjack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblackjack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-236-clblackjackbattle",
    "title": "blackjackbattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblackjackbattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-237-clblackjackhhhh",
    "title": "blackjackhhhh",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblackjackhhhh.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-238-clblackknight",
    "title": "blackknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblackknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-239-clblackout",
    "title": "blackout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblackout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-240-clblacksmithlab",
    "title": "blacksmithlab",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblacksmithlab.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-241-clblastronaut",
    "title": "blastronaut",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblastronaut.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-242-clblazedrifter",
    "title": "blazedrifter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblazedrifter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-243-clbleachvsnaruto",
    "title": "bleachvsnaruto",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbleachvsnaruto.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-244-clblightborne",
    "title": "blightborne",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblightborne.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-245-clblobsstory2",
    "title": "blobsstory 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblobsstory2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-246-clblockblast",
    "title": "blockblast",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblockblast.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-247-clblockblastv2",
    "title": "blockblastv 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblockblastv2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-248-clblockcraftparkour",
    "title": "blockcraftparkour",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblockcraftparkour.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-249-clblockcraftshooter",
    "title": "blockcraftshooter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblockcraftshooter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-250-clblockpost",
    "title": "blockpost",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblockpost.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-251-clblockthepig",
    "title": "blockthepig",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblockthepig.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-252-clblockydemolitionderby",
    "title": "blockydemolitionderby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblockydemolitionderby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-253-clblockysnakes",
    "title": "blockysnakes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblockysnakes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-254-clblood",
    "title": "blood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-255-clbloodmoney",
    "title": "bloodmoney",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloodmoney.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-256-clbloodtournament",
    "title": "bloodtournament",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloodtournament.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-257-clbloons",
    "title": "bloons",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloons.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-258-clbloons2",
    "title": "bloons 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloons2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-259-clbloonspp1",
    "title": "bloonspp 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonspp1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-260-clbloonspp2",
    "title": "bloonspp 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonspp2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-261-clbloonspp3",
    "title": "bloonspp 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonspp3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-262-clbloonspp4",
    "title": "bloonspp 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonspp4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-263-clbloonspp5",
    "title": "bloonspp 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonspp5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-264-clbloonstd1",
    "title": "bloons TD1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonsTD1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-265-clbloonstd2",
    "title": "bloons TD2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonsTD2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-266-clbloonstd3",
    "title": "bloons TD3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonsTD3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-267-clbloonstd4",
    "title": "bloons TD4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonsTD4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-268-clbloonstd5",
    "title": "bloons TD5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonsTD5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-269-clbloonstd6scratch",
    "title": "bloons TD6 scratch",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloonsTD6scratch.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-270-clbloxorz",
    "title": "bloxorz",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbloxorz.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-271-clblumgiracers",
    "title": "blumgiracers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblumgiracers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-272-clblumgirocket",
    "title": "blumgirocket",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clblumgirocket.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-273-clbmx2",
    "title": "BMX2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clBMX2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-274-clbntts",
    "title": "bntts",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbntts.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-275-clbobasimulator",
    "title": "bobasimulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbobasimulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-276-clbobtherobber",
    "title": "bobtherobber",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbobtherobber.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-277-clbobtherobber2",
    "title": "bobtherobber 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbobtherobber2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-278-clbobtherobber5",
    "title": "bobtherobber 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbobtherobber5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-279-clbollybeat",
    "title": "bollybeat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbollybeat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-280-clbomberman",
    "title": "bomberman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbomberman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-281-clbomberman2",
    "title": "bomberman 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbomberman2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-282-clbombermanhero",
    "title": "bombermanhero",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbombermanhero.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-283-clbombermanworld",
    "title": "bombermanworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbombermanworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-284-clbonanza-bros",
    "title": "Bonanza-Bros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clBonanza-Bros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-285-clbonkerssnes",
    "title": "bonkerssnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbonkerssnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-286-clboomslingers",
    "title": "boomslingers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clboomslingers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-287-clbottlecracks",
    "title": "bottlecracks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbottlecracks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-288-clbottleflip3d",
    "title": "bottleflip 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbottleflip3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-289-clbotwds",
    "title": "botwds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbotwds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-290-clbounceback",
    "title": "bounceback",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbounceback.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-291-clbouncemasters",
    "title": "bouncemasters",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbouncemasters.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-292-clbouncybasketball",
    "title": "bouncybasketball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbouncybasketball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-293-clbouncymotors",
    "title": "bouncymotors",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbouncymotors.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-294-clbountyofone",
    "title": "Bounty Of One",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clBountyOfOne.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-295-clbowlalt",
    "title": "bowlalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbowlalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-296-clbowmaster",
    "title": "bowmaster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbowmaster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-297-clboxhead2playrooms",
    "title": "boxhead 2 playrooms",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clboxhead2playrooms.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-298-clboxheadnightmare",
    "title": "boxheadnightmare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clboxheadnightmare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-299-clboxinglive-2",
    "title": "boxinglive-2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clboxinglive-2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-300-clboxinglive2",
    "title": "boxinglive 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clboxinglive2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-301-clboxingrandom",
    "title": "boxingrandom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clboxingrandom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-302-clbrainrot",
    "title": "brainrot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbrainrot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-303-clbrawlsimulator3d",
    "title": "brawlsimulator 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbrawlsimulator3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-304-clbrawlstars",
    "title": "Brawlstars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clBrawlstars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-305-clbreadskate",
    "title": "breadskate",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbreadskate.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-306-clbridgerace",
    "title": "bridgerace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbridgerace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-307-clbrotato",
    "title": "brotato",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbrotato.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-308-clbtd1",
    "title": "BTD1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clBTD1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-309-clbtd5",
    "title": "btd 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbtd5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-310-clbtts",
    "title": "btts",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbtts.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-311-clbtts2",
    "title": "btts 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbtts2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-312-clbubbleshooter",
    "title": "bubbleshooter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbubbleshooter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-313-clbubbleshooterpirate",
    "title": "bubbleshooterpirate",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbubbleshooterpirate.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-314-clbubbletanks",
    "title": "bubbletanks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbubbletanks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-315-clbubbletanks2",
    "title": "bubbletanks 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbubbletanks2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-316-clbubbletanks3",
    "title": "bubbletanks 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbubbletanks3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-317-clbubbletanksarenas",
    "title": "bubbletanksarenas",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbubbletanksarenas.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-318-clbubbletankstd",
    "title": "bubbletankstd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbubbletankstd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-319-clbubsy",
    "title": "bubsy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbubsy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-320-clbuckshotroulette",
    "title": "buckshotroulette",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbuckshotroulette.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-321-clbuildnowgg",
    "title": "buildnowgg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbuildnowgg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-322-clbulletforce",
    "title": "bulletforce",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbulletforce.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-323-clbunnyland",
    "title": "bunnyland",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbunnyland.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-324-clbunzobunny",
    "title": "bunzobunny",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbunzobunny.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-325-clburgerandfrights",
    "title": "burgerandfrights",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clburgerandfrights.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-326-clburgertime",
    "title": "burgertime",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clburgertime.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-327-clburritobison",
    "title": "burritobison",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clburritobison.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-328-clburritobison2",
    "title": "burritobison 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clburritobison2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-329-clburritobisonlaunchalibre",
    "title": "burritobisonlaunchalibre",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clburritobisonlaunchalibre.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-330-clburritobisonrevenge",
    "title": "burritobisonrevenge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clburritobisonrevenge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-331-clbushidoblade",
    "title": "bushidoblade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbushidoblade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-332-clbusterjam",
    "title": "Buster Jam",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clBusterJam.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-333-clcactusmccoy-1-",
    "title": "cactusmccoy(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcactusmccoy(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-334-clcactusmccoy",
    "title": "cactusmccoy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcactusmccoy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-335-clcactusmccoy2-1-",
    "title": "cactusmccoy 2(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcactusmccoy2(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-336-clcactusmccoy2-2-",
    "title": "cactusmccoy 2(2)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcactusmccoy2(2).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-337-clcactusmccoy2",
    "title": "cactusmccoy 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcactusmccoy2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-338-clcallofbattle",
    "title": "callofbattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcallofbattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-339-clcamilla",
    "title": "camilla",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcamilla.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-340-clcandybox1",
    "title": "candybox 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcandybox1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-341-clcannonballs3d",
    "title": "cannonballs 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcannonballs3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-342-clcannonfodder",
    "title": "cannonfodder",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcannonfodder.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-343-clcaptainlang",
    "title": "captainlang",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcaptainlang.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-344-clcaptchaware",
    "title": "captchaware",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcaptchaware.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-345-clcapybaraclicker",
    "title": "capybaraclicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcapybaraclicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-346-clcarcrash3",
    "title": "carcrash 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcarcrash3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-347-clcardrawing",
    "title": "cardrawing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcardrawing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-348-clcareatscar2deluxe",
    "title": "careatscar 2 deluxe",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcareatscar2deluxe.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-349-clcarkingarena",
    "title": "carkingarena",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcarkingarena.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-350-clcarmods",
    "title": "carmods",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcarmods.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-351-clcarrampvspolicechase",
    "title": "carrampvspolicechase",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcarrampvspolicechase.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-352-clcarstuntsdriving",
    "title": "carstuntsdriving",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcarstuntsdriving.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-353-clcartoonnetworktabletennisultimatetournament",
    "title": "Cartoon Network Table Tennis Ultimate Tournament",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clCartoonNetworkTableTennisUltimateTournament.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-354-clcastaway",
    "title": "castaway",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastaway.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-355-clcastlebloodline",
    "title": "castlebloodline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastlebloodline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-356-clcastlecircleofmoon",
    "title": "castlecircleofmoon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastlecircleofmoon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-357-clcastlevania",
    "title": "castlevania",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastlevania.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-358-clcastlevania2",
    "title": "castlevania 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastlevania2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-359-clcastlevania3",
    "title": "castlevania 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastlevania3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-360-clcastlevaniaariaofsorrow",
    "title": "castlevaniaariaofsorrow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastlevaniaariaofsorrow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-361-clcastlevaniadawnofsorrow",
    "title": "castlevaniadawnofsorrow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastlevaniadawnofsorrow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-362-clcastlevanianes",
    "title": "castlevanianes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastlevanianes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-363-clcastlewarsmodern",
    "title": "castlewarsmodern",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcastlewarsmodern.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-364-clcatmario",
    "title": "catmario",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcatmario.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-365-clcatmariogood",
    "title": "catmariogood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcatmariogood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-366-clcatslovecake2",
    "title": "catslovecake 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcatslovecake2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-367-clcavecrawler",
    "title": "cavecrawler",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcavecrawler.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-368-clcavestory",
    "title": "cavestory",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcavestory.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-369-clceleste",
    "title": "celeste",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clceleste.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-370-clceleste2",
    "title": "celeste 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clceleste2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-371-clcelestemariodx",
    "title": "celestemariodx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcelestemariodx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-372-clceliasstupidromhack",
    "title": "Celias Stupid ROMHack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clCeliasStupidROMHack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-373-clcellardoor",
    "title": "cellardoor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcellardoor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-374-clcelltosingularity",
    "title": "Cell To Singularity",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clCellToSingularity.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-375-clcentipedearcade",
    "title": "centipedearcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcentipedearcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-376-clchainofmemories",
    "title": "chainofmemories",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchainofmemories.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-377-clchaosfaction2",
    "title": "chaosfaction 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchaosfaction2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-378-clcheckers",
    "title": "checkers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcheckers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-379-clcheesechompers3d",
    "title": "cheesechompers 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcheesechompers3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-380-clcheeseisthereason",
    "title": "cheeseisthereason",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcheeseisthereason.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-381-clcheeserolling",
    "title": "cheeserolling",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcheeserolling.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-382-clcheshireinachatroom",
    "title": "cheshireinachatroom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcheshireinachatroom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-383-clchess",
    "title": "chess",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchess.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-384-clchessclassic",
    "title": "chessclassic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchessclassic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-385-clchibiknight",
    "title": "chibiknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchibiknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-386-clchickencs",
    "title": "Chicken CS",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clChickenCS.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-387-clchickenscream",
    "title": "chickenscream",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchickenscream.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-388-clchickenwar",
    "title": "chickenwar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchickenwar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-389-clchipschallenge",
    "title": "chipschallenge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchipschallenge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-390-clchoppyorc",
    "title": "choppyorc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchoppyorc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-391-clchoroqwonderful",
    "title": "choroqwonderful",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchoroqwonderful.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-392-clchronotrigger",
    "title": "chronotrigger",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchronotrigger.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-393-clchuzzle",
    "title": "chuzzle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchuzzle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-394-clcircloo2",
    "title": "Circlo O2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clCircloO2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-395-clciviballs",
    "title": "civiballs",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clciviballs.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-396-clciviballs2",
    "title": "civiballs 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clciviballs2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-397-clclashnslash",
    "title": "clashnslash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclashnslash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-398-clclashofvikings",
    "title": "clashofvikings",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclashofvikings.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-399-clclassof09",
    "title": "classof 09",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclassof09.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-400-clclaymore",
    "title": "claymore",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclaymore.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-401-clclayuncraft",
    "title": "clayuncraft",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclayuncraft.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-402-clcleanupio",
    "title": "cleanupio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcleanupio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-403-clclearvision",
    "title": "clearvision",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclearvision.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-404-clclearvision2",
    "title": "clearvision 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclearvision2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-405-clclearvision3",
    "title": "clearvision 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclearvision3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-406-clclearvision4",
    "title": "clearvision 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclearvision4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-407-clclearvision5",
    "title": "clearvision 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclearvision5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-408-clclimbforbrainrots",
    "title": "climbforbrainrots",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclimbforbrainrots.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-409-clclmadnessambulation",
    "title": "clmadnessambulation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclmadnessambulation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-410-clclover",
    "title": "clover",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclover.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-411-clclubbytheseal",
    "title": "clubbytheseal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclubbytheseal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-412-clclusterrush",
    "title": "clusterrush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclusterrush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-413-clcoalllcdemo",
    "title": "coalllcdemo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoalllcdemo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-414-clcod4",
    "title": "cod 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcod4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-415-clcodblackopp",
    "title": "codblackopp",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcodblackopp.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-416-clcoddefiance",
    "title": "coddefiance",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoddefiance.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-417-clcodenamegordon",
    "title": "codenamegordon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcodenamegordon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-418-clcodeorg",
    "title": "codeorg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcodeorg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-419-clcodeorgbutoffline",
    "title": "codeorgbutoffline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcodeorgbutoffline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-420-clcodercraft",
    "title": "codercraft",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcodercraft.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-421-clcodmodernwarfare",
    "title": "codmodernwarfare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcodmodernwarfare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-422-clcodworldatwar",
    "title": "codworldatwar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcodworldatwar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-423-clcoffeemaker",
    "title": "coffeemaker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoffeemaker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-424-clcoldpines",
    "title": "coldpines",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoldpines.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-425-clcolorburst3d",
    "title": "colorburst 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcolorburst3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-426-clcolormatch",
    "title": "colormatch",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcolormatch.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-427-clcolorwatersort3d",
    "title": "colorwatersort 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcolorwatersort3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-428-clcombopool",
    "title": "combopool",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcombopool.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-429-clcommandandconquer",
    "title": "commandandconquer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcommandandconquer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-430-clcommanderkeen4",
    "title": "commanderkeen 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcommanderkeen4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-431-clcommanderkeen5",
    "title": "commanderkeen 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcommanderkeen5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-432-clcommanderkeen6",
    "title": "commanderkeen 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcommanderkeen6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-433-clconfrontingurself",
    "title": "confrontingurself",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clconfrontingurself.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-434-clconfrontingyourself",
    "title": "confrontingyourself",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clconfrontingyourself.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-435-clconkersbadfurday",
    "title": "conkersbadfurday",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clconkersbadfurday.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-436-clcontra",
    "title": "contra",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcontra.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-437-clcontra3",
    "title": "contra 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcontra3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-438-clcookie-clicker",
    "title": "cookie-clicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcookie-clicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-439-clcookieclicker",
    "title": "cookieclicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcookieclicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-440-clcookieclickercool",
    "title": "cookieclickercool",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcookieclickercool.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-441-clcookieclickergood",
    "title": "cookieclickergood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcookieclickergood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-442-clcookieclickermodmenu",
    "title": "cookieclickermodmenu",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcookieclickermodmenu.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-443-clcookingmama",
    "title": "cookingmama",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcookingmama.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-444-clcookingmama2",
    "title": "cookingmama 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcookingmama2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-445-clcookingmama3",
    "title": "cookingmama 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcookingmama3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-446-clcoreball",
    "title": "coreball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoreball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-447-clcoryinthehouse",
    "title": "coryinthehouse",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoryinthehouse.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-448-clcotlk",
    "title": "cotlk",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcotlk.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-449-clcountmastersstickmangames",
    "title": "countmastersstickmangames",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcountmastersstickmangames.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-450-clcoverorange",
    "title": "coverorange",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorange.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-451-clcoverorange2",
    "title": "coverorange 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorange2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-452-clcoverorangejourneygangsters",
    "title": "coverorangejourneygangsters",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorangejourneygangsters.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-453-clcoverorangejourneyknights",
    "title": "coverorangejourneyknights",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorangejourneyknights.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-454-clcoverorangejourneypirates",
    "title": "coverorangejourneypirates",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorangejourneypirates.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-455-clcoverorangejourneyspace",
    "title": "coverorangejourneyspace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorangejourneyspace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-456-clcoverorangeplayerspack",
    "title": "coverorangeplayerspack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorangeplayerspack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-457-clcoverorangeplayerspack2",
    "title": "coverorangeplayerspack 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorangeplayerspack2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-458-clcoverorangeplayerspack3-1-",
    "title": "coverorangeplayerspack 3(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorangeplayerspack3(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-459-clcoverorangeplayerspack3",
    "title": "coverorangeplayerspack 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorangeplayerspack3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-460-clcrankit-",
    "title": "crankit!",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrankit!.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-461-clcrankit",
    "title": "crankit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrankit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-462-clcrash2",
    "title": "crash 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrash2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-463-clcrash3",
    "title": "crash 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrash3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-464-clcrashbandicoot--1-",
    "title": "crashbandicoot (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrashbandicoot%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-465-clcrashbandicoot",
    "title": "crashbandicoot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrashbandicoot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-466-clcrashbandicoot2",
    "title": "crashbandicoot 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrashbandicoot2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-467-clcrashteamracing",
    "title": "crashteamracing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrashteamracing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-468-clcrazycars",
    "title": "crazycars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrazycars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-469-clcrazycattle3d",
    "title": "crazycattle 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrazycattle3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-470-clcrazychicken3d",
    "title": "crazychicken 3 D",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrazychicken3D.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-471-clcrazyclimber",
    "title": "crazyclimber",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrazyclimber.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-472-clcrazyfrogracer",
    "title": "crazyfrogracer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrazyfrogracer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-473-clcrazymotorcycle",
    "title": "crazymotorcycle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrazymotorcycle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-474-clcrazypenguincatapult",
    "title": "crazypenguincatapult",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrazypenguincatapult.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-475-clcrazyplanelanding",
    "title": "crazyplanelanding",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrazyplanelanding.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-476-clcrazytaxigba",
    "title": "crazytaxigba",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrazytaxigba.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-477-clcreaturecardidle",
    "title": "creaturecardidle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcreaturecardidle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-478-clcreeperworld2",
    "title": "creeperworld 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcreeperworld2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-479-clcreepyinternetstories",
    "title": "creepyinternetstories",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcreepyinternetstories.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-480-clcreepynightfunkin",
    "title": "creepynightfunkin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcreepynightfunkin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-481-clcrimsonmadness",
    "title": "crimsonmadness",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrimsonmadness.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-482-clcrossyroad",
    "title": "crossyroad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrossyroad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-483-clcrunchball3000",
    "title": "crunchball 3000",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrunchball3000.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-484-clcrystalcastles",
    "title": "Crystal Castles",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clCrystalCastles.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-485-clcs16",
    "title": "cs 16",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcs16.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-486-clcs6",
    "title": "cs 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcs6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-487-clcsds",
    "title": "csds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcsds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-488-clcsgoclicker",
    "title": "csgoclicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcsgoclicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-489-clctgpnitro",
    "title": "ctgpnitro",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clctgpnitro.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-490-clcurveball-1-",
    "title": "curveball(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcurveball(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-491-clcurveball",
    "title": "curveball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcurveball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-492-clcustomersupport",
    "title": "customersupport",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcustomersupport.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-493-clcuttherope",
    "title": "cuttherope",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcuttherope.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-494-clcuttheropeholiday",
    "title": "cuttheropeholiday",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcuttheropeholiday.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-495-clcuttheropetimetravel",
    "title": "cuttheropetimetravel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcuttheropetimetravel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-496-clcvooc",
    "title": "cvooc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcvooc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-497-clcyberbungracing",
    "title": "cyberbungracing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcyberbungracing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-498-clcybersensation",
    "title": "cybersensation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcybersensation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-499-cldadgame",
    "title": "dadgame",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldadgame.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-500-cldadish",
    "title": "dadish",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldadish.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-501-cldadnme",
    "title": "dadnme",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldadnme.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-502-cldaggerfall",
    "title": "daggerfall",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldaggerfall.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-503-cldandysworldclicker",
    "title": "dandysworldclicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldandysworldclicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-504-cldanktomb",
    "title": "danktomb",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldanktomb.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-505-cldasharena",
    "title": "dasharena",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldasharena.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-506-cldashio",
    "title": "dashio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldashio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-507-cldashmetry",
    "title": "Dashmetry",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clDashmetry.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-508-cldatewithiraq",
    "title": "datewithiraq",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldatewithiraq.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-509-cldborigins",
    "title": "dborigins",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldborigins.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-510-cldborigins2",
    "title": "dborigins 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldborigins2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-511-cldbsniper",
    "title": "dbsniper",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldbsniper.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-512-cldbzattacksaiyans",
    "title": "dbzattacksaiyans",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldbzattacksaiyans.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-513-cldbzdevolution",
    "title": "dbzdevolution",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldbzdevolution.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-514-cldbzsuperwarriorssonic",
    "title": "dbzsuperwarriorssonic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldbzsuperwarriorssonic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-515-cldbzwarriors2",
    "title": "dbzwarriors 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldbzwarriors2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-516-clddlc64",
    "title": "ddlc 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clddlc64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-517-cldeadair",
    "title": "deadair",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeadair.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-518-cldeadestate",
    "title": "deadestate",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeadestate.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-519-cldeadfrontieroutbreak",
    "title": "deadfrontieroutbreak",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeadfrontieroutbreak.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-520-cldeadfrontieroutbreak2",
    "title": "deadfrontieroutbreak 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeadfrontieroutbreak2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-521-cldeadlydescent",
    "title": "deadlydescent",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeadlydescent.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-522-cldeadplate",
    "title": "deadplate",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeadplate.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-523-cldeadseat",
    "title": "deadseat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeadseat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-524-cldeadzed",
    "title": "deadzed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeadzed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-525-cldeadzed2",
    "title": "deadzed 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeadzed2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-526-cldeathchase",
    "title": "deathchase",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeathchase.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-527-cldeathrun",
    "title": "deathrun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeathrun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-528-cldeblob2",
    "title": "deblob 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeblob2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-529-cldecision",
    "title": "decision",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldecision.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-530-cldecision2",
    "title": "decision 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldecision2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-531-cldecision3",
    "title": "decision 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldecision3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-532-cldecisionmedieval",
    "title": "decisionmedieval",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldecisionmedieval.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-533-cldeepersleep",
    "title": "deepersleep",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeepersleep.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-534-cldeepestsword",
    "title": "deepestsword",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeepestsword.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-535-cldeepsleep",
    "title": "deepsleep",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeepsleep.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-536-cldefenderarcade",
    "title": "defenderarcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldefenderarcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-537-cldefendyourcastle",
    "title": "defendyourcastle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldefendyourcastle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-538-cldefendyournuts",
    "title": "defendyournuts",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldefendyournuts.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-539-cldefendyournuts2",
    "title": "defendyournuts 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldefendyournuts2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-540-cldeltarune",
    "title": "deltarune",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeltarune.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-541-cldeltatraveler",
    "title": "deltatraveler",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldeltatraveler.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-542-cldementium",
    "title": "dementium",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldementium.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-543-cldemolitionderbycrashracing",
    "title": "demolitionderbycrashracing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldemolitionderbycrashracing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-544-cldemonblade",
    "title": "demonblade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldemonblade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-545-cldemonbluff",
    "title": "demonbluff",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldemonbluff.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-546-cldiablo",
    "title": "diablo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldiablo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-547-cldiamondhollow",
    "title": "diamondhollow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldiamondhollow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-548-cldiamondhollow2",
    "title": "diamondhollow 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldiamondhollow2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-549-cldiddykong-racing",
    "title": "diddykong-racing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldiddykong-racing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-550-cldieinthedungeon",
    "title": "dieinthedungeon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldieinthedungeon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-551-cldigdeep",
    "title": "digdeep",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldigdeep.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-552-cldigdug",
    "title": "digdug",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldigdug.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-553-cldigdug2",
    "title": "digdug 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldigdug2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-554-cldigdug26",
    "title": "digdug 26",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldigdug26.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-555-cldigtochina",
    "title": "digtochina",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldigtochina.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-556-cldimensionalincident",
    "title": "dimensionalincident",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldimensionalincident.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-557-cldinodudes",
    "title": "dinodudes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldinodudes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-558-cldinorun",
    "title": "dinorun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldinorun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-559-cldinorunenterplanetd",
    "title": "dinorunenterplanetd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldinorunenterplanetd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-560-cldinorunmarathonofdoom",
    "title": "dinorunmarathonofdoom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldinorunmarathonofdoom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-561-cldiredecks",
    "title": "diredecks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldiredecks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-562-cldkccompetitioncart",
    "title": "dkccompetitioncart",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldkccompetitioncart.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-563-cldknescollection-1-",
    "title": "DKNESCollection(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clDKNESCollection(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-564-cldknescollection",
    "title": "DKNESCollection",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clDKNESCollection.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-565-cldoblox",
    "title": "doblox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoblox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-566-cldogeminer",
    "title": "dogeminer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldogeminer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-567-cldogeminer2",
    "title": "dogeminer 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldogeminer2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-568-cldokidokiliteratureclub",
    "title": "dokidokiliteratureclub",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldokidokiliteratureclub.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-569-cldomeromantik",
    "title": "domeromantik",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldomeromantik.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-570-cldonkeykong",
    "title": "donkeykong",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldonkeykong.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-571-cldonkeykong64",
    "title": "donkeykong 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldonkeykong64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-572-cldonkeykong94",
    "title": "donkeykong 94",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldonkeykong94.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-573-cldonkeykongcountry",
    "title": "donkeykongcountry",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldonkeykongcountry.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-574-cldonkeykongcountry2",
    "title": "donkeykongcountry 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldonkeykongcountry2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-575-cldonkeykongcountry3",
    "title": "donkeykongcountry 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldonkeykongcountry3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-576-cldonkeykongnes",
    "title": "donkeykongnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldonkeykongnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-577-cldontescape",
    "title": "dontescape",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldontescape.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-578-cldontescape2",
    "title": "dontescape 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldontescape2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-579-cldontescape3",
    "title": "dontescape 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldontescape3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-580-cldontyoulecturemehtml",
    "title": "dontyoulecturemehtml",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldontyoulecturemehtml.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-581-cldoodlejump",
    "title": "doodlejump",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoodlejump.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-582-cldoodlejumpgoober",
    "title": "doodlejumpgoober",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoodlejumpgoober.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-583-cldoom",
    "title": "doom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-584-cldoom2",
    "title": "doom 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoom2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-585-cldoom2d",
    "title": "doom 2 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoom2d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-586-cldoom2ddos",
    "title": "doom 2 d DOS",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoom2dDOS.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-587-cldoom2dos",
    "title": "doom 2 dos",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoom2dos.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-588-cldoom3pack",
    "title": "doom 3 pack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoom3pack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-589-cldoom64",
    "title": "doom 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoom64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-590-cldoomdos",
    "title": "doomdos",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoomdos.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-591-cldoomemscripten",
    "title": "doomemscripten",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoomemscripten.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-592-cldoomps",
    "title": "doomps",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoomps.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-593-cldoompsalt",
    "title": "doompsalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoompsalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-594-cldoomzio",
    "title": "doomzio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoomzio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-595-cldoorscastle",
    "title": "doorscastle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoorscastle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-596-cldoswasmx",
    "title": "doswasmx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoswasmx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-597-cldoubledribble",
    "title": "doubledribble",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoubledribble.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-598-cldouchebaglife",
    "title": "douchebaglife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldouchebaglife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-599-cldouchebagworkout",
    "title": "douchebagworkout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldouchebagworkout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-600-cldouchebagworkout2",
    "title": "douchebagworkout 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldouchebagworkout2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-601-cldownthemountain",
    "title": "downthemountain",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldownthemountain.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-602-cldragonballadvance",
    "title": "dragonballadvance",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldragonballadvance.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-603-cldragonballzthelegacyofgoku",
    "title": "Dragon Ball ZThe Legacyof Goku",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clDragonBallZTheLegacyofGoku.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-604-cldragonquest5ds",
    "title": "dragonquest 5 ds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldragonquest5ds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-605-cldragonquestix",
    "title": "Dragon Quest IX",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clDragonQuestIX.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-606-cldragonwarriormonsters",
    "title": "dragonwarriormonsters",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldragonwarriormonsters.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-607-cldragonxclient",
    "title": "Dragonxclient",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clDragonxclient.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-608-cldrawclimber",
    "title": "drawclimber",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldrawclimber.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-609-cldrawntolife",
    "title": "drawntolife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldrawntolife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-610-cldrawntolife2",
    "title": "drawntolife 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldrawntolife2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-611-cldrawtheline",
    "title": "drawtheline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldrawtheline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-612-cldreader",
    "title": "dreader",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldreader.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-613-cldreadheadparkour",
    "title": "dreadheadparkour",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldreadheadparkour.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-614-cldriftboss",
    "title": "driftboss",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldriftboss.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-615-cldrifthuntersmerge",
    "title": "drifthuntersmerge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldrifthuntersmerge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-616-cldriftsimulator",
    "title": "driftsimulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldriftsimulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-617-cldrivemady",
    "title": "drivemady",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldrivemady.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-618-cldrivenwild",
    "title": "drivenwild",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldrivenwild.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-619-cldriverussia",
    "title": "driverussia",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldriverussia.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-620-cldrmario",
    "title": "drmario",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldrmario.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-621-cldrweedgaster",
    "title": "drweedgaster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldrweedgaster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-622-cldta6",
    "title": "dta 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldta6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-623-cldubstep",
    "title": "dubstep",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldubstep.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-624-clduckhunt",
    "title": "duckhunt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clduckhunt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-625-clducklfe5",
    "title": "ducklfe 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducklfe5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-626-clducklife",
    "title": "ducklife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducklife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-627-clducklife2",
    "title": "ducklife 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducklife2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-628-clducklife3",
    "title": "ducklife 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducklife3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-629-clducklife4",
    "title": "ducklife 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducklife4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-630-clducklifebattle",
    "title": "ducklifebattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducklifebattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-631-clducklifespace",
    "title": "ducklifespace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducklifespace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-632-clducklingsio",
    "title": "ducklingsio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducklingsio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-633-clducktales",
    "title": "ducktales",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducktales.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-634-clducktales2",
    "title": "ducktales 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducktales2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-635-cldud",
    "title": "dud",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldud.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-636-cldukenukem2",
    "title": "dukenukem 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldukenukem2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-637-cldukenukem3d",
    "title": "dukenukem 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldukenukem3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-638-cldumbwaystodie",
    "title": "dumbwaystodie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldumbwaystodie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-639-cldumpling",
    "title": "dumpling",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldumpling.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-640-cldunebuggy",
    "title": "dunebuggy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldunebuggy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-641-cldungeondeck",
    "title": "dungeondeck",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldungeondeck.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-642-cldungeonraid",
    "title": "dungeonraid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldungeonraid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-643-cldungeonsanddegenerategamblers",
    "title": "dungeonsanddegenerategamblers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldungeonsanddegenerategamblers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-644-cldunkshot",
    "title": "dunkshot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldunkshot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-645-clduskchild",
    "title": "duskchild",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clduskchild.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-646-cldyingdreams",
    "title": "dyingdreams",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldyingdreams.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-647-cldynamiteheaddy",
    "title": "dynamiteheaddy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldynamiteheaddy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-648-cleaglercraft-alpha-126-offline",
    "title": "Eaglercraft-Alpha-126-Offline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clEaglercraft-Alpha-126-Offline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-649-cleaglercraft-beta-1-3-offline",
    "title": "Eaglercraft-Beta-1.3-Offline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clEaglercraft-Beta-1.3-Offline",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-650-cleaglercraft-beta-13-offline",
    "title": "Eaglercraft-Beta-13-Offline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clEaglercraft-Beta-13-Offline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-651-cleaglercraft-indev-offline--1-",
    "title": "Eaglercraft-Indev-Offline (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clEaglercraft-Indev-Offline%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-652-cleaglercraft-indev-offline-1-",
    "title": "Eaglercraft-Indev-Offline(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clEaglercraft-Indev-Offline(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-653-cleaglercraft-indev-offline-2-",
    "title": "Eaglercraft-Indev-Offline(2)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clEaglercraft-Indev-Offline(2).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-654-cleaglercraft-indev-offline",
    "title": "Eaglercraft-Indev-Offline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clEaglercraft-Indev-Offline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-655-cleaglercraft152",
    "title": "eaglercraft 152",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleaglercraft152.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-656-cleaglercraftl-19-v0-7-0-offline-signed-1-",
    "title": "Eaglercraft L 19 v 0 7 0 Offline Signed(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clEaglercraftL_19_v0_7_0_Offline_Signed(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-657-cleaglercraftl-19-v0-7-0-offline-signed",
    "title": "Eaglercraft L 19 v 0 7 0 Offline Signed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clEaglercraftL_19_v0_7_0_Offline_Signed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-658-cleaglercraftnebula",
    "title": "eaglercraftnebula",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleaglercraftnebula.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-659-cleagleride",
    "title": "eagleride",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleagleride.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-660-clearntodie",
    "title": "earntodie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearntodie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-661-clearntodie2",
    "title": "earntodie 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearntodie2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-662-clearthbound",
    "title": "earthbound",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthbound.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-663-clearthbound3",
    "title": "earthbound 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthbound3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-664-clearthboundsnes",
    "title": "earthboundsnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthboundsnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-665-clearthtaken",
    "title": "earthtaken",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthtaken.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-666-clearthtaken2",
    "title": "earthtaken 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthtaken2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-667-clearthtaken3",
    "title": "earthtaken 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthtaken3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-668-clearthwormgg",
    "title": "earthwormgg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthwormgg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-669-clearthwormjim--1-",
    "title": "earthwormjim (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthwormjim%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-670-clearthwormjim",
    "title": "earthwormjim",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthwormjim.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-671-clearthwormjim2--1-",
    "title": "earthwormjim 2 (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthwormjim2%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-672-clearthwormjim2",
    "title": "earthwormjim 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clearthwormjim2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-673-cledelweiss",
    "title": "edelweiss",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cledelweiss.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-674-cledyscarsimulator",
    "title": "edyscarsimulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cledyscarsimulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-675-cleffinghail",
    "title": "effinghail",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleffinghail.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-676-cleffingmachines",
    "title": "effingmachines",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleffingmachines.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-677-cleffingworms",
    "title": "effingworms",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleffingworms.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-678-cleffingzombies",
    "title": "effingzombies",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleffingzombies.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-679-clegg",
    "title": "egg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clegg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-680-cleggycar",
    "title": "eggycar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleggycar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-681-clelasticface",
    "title": "elasticface",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clelasticface.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-682-clelectricman2",
    "title": "electricman 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clelectricman2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-683-clelevatoraction",
    "title": "elevatoraction",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clelevatoraction.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-684-clelytraflight",
    "title": "elytraflight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clelytraflight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-685-clemujs",
    "title": "emujs",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clemujs.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-686-clenchain",
    "title": "enchain",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clenchain.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-687-clendacopia",
    "title": "endacopia",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clendacopia.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-688-clendlesswar4",
    "title": "endlesswar 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clendlesswar4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-689-clendlesswar5",
    "title": "endlesswar 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clendlesswar5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-690-clendlesswar5wow",
    "title": "endlesswar 5 wow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clendlesswar5wow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-691-clendlesswar7",
    "title": "endlesswar 7",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clendlesswar7.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-692-clenduro",
    "title": "enduro",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clenduro.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-693-clepicbattlefantasy5",
    "title": "epicbattlefantasy 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clepicbattlefantasy5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-694-clescalatingduel",
    "title": "escalatingduel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clescalatingduel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-695-clescaperoad",
    "title": "escaperoad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clescaperoad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-696-clescaperoadcity2",
    "title": "escaperoadcity 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clescaperoadcity2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-697-clescapeschoolduel",
    "title": "escapeschoolduel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clescapeschoolduel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-698-clet",
    "title": "et",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clet.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-699-cletrianoddyssey",
    "title": "etrianoddyssey",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cletrianoddyssey.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-700-cleurovisionsim",
    "title": "eurovisionsim",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleurovisionsim.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-701-clevilglitch",
    "title": "evilglitch",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clevilglitch.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-702-clevolution",
    "title": "evolution",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clevolution.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-703-clexcitebike64",
    "title": "excitebike 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clexcitebike64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-704-clexitpath",
    "title": "exitpath",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clexitpath.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-705-clexoobservation",
    "title": "exoobservation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clexoobservation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-706-clextremerun3d",
    "title": "extremerun 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clextremerun3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-707-clfactoryballs",
    "title": "factoryballs",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfactoryballs.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-708-clfactoryballs2",
    "title": "factoryballs 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfactoryballs2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-709-clfactoryballs3",
    "title": "factoryballs 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfactoryballs3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-710-clfactoryballs4",
    "title": "factoryballs 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfactoryballs4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-711-clfairytalevsonepiece",
    "title": "fairytalevsonepiece",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfairytalevsonepiece.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-712-clfallguys",
    "title": "fallguys",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfallguys.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-713-clfallout",
    "title": "fallout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfallout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-714-clfamidash",
    "title": "famidash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfamidash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-715-clfamidash128",
    "title": "famidash 128",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfamidash128.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-716-clfamidashalbum128",
    "title": "famidash Album 128",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfamidashAlbum128.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-717-clfamidashbsides128",
    "title": "famidash BSides 128",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfamidashBSides128.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-718-clfamidashcsides128",
    "title": "famidash CSides 128",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfamidashCSides128.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-719-clfamidashdsides128",
    "title": "famidash DSides 128",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfamidashDSides128.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-720-clfamilyguycorrupted",
    "title": "familyguycorrupted",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfamilyguycorrupted.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-721-clfancypantsadventure",
    "title": "fancypantsadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfancypantsadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-722-clfancypantsadventure2",
    "title": "fancypantsadventure 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfancypantsadventure2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-723-clfancypantsadventure3",
    "title": "fancypantsadventure 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfancypantsadventure3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-724-clfancysnowboarding",
    "title": "fancysnowboarding",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfancysnowboarding.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-725-clfantasyzone",
    "title": "fantasyzone",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfantasyzone.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-726-clfashionbattle",
    "title": "fashionbattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfashionbattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-727-clfattygenius",
    "title": "fattygenius",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfattygenius.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-728-clfearassessment",
    "title": "fearassessment",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfearassessment.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-729-clfearstofathomhomealone",
    "title": "fearstofathomhomealone",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfearstofathomhomealone.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-730-clfeedthevoid",
    "title": "feedthevoid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfeedthevoid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-731-clfeedus",
    "title": "feedus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfeedus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-732-clfeedus2",
    "title": "feedus 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfeedus2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-733-clfeedus3",
    "title": "feedus 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfeedus3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-734-clfeedus4",
    "title": "feedus 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfeedus4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-735-clfeedus5",
    "title": "feedus 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfeedus5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-736-clff2ws",
    "title": "ff 2 ws",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clff2ws.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-737-clff3",
    "title": "FF3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFF3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-738-clff6",
    "title": "ff 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clff6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-739-clffaf",
    "title": "ffaf",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clffaf.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-740-clffmysticquest",
    "title": "ffmysticquest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clffmysticquest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-741-clffsonic1",
    "title": "FFsonic 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFFsonic1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-742-clffsonic2",
    "title": "FFsonic 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFFsonic2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-743-clffsonic3",
    "title": "FFsonic 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFFsonic3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-744-clffsonic4",
    "title": "FFsonic 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFFsonic4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-745-clffsonic5",
    "title": "FFsonic 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFFsonic5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-746-clffsonic61",
    "title": "FFsonic 61",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFFsonic61.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-747-clffsonic62",
    "title": "FFsonic 62",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFFsonic62.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-748-clfifa07",
    "title": "FIFA07",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFA07.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-749-clfifa10",
    "title": "FIFA10",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFA10.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-750-clfifa11",
    "title": "FIFA11",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFA11.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-751-clfifa2000-1-",
    "title": "FIFA2000(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFA2000(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-752-clfifa2000-2-",
    "title": "FIFA2000(2)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFA2000(2).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-753-clfifa2000",
    "title": "fifa 2000",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfifa2000.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-754-clfifa99",
    "title": "FIFA99",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFA99.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-755-clfifainternationalsoccer",
    "title": "FIFAinternationalsoccer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFAinternationalsoccer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-756-clfifaroadtoworldcup98",
    "title": "FIFAroadtoworldcup 98",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFAroadtoworldcup98.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-757-clfifasoccer06",
    "title": "FIFAsoccer 06",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFAsoccer06.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-758-clfifasoccer95",
    "title": "FIFAsoccer 95",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFAsoccer95.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-759-clfifasoccer96",
    "title": "FIFAsoccer 96",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFAsoccer96.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-760-clfifasoccer97",
    "title": "FIFAsoccer 97",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFAsoccer97.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-761-clfifastreet2",
    "title": "FIFAstreet 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFIFAstreet2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-762-clfinalearth2",
    "title": "finalearth 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalearth2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-763-clfinalfantasy",
    "title": "finalfantasy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-764-clfinalfantasy2nes",
    "title": "finalfantasy 2 nes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasy2nes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-765-clfinalfantasy3nes",
    "title": "finalfantasy 3 nes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasy3nes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-766-clfinalfantasyii",
    "title": "finalfantasy II",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasyII.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-767-clfinalfantasyix",
    "title": "finalfantasy IX",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasyIX.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-768-clfinalfantasylegend2",
    "title": "finalfantasylegend 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasylegend2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-769-clfinalfantasytactics",
    "title": "finalfantasytactics",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasytactics.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-770-clfinalfantasyvi",
    "title": "finalfantasy VI",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasyVI.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-771-clfinalfantasyvii",
    "title": "finalfantasy VII",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasyVII.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-772-clfinalfantasyviid2",
    "title": "finalfantasy VIId 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasyVIId2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-773-clfinalfantasyviid3",
    "title": "finalfantasy VIId 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasyVIId3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-774-clfinalfantasyviitheothertetrr",
    "title": "finalfantasy VIItheothertetrr",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasyVIItheothertetrr.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-775-clfinalninja",
    "title": "finalninja",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalninja.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-776-clfindthealien",
    "title": "findthealien",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfindthealien.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-777-clfireblob",
    "title": "fireblob",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfireblob.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-778-clfireboyandwatergirl",
    "title": "fireboyandwatergirl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfireboyandwatergirl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-779-clfireboyandwatergirl2",
    "title": "fireboyandwatergirl 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfireboyandwatergirl2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-780-clfireboyandwatergirl3",
    "title": "fireboyandwatergirl 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfireboyandwatergirl3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-781-clfireboyandwatergirl5",
    "title": "fireboyandwatergirl 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfireboyandwatergirl5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-782-clfireboyandwatergirl6",
    "title": "fireboyandwatergirl 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfireboyandwatergirl6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-783-clfireemblem",
    "title": "fireemblem",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfireemblem.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-784-clfisheatgettingbig",
    "title": "fisheatgettingbig",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfisheatgettingbig.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-785-clfisquarium",
    "title": "fisquarium",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfisquarium.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-786-clfivenightsatbaldisredone",
    "title": "fivenightsatbaldisredone",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfivenightsatbaldisredone.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-787-clfivenightsatepsteins",
    "title": "fivenightsatepsteins",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfivenightsatepsteins.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-788-clfivenightsatshreks",
    "title": "fivenightsatshreks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfivenightsatshreks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-789-clfivenightsatshrekshotel",
    "title": "fivenightsatshrekshotel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfivenightsatshrekshotel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-790-clfivenightsatyoshis",
    "title": "fivenightsatyoshis",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfivenightsatyoshis.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-791-clflappybird",
    "title": "flappybird",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clflappybird.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-792-clflashsonic",
    "title": "flashsonic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clflashsonic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-793-clfloodrunner",
    "title": "floodrunner",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfloodrunner.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-794-clfloodrunner2",
    "title": "floodrunner 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfloodrunner2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-795-clfloodrunner4",
    "title": "floodrunner 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfloodrunner4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-796-clfluidism",
    "title": "fluidism",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfluidism.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-797-clfnac1",
    "title": "fnac 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnac1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-798-clfnac2",
    "title": "fnac 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnac2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-799-clfnaf",
    "title": "FNAF",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFNAF.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-800-clfnaf2",
    "title": "FNAF2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFNAF2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-801-clfnaf3",
    "title": "FNAF3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFNAF3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-802-clfnaf3remastered",
    "title": "fnaf 3 remastered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnaf3remastered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-803-clfnaf4",
    "title": "FNAF4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clFNAF4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-804-clfnaf4halloween",
    "title": "fnaf 4 halloween",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnaf4halloween.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-805-clfnafanimatronics",
    "title": "fnafanimatronics",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnafanimatronics.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-806-clfnafps",
    "title": "fnafps",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnafps.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-807-clfnafshooter",
    "title": "fnafshooter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnafshooter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-808-clfnafsl",
    "title": "fnafsl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnafsl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-809-clfnafucn",
    "title": "fnafucn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnafucn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-810-clfnafworldd",
    "title": "fnafworldd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnafworldd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-811-clfnaw",
    "title": "fnaw",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnaw.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-812-clfnfaethos",
    "title": "fnfaethos",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfaethos.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-813-clfnfagoti",
    "title": "fnfagoti",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfagoti.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-814-clfnfakage",
    "title": "fnfakage",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfakage.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-815-clfnfanimation",
    "title": "fnfanimation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfanimation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-816-clfnfannie",
    "title": "fnfannie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfannie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-817-clfnfasdf",
    "title": "fnfasdf",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfasdf.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-818-clfnfbelowdepths",
    "title": "fnfbelowdepths",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfbelowdepths.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-819-clfnfbfdi26",
    "title": "fnfbfdi 26",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfbfdi26.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-820-clfnfbinarybreakdown",
    "title": "fnfbinarybreakdown",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfbinarybreakdown.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-821-clfnfblackbetrayal",
    "title": "fnfblackbetrayal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfblackbetrayal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-822-clfnfbside",
    "title": "fnfbside",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfbside.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-823-clfnfcamelliarudeblaster",
    "title": "fnfcamelliarudeblaster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfcamelliarudeblaster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-824-clfnfcandycarrier",
    "title": "fnfcandycarrier",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfcandycarrier.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-825-clfnfchara",
    "title": "fnfchara",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfchara.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-826-clfnfcitytales",
    "title": "fnfcitytales",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfcitytales.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-827-clfnfclassified",
    "title": "fnfclassified",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfclassified.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-828-clfnfcorrosion",
    "title": "fnfcorrosion",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfcorrosion.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-829-clfnfcory",
    "title": "fnfcory",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfcory.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-830-clfnfcrunchin",
    "title": "fnfcrunchin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfcrunchin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-831-clfnfdeciever",
    "title": "fnfdeciever",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfdeciever.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-832-clfnfdesolation",
    "title": "fnfdesolation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfdesolation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-833-clfnfdocumictxtv3",
    "title": "fnfdocumictxtv 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfdocumictxtv3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-834-clfnfdokitakeoverplus",
    "title": "fnfdokitakeoverplus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfdokitakeoverplus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-835-clfnfdropandroll",
    "title": "fnfdropandroll",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfdropandroll.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-836-clfnfdsides",
    "title": "fnfdsides",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfdsides.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-837-clfnfdustin",
    "title": "fnfdustin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfdustin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-838-clfnfdusttale",
    "title": "fnfdusttale",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfdusttale.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-839-clfnffleetway",
    "title": "fnffleetway",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnffleetway.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-840-clfnfflippedout",
    "title": "fnfflippedout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfflippedout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-841-clfnffnaf1",
    "title": "fnffnaf 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnffnaf1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-842-clfnffnaf2",
    "title": "fnffnaf 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnffnaf2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-843-clfnffnaf3",
    "title": "fnffnaf 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnffnaf3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-844-clfnffnatpt",
    "title": "fnffnatpt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnffnatpt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-845-clfnfgamebreakerbundle",
    "title": "fnfgamebreakerbundle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfgamebreakerbundle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-846-clfnfgfmode",
    "title": "fnfgfmode",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfgfmode.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-847-clfnfgodot",
    "title": "fnfgodot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfgodot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-848-clfnfgoldenapple",
    "title": "fnfgoldenapple",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfgoldenapple.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-849-clfnfhank",
    "title": "fnfhank",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfhank.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-850-clfnfheartbreakhavoc",
    "title": "fnfheartbreakhavoc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfheartbreakhavoc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-851-clfnfherobrine",
    "title": "fnfherobrine",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfherobrine.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-852-clfnfhex",
    "title": "fnfhex",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfhex.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-853-clfnfholiday",
    "title": "fnfholiday",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfholiday.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-854-clfnfhorkglorpgloop",
    "title": "fnfhorkglorpgloop",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfhorkglorpgloop.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-855-clfnfhotline",
    "title": "fnfhotline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfhotline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-856-clfnfhypnoslullaby",
    "title": "fnfhypnoslullaby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfhypnoslullaby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-857-clfnfimposter3",
    "title": "fnfimposter 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfimposter3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-858-clfnfimposterv4",
    "title": "fnfimposterv 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfimposterv4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-859-clfnfindiecross",
    "title": "fnfindiecross",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfindiecross.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-860-clfnfinfernalbout",
    "title": "fnfinfernalbout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfinfernalbout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-861-clfnfinfiniteirida",
    "title": "fnfinfiniteirida",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfinfiniteirida.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-862-clfnfironlung",
    "title": "fnfironlung",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfironlung.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-863-clfnfjapcreepypasta",
    "title": "fnfjapcreepypasta",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfjapcreepypasta.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-864-clfnfmadnesspoop",
    "title": "fnfmadnesspoop",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfmadnesspoop.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-865-clfnfmaginagematches",
    "title": "fnfmaginagematches",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfmaginagematches.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-866-clfnfmariomadnessdside",
    "title": "fnfmariomadnessdside",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfmariomadnessdside.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-867-clfnfmarioport",
    "title": "fnfmarioport",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfmarioport.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-868-clfnfmcmadness",
    "title": "fnfmcmadness",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfmcmadness.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-869-clfnfmidfight",
    "title": "fnfmidfight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfmidfight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-870-clfnfmiku",
    "title": "fnfmiku",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfmiku.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-871-clfnfmobmod",
    "title": "fnfmobmod",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfmobmod.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-872-clfnfneo",
    "title": "fnfneo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfneo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-873-clfnfpiggyfield",
    "title": "fnfpiggyfield",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfpiggyfield.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-874-clfnfplutoshi",
    "title": "fnfplutoshi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfplutoshi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-875-clfnfpokepastaperdition",
    "title": "fnfpokepastaperdition",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfpokepastaperdition.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-876-clfnfporifera",
    "title": "fnfporifera",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfporifera.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-877-clfnfqt",
    "title": "fnfqt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfqt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-878-clfnfremnants",
    "title": "fnfremnants",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfremnants.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-879-clfnfretrospecter",
    "title": "fnfretrospecter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfretrospecter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-880-clfnfrevmixed",
    "title": "fnfrevmixed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfrevmixed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-881-clfnfrewrite",
    "title": "fnfrewrite",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfrewrite.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-882-clfnfrhythmicrev",
    "title": "fnfrhythmicrev",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfrhythmicrev.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-883-clfnfrottensmoothie",
    "title": "fnfrottensmoothie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfrottensmoothie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-884-clfnfselfpaced",
    "title": "fnfselfpaced",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfselfpaced.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-885-clfnfshaggy4keys",
    "title": "fnfshaggy 4 keys",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfshaggy4keys.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-886-clfnfshaggyxmatt",
    "title": "fnfshaggyxmatt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfshaggyxmatt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-887-clfnfshucks-v2",
    "title": "fnfshucks-v 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfshucks-v2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-888-clfnfshucksv2",
    "title": "fnfshucksv 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfshucksv2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-889-clfnfsky",
    "title": "fnfsky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfsky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-890-clfnfsoft",
    "title": "fnfsoft",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfsoft.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-891-clfnfsonicexe",
    "title": "fnfsonicexe",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfsonicexe.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-892-clfnfsonicexe4",
    "title": "fnfsonicexe 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfsonicexe4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-893-clfnfstarlightmayhem",
    "title": "fnfstarlightmayhem",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfstarlightmayhem.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-894-clfnfstridentcrisis",
    "title": "fnfstridentcrisis",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfstridentcrisis.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-895-clfnftailsgetstrolled",
    "title": "fnftailsgetstrolled",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnftailsgetstrolled.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-896-clfnftooslowfran",
    "title": "fnftooslowfran",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnftooslowfran.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-897-clfnftricky",
    "title": "fnftricky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnftricky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-898-clfnftwiddlefinger",
    "title": "fnf TWIDDLEFINGER",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfTWIDDLEFINGER.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-899-clfnfundertale",
    "title": "fnfundertale",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfundertale.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-900-clfnfvoid",
    "title": "fnfvoid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfvoid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-901-clfnfvstabi",
    "title": "fnfvstabi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfvstabi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-902-clfnfwaltenfiles",
    "title": "fnfwaltenfiles",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfwaltenfiles.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-903-clfnfwednesday-infedility",
    "title": "fnfwednesday-infedility",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfwednesday-infedility.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-904-clfnfwhitty",
    "title": "fnfwhitty",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfwhitty.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-905-clfnfzardy",
    "title": "fnfzardy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfzardy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-906-clfocus",
    "title": "focus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfocus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-907-clfolderdungeon",
    "title": "folderdungeon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfolderdungeon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-908-clfootballbros",
    "title": "footballbros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfootballbros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-909-clfootballlegends",
    "title": "footballlegends",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfootballlegends.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-910-clforknsausage",
    "title": "forknsausage",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clforknsausage.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-911-clfortzone",
    "title": "fortzone",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfortzone.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-912-clfpa4p1",
    "title": "fpa 4 p 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfpa4p1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-913-clfpa4p2",
    "title": "fpa 4 p 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfpa4p2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-914-clfreegemas",
    "title": "freegemas",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfreegemas.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-915-clfreerider",
    "title": "freerider",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfreerider.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-916-clfreerider2",
    "title": "freerider 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfreerider2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-917-clfreerider3",
    "title": "freerider 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfreerider3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-918-clfridaynightfunkin",
    "title": "fridaynightfunkin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfridaynightfunkin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-919-clfroggerarcade",
    "title": "froggerarcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfroggerarcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-920-clfromrusttoash",
    "title": "fromrusttoash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfromrusttoash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-921-clfruitninja",
    "title": "fruitninja",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfruitninja.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-922-clfunkinmix",
    "title": "funkinmix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfunkinmix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-923-clfunnybattle",
    "title": "funnybattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfunnybattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-924-clfunnybattle2",
    "title": "funnybattle 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfunnybattle2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-925-clfunnymadracing",
    "title": "funnymadracing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfunnymadracing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-926-clfunnyshooter2",
    "title": "funnyshooter 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfunnyshooter2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-927-clfunnyshooter22",
    "title": "funnyshooter 22",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfunnyshooter22.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-928-clfuschiax",
    "title": "fuschiax",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfuschiax.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-929-clfused240",
    "title": "fused 240",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfused240.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-930-clfzero",
    "title": "fzero",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfzero.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-931-clfzerox",
    "title": "fzerox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfzerox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-932-clgachaverse",
    "title": "gachaverse",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgachaverse.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-933-clgain-ground",
    "title": "Gain Ground",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clGain%20Ground.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-934-clgalaga",
    "title": "galaga",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgalaga.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-935-clgameandwatchcollection",
    "title": "gameandwatchcollection",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgameandwatchcollection.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-936-clgamewatchgallery3",
    "title": "gamewatchgallery 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgamewatchgallery3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-937-clgangstabean",
    "title": "gangstabean",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgangstabean.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-938-clgangstabean2",
    "title": "gangstabean 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgangstabean2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-939-clgangsterbros",
    "title": "gangsterbros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgangsterbros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-940-clgarcello",
    "title": "garcello",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgarcello.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-941-clgarfcaughtinact",
    "title": "garfcaughtinact",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgarfcaughtinact.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-942-clgdlite",
    "title": "gdlite",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgdlite.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-943-clgeneralchaos",
    "title": "generalchaos",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgeneralchaos.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-944-clgenericfightermaybe",
    "title": "genericfightermaybe",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgenericfightermaybe.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-945-clgeometrydashscratch",
    "title": "geometrydashscratch",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgeometrydashscratch.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-946-clgeometryvibes",
    "title": "geometryvibes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgeometryvibes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-947-clgeorgeandtheprinter",
    "title": "georgeandtheprinter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgeorgeandtheprinter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-948-clgetawayshootout",
    "title": "getawayshootout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgetawayshootout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-949-clgetontop",
    "title": "getontop",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgetontop.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-950-clgettothetopalthoughthereisnotop",
    "title": "Gettothetopalthoughthereisnotop",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clGettothetopalthoughthereisnotop.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-951-clgetyoked",
    "title": "getyoked",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgetyoked.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-952-clggshinobi",
    "title": "ggshinobi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clggshinobi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-953-clggshinobi2",
    "title": "ggshinobi 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clggshinobi2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-954-clghosttrick",
    "title": "ghosttrick",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clghosttrick.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-955-clgimmietheairpod",
    "title": "gimmietheairpod",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgimmietheairpod.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-956-clgladdihoppers",
    "title": "gladdihoppers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgladdihoppers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-957-clglfighters",
    "title": "glfighters",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clglfighters.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-958-clgloryhunters",
    "title": "gloryhunters",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgloryhunters.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-959-clglover",
    "title": "glover",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clglover.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-960-clgoalsouthafrica",
    "title": "goalsouthafrica",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoalsouthafrica.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-961-clgobble",
    "title": "gobble",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgobble.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-962-clgoingballs",
    "title": "goingballs",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoingballs.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-963-clgolddiggerfrvr",
    "title": "golddiggerfrvr",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgolddiggerfrvr.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-964-clgoldenaxe",
    "title": "goldenaxe",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoldenaxe.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-965-clgoldenaxe2",
    "title": "goldenaxe 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoldenaxe2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-966-clgoldenaxe3",
    "title": "goldenaxe 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoldenaxe3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-967-clgoldeneye007",
    "title": "goldeneye 007",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoldeneye007.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-968-clgoldensun",
    "title": "goldensun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoldensun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-969-clgoldensunnds",
    "title": "goldensunnds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoldensunnds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-970-clgoldensunthelostage",
    "title": "Golden Sun The Lost Age",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clGoldenSunTheLostAge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-971-clgoldminer",
    "title": "goldminer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoldminer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-972-clgolfbattle",
    "title": "golfbattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgolfbattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-973-clgolforbit",
    "title": "golforbit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgolforbit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-974-clgolfsunday",
    "title": "golfsunday",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgolfsunday.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-975-clgoodbigtowertinysquare",
    "title": "goodbigtowertinysquare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoodbigtowertinysquare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-976-clgoodbigtowertinysquare2",
    "title": "goodbigtowertinysquare 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoodbigtowertinysquare2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-977-clgoodboygalaxy",
    "title": "goodboygalaxy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoodboygalaxy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-978-clgoodmonkeymart",
    "title": "goodmonkeymart",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoodmonkeymart.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-979-clgooftroopsnes",
    "title": "gooftroopsnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgooftroopsnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-980-clgooglebaseball",
    "title": "googlebaseball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgooglebaseball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-981-clgoogledino",
    "title": "googledino",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgoogledino.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-982-clgorescriptclassic",
    "title": "gorescriptclassic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgorescriptclassic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-983-clgorillatag",
    "title": "gorillatag",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgorillatag.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-984-clgotobed",
    "title": "gotobed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgotobed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-985-clgrandactionsimulator-ny",
    "title": "grandactionsimulator-ny",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrandactionsimulator-ny.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-986-clgranddad",
    "title": "granddad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgranddad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-987-clgrandescapeprison",
    "title": "grandescapeprison",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrandescapeprison.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-988-clgrandtheftautoadvance",
    "title": "grandtheftautoadvance",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrandtheftautoadvance.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-989-clgranny",
    "title": "granny",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgranny.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-990-clgranny2",
    "title": "granny 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgranny2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-991-clgranny22",
    "title": "granny 22",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgranny22.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-992-clgranny3",
    "title": "granny 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgranny3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-993-clgrannycreepy",
    "title": "grannycreepy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrannycreepy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-994-clgrannynightmare",
    "title": "grannynightmare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrannynightmare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-995-clgrannyy",
    "title": "grannyy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrannyy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-996-clgranturismo",
    "title": "granturismo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgranturismo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-997-clgranturismo2",
    "title": "granturismo 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgranturismo2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-998-clgrassmowing",
    "title": "grassmowing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrassmowing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-999-clgravity",
    "title": "gravity",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgravity.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1000-clgravitymod",
    "title": "gravitymod",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgravitymod.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1001-clgreenergrassawaits",
    "title": "greenergrassawaits",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgreenergrassawaits.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1002-clgrey-box-testing",
    "title": "grey-box-testing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrey-box-testing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1003-clgrimacebirthday",
    "title": "grimacebirthday",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrimacebirthday.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1004-clgrindcraft",
    "title": "grindcraft",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrindcraft.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1005-clgrn",
    "title": "grn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1006-clgrowagarden",
    "title": "growagarden",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrowagarden.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1007-clgrowdenio",
    "title": "growdenio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrowdenio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1008-clgrowmi",
    "title": "growmi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrowmi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1009-clgrowyourgarden",
    "title": "growyourgarden",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrowyourgarden.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1010-clgta",
    "title": "gta",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgta.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1011-clgta2",
    "title": "gta 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgta2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1012-clgta22",
    "title": "gta 22",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgta22.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1013-clgta2alt",
    "title": "gta 2 alt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgta2alt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1014-clgtaalt",
    "title": "gtaalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgtaalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1015-clgtaalty",
    "title": "gtaalty",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgtaalty.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1016-clgtachina",
    "title": "gtachina",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgtachina.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1017-clgtamods",
    "title": "gtamods",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgtamods.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1018-clguesstheiranswer",
    "title": "guesstheiranswer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clguesstheiranswer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1019-clgun-spin",
    "title": "gun-spin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgun-spin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1020-clgunblood",
    "title": "gunblood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunblood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1021-clguncho",
    "title": "guncho",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clguncho.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1022-clgunfighterjessejames",
    "title": "gunfighterjessejames",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunfighterjessejames.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1023-clgunknight",
    "title": "gunknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1024-clgunmayhem",
    "title": "gunmayhem",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunmayhem.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1025-clgunmayhem2",
    "title": "gunmayhem 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunmayhem2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1026-clgunmayhem2goof",
    "title": "gunmayhem 2 goof",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunmayhem2goof.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1027-clgunmayhemredux",
    "title": "gunmayhemredux",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunmayhemredux.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1028-clgunnight",
    "title": "gunnight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunnight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1029-clgunsmoke",
    "title": "gunsmoke",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunsmoke.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1030-clgunstarheroes",
    "title": "gunstarheroes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgunstarheroes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1031-clgymstack",
    "title": "gymstack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgymstack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1032-clgyromite",
    "title": "gyromite",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgyromite.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1033-clhacx",
    "title": "hacx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhacx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1034-clhajimeippo",
    "title": "hajimeippo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhajimeippo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1035-clhajimenoippo",
    "title": "hajimenoippo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhajimenoippo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1036-clhalflife",
    "title": "halflife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhalflife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1037-clhalocombatdevolved",
    "title": "halocombatdevolved",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhalocombatdevolved.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1038-clhandshakes",
    "title": "handshakes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhandshakes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1039-clhandsofwar--1-",
    "title": "handsofwar (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhandsofwar%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1040-clhandsofwar-1-",
    "title": "handsofwar(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhandsofwar(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1041-clhandsofwar-2-",
    "title": "handsofwar(2)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhandsofwar(2).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1042-clhandsofwar",
    "title": "handsofwar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhandsofwar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1043-clhandulum",
    "title": "handulum",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhandulum.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1044-clhanger",
    "title": "hanger",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhanger.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1045-clhanger2",
    "title": "hanger 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhanger2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1046-clhangonsms",
    "title": "hangonsms",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhangonsms.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1047-clhappyroom",
    "title": "happyroom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhappyroom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1048-clhappywheels",
    "title": "happywheels",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhappywheels.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1049-clhardwaretycoon",
    "title": "hardwaretycoon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhardwaretycoon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1050-clharmonyofdissonance",
    "title": "harmonyofdissonance",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clharmonyofdissonance.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1051-clharoldsbadday",
    "title": "Haroldsbadday",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clHaroldsbadday.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1052-clharvestio",
    "title": "harvestio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clharvestio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1053-clharvestmoon",
    "title": "harvestmoon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clharvestmoon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1054-clharvestmoon2",
    "title": "harvestmoon 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clharvestmoon2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1055-clharvestmoon64",
    "title": "harvestmoon 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clharvestmoon64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1056-clhauntedschool",
    "title": "hauntedschool",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhauntedschool.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1057-clhauntthehouse",
    "title": "hauntthehouse",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhauntthehouse.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1058-clheartandsoul",
    "title": "heartandsoul",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clheartandsoul.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1059-clheartandsoul121",
    "title": "heartandsoul 121",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clheartandsoul121.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1060-clhei-t",
    "title": "hei$t",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhei%24t.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1061-clhelios-offline--1-",
    "title": "Helios-Offline (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clHelios-Offline%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1062-clhelios-offline",
    "title": "Helios-Offline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clHelios-Offline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1063-clhelixjump",
    "title": "helixjump",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhelixjump.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1064-clhellron",
    "title": "hellron",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhellron.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1065-clhelpnobrakes",
    "title": "helpnobrakes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhelpnobrakes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1066-clheretic",
    "title": "heretic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clheretic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1067-clhero3flyingrobot",
    "title": "hero 3 flyingrobot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhero3flyingrobot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1068-clherobrinereborn",
    "title": "herobrinereborn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clherobrinereborn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1069-clhextris",
    "title": "hextris",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhextris.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1070-clhighspeed",
    "title": "High Speed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clHighSpeed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1071-clhighstakes",
    "title": "highstakes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhighstakes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1072-clhighwayracer2",
    "title": "highwayracer 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhighwayracer2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1073-clhighwaytraffic3d",
    "title": "highwaytraffic 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhighwaytraffic3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1074-clhillclimbracinglite",
    "title": "hillclimbracinglite",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhillclimbracinglite.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1075-clhinohomo",
    "title": "Hi No Homo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clHiNoHomo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1076-clhipsterkickball",
    "title": "hipsterkickball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhipsterkickball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1077-clhit8ox",
    "title": "hit 8 ox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhit8ox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1078-clhitsinglereal",
    "title": "hitsinglereal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhitsinglereal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1079-clhitstunfly",
    "title": "hitstunfly",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhitstunfly.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1080-clhl2doom",
    "title": "hl 2 doom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhl2doom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1081-clhobo",
    "title": "hobo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhobo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1082-clhobo2",
    "title": "hobo 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhobo2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1083-clhobo3",
    "title": "hobo 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhobo3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1084-clhobo4",
    "title": "hobo 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhobo4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1085-clhobo5",
    "title": "hobo 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhobo5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1086-clhobo6",
    "title": "hobo 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhobo6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1087-clhobo7",
    "title": "hobo 7",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhobo7.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1088-clhobovszombies",
    "title": "hobovszombies",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhobovszombies.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1089-clhoennslastwish",
    "title": "Hoenns Last Wish",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clHoennsLastWish.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1090-clholebattle",
    "title": "holebattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clholebattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1091-clholeio",
    "title": "holeio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clholeio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1092-clhollowknight",
    "title": "hollowknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhollowknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1093-clhomesheephome",
    "title": "homesheephome",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhomesheephome.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1094-clhorrormickeymouse",
    "title": "horrormickeymouse",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhorrormickeymouse.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1095-clhotdogbush",
    "title": "hotdogbush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhotdogbush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1096-clhotwax",
    "title": "hotwax",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhotwax.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1097-clhouseofhazards",
    "title": "houseofhazards",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhouseofhazards.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1098-clhoverracerdrive",
    "title": "hoverracerdrive",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhoverracerdrive.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1099-clhuggywuggypixel",
    "title": "huggywuggypixel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhuggywuggypixel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1100-clhumanexpenditureprogram",
    "title": "humanexpenditureprogram",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhumanexpenditureprogram.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1101-clhungryknight",
    "title": "hungryknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhungryknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1102-clhungrylamu",
    "title": "hungrylamu",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhungrylamu.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1103-clhyppersandbox",
    "title": "hyppersandbox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhyppersandbox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1104-clicantbelievegoogleflaggedmeforthenameofthefilelol",
    "title": "icantbelievegoogleflaggedmeforthenameofthefilelol",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clicantbelievegoogleflaggedmeforthenameofthefilelol.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1105-clice-age-baby",
    "title": "ice age baby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clice%20age%20baby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1106-clicedodo",
    "title": "icedodo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clicedodo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1107-clicefishing",
    "title": "icefishing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clicefishing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1108-clicypurplehead",
    "title": "icypurplehead",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clicypurplehead.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1109-clidlebreakout",
    "title": "idlebreakout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clidlebreakout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1110-clidledice",
    "title": "idledice",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clidledice.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1111-clidlefootballmanager",
    "title": "idlefootballmanager",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clidlefootballmanager.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1112-clidleidlegamedev",
    "title": "idleidlegamedev",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clidleidlegamedev.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1113-clidleminertycoon",
    "title": "idleminertycoon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clidleminertycoon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1114-clidleminorzamnshes12",
    "title": "idleminorzamnshes 12",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clidleminorzamnshes12.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1115-climpossiblequiz--1-",
    "title": "impossiblequiz (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/climpossiblequiz%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1116-climpossiblequiz",
    "title": "impossiblequiz",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/climpossiblequiz.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1117-climpossiblequiz2",
    "title": "impossiblequiz 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/climpossiblequiz2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1118-clinclementemerald",
    "title": "inclementemerald",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clinclementemerald.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1119-clindiantrucksimiulator",
    "title": "indiantrucksimiulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clindiantrucksimiulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1120-clinfinitecraft",
    "title": "infinitecraft",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clinfinitecraft.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1121-clinkgame",
    "title": "inkgame",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clinkgame.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1122-clinkwell--v104-",
    "title": "Inkwell (v 104)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clInkwell%20(v104).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1123-clinnkeeper",
    "title": "innkeeper",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clinnkeeper.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1124-clinsidestory",
    "title": "insidestory",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clinsidestory.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1125-clinsomniary",
    "title": "insomniary",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clinsomniary.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1126-clintellisphere",
    "title": "intellisphere",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clintellisphere.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1127-clinteractivebuddy",
    "title": "interactivebuddy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clinteractivebuddy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1128-clintoruins",
    "title": "intoruins",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clintoruins.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1129-clintospace",
    "title": "intospace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clintospace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1130-clintospace2",
    "title": "intospace 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clintospace2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1131-clintospace3",
    "title": "intospace 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clintospace3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1132-clintothedeepweb",
    "title": "intothedeepweb",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clintothedeepweb.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1133-clintrusion",
    "title": "intrusion",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clintrusion.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1134-cliqball",
    "title": "iqball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cliqball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1135-clironsnout",
    "title": "ironsnout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clironsnout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1136-clironsoldier",
    "title": "ironsoldier",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clironsoldier.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1137-clirori",
    "title": "irori",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clirori.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1138-clitgetssolonelyhere",
    "title": "itgetssolonelyhere",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clitgetssolonelyhere.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1139-cliwbtg",
    "title": "iwbtg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cliwbtg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1140-cljacksmith",
    "title": "jacksmith",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljacksmith.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1141-cljacksmithencryptedorsmthn",
    "title": "jacksmithencryptedorsmthn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljacksmithencryptedorsmthn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1142-cljailbreakobbbobob",
    "title": "jailbreakobbbobob",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljailbreakobbbobob.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1143-cljamesbondjr",
    "title": "jamesbondjr",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljamesbondjr.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1144-cljazzjackrabbit",
    "title": "jazzjackrabbit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljazzjackrabbit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1145-cljazzjackrabbit2",
    "title": "jazzjackrabbit 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljazzjackrabbit2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1146-cljefflings",
    "title": "jefflings",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljefflings.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1147-cljellydadhero",
    "title": "jellydadhero",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljellydadhero.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1148-cljellydrift",
    "title": "jellydrift",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljellydrift.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1149-cljellymario",
    "title": "jellymario",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljellymario.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1150-cljellytruck",
    "title": "jellytruck",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljellytruck.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1151-cljellytruckgood",
    "title": "jellytruckgood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljellytruckgood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1152-cljetforcegemini",
    "title": "jetforcegemini",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljetforcegemini.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1153-cljetpackjoyride",
    "title": "jetpackjoyride",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljetpackjoyride.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1154-cljetrush",
    "title": "jetrush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljetrush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1155-cljetskiracing",
    "title": "jetskiracing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljetskiracing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1156-cljmocraft",
    "title": "jmocraft",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljmocraft.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1157-cljohnnytrigger",
    "title": "johnnytrigger",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljohnnytrigger.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1158-cljohnnyupgrade",
    "title": "johnnyupgrade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljohnnyupgrade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1159-cljojobaps1",
    "title": "jojobaps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljojobaps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1160-cljourneyarcade",
    "title": "journeyarcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljourneyarcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1161-cljourneydownhill",
    "title": "journeydownhill",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljourneydownhill.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1162-cljoustarcade",
    "title": "joustarcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljoustarcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1163-cljsvecx",
    "title": "jsvecx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljsvecx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1164-cljumbomario",
    "title": "jumbomario",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljumbomario.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1165-cljump",
    "title": "JUMP",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clJUMP.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1166-cljumpingshell",
    "title": "jumpingshell",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljumpingshell.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1167-cljunglebooksnes",
    "title": "junglebooksnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljunglebooksnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1168-cljungledeerhunting",
    "title": "jungledeerhunting",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljungledeerhunting.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1169-cljurassicpark",
    "title": "jurassicpark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljurassicpark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1170-cljustfalllol",
    "title": "justfalllol",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljustfalllol.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1171-cljusthitthebutton",
    "title": "justhitthebutton",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljusthitthebutton.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1172-cljustoneboss",
    "title": "justoneboss",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljustoneboss.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1173-clkaizomarioworld",
    "title": "kaizomarioworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkaizomarioworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1174-clkalikan",
    "title": "kalikan",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkalikan.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1175-clkanyezone",
    "title": "kanyezone",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkanyezone.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1176-clkapi",
    "title": "kapi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkapi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1177-clkaratebros",
    "title": "karatebros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkaratebros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1178-clkarlson",
    "title": "karlson",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkarlson.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1179-clkartbros",
    "title": "kartbros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkartbros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1180-clkengriffeyjrpresentsmajorleaguebaseball",
    "title": "Ken Griffey Jr Presents Major League Baseball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clKenGriffeyJrPresentsMajorLeagueBaseball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1181-clkeroseneclient",
    "title": "keroseneclient",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkeroseneclient.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1182-clkillerinstinct",
    "title": "killerinstinct",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkillerinstinct.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1183-clkillover",
    "title": "killover",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkillover.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1184-clkilltheiceagebabyadventure",
    "title": "killtheiceagebabyadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkilltheiceagebabyadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1185-clkimjonguntilepuzzle",
    "title": "kimjonguntilepuzzle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkimjonguntilepuzzle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1186-clkingdomheartsdays",
    "title": "kingdomheartsdays",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkingdomheartsdays.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1187-clkingdomheartsrecoded",
    "title": "kingdomheartsrecoded",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkingdomheartsrecoded.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1188-clkingdomheartsrecodedalt",
    "title": "kingdomheartsrecodedalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkingdomheartsrecodedalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1189-clkirby64",
    "title": "kirby 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirby64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1190-clkirby64crystalshards",
    "title": "kirby 64 crystalshards",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirby64crystalshards.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1191-clkirbyandtheamzingmirror",
    "title": "kirbyandtheamzingmirror",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbyandtheamzingmirror.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1192-clkirbycanvascurse",
    "title": "kirbycanvascurse",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbycanvascurse.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1193-clkirbysadventure",
    "title": "kirbysadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbysadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1194-clkirbysdreamland",
    "title": "kirbysdreamland",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbysdreamland.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1195-clkirbysdreamland3",
    "title": "kirbysdreamland 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbysdreamland3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1196-clkirbysoftandwet",
    "title": "kirbysoftandwet",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbysoftandwet.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1197-clkirbysqueaksquad",
    "title": "kirbysqueaksquad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbysqueaksquad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1198-clkirbysuperstar",
    "title": "kirbysuperstar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbysuperstar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1199-clkirbysuperstarultra",
    "title": "kirbysuperstarultra",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbysuperstarultra.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1200-clkirbytiltandtumble",
    "title": "kirbytiltandtumble",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkirbytiltandtumble.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1201-clkittencannon",
    "title": "kittencannon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkittencannon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1202-clklifur",
    "title": "klifur",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clklifur.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1203-clknifehit",
    "title": "knifehit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clknifehit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1204-clknightmaretower",
    "title": "knightmaretower",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clknightmaretower.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1205-clknockknock",
    "title": "knockknock",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clknockknock.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1206-clkonkrio",
    "title": "konkrio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkonkrio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1207-clkoopasrevenge",
    "title": "koopasrevenge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkoopasrevenge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1208-clkourio",
    "title": "kourio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clkourio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1209-clks2teams",
    "title": "ks 2 teams",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clks2teams.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1210-cllaceysflashgames",
    "title": "laceysflashgames",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllaceysflashgames.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1211-cllastfirered",
    "title": "lastfirered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllastfirered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1212-cllasthorizon",
    "title": "lasthorizon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllasthorizon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1213-cllaststand",
    "title": "laststand",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllaststand.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1214-cllaststand2",
    "title": "laststand 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllaststand2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1215-clleaderstrike",
    "title": "leaderstrike",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clleaderstrike.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1216-clleapandavoid2",
    "title": "leapandavoid 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clleapandavoid2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1217-cllearntofly",
    "title": "learntofly",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllearntofly.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1218-cllearntofly2",
    "title": "learntofly 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllearntofly2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1219-cllearntofly3",
    "title": "learntofly 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllearntofly3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1220-cllearntofly3debug",
    "title": "Learn To Fly 3 Debug",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clLearnToFly3Debug.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1221-cllearntoflyidle",
    "title": "learntoflyidle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllearntoflyidle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1222-cllearntoflyidlehack",
    "title": "learntoflyidlehack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllearntoflyidlehack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1223-cllegacyofgoku",
    "title": "Legacy Of Goku",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clLegacyOfGoku.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1224-cllegobatman",
    "title": "legobatman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllegobatman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1225-cllegobatman2superheroes",
    "title": "legobatman 2 superheroes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllegobatman2superheroes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1226-cllegoindianajones",
    "title": "legoindianajones",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllegoindianajones.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1227-cllegoindianajones2",
    "title": "legoindianajones 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllegoindianajones2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1228-cllegoninjago",
    "title": "legoninjago",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllegoninjago.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1229-cllegostarwars",
    "title": "legostarwars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllegostarwars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1230-cllegostarwars2gba",
    "title": "legostarwars 2 gba",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllegostarwars2gba.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1231-cllegostarwarsgba",
    "title": "legostarwarsgba",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllegostarwarsgba.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1232-cllemmings",
    "title": "lemmings",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllemmings.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1233-clletitconsume",
    "title": "letitconsume",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clletitconsume.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1234-clletsgoeevee",
    "title": "letsgoeevee",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clletsgoeevee.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1235-clletsgopikachu",
    "title": "letsgopikachu",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clletsgopikachu.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1236-clleveldevil",
    "title": "leveldevil",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clleveldevil.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1237-clleverwarriors",
    "title": "leverwarriors",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clleverwarriors.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1238-cllightitup",
    "title": "lightitup",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllightitup.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1239-cllilrunmo",
    "title": "lilrunmo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllilrunmo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1240-cllime",
    "title": "lime",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllime.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1241-cllinerider",
    "title": "linerider",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllinerider.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1242-cllinksawakeningdx",
    "title": "linksawakeningdx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllinksawakeningdx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1243-cllinktothepast",
    "title": "linktothepast",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllinktothepast.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1244-cllittlealchemy2",
    "title": "littlealchemy 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllittlealchemy2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1245-cllittlerunmo",
    "title": "littlerunmo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllittlerunmo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1246-cllockthedoor",
    "title": "lockthedoor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllockthedoor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1247-clloderunner",
    "title": "loderunner",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clloderunner.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1248-cllonewolf",
    "title": "lonewolf",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllonewolf.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1249-cllosangelesshark",
    "title": "losangelesshark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllosangelesshark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1250-cllowknight",
    "title": "lowknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllowknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1251-clloz1",
    "title": "loz 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clloz1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1252-cllozlinkawakening",
    "title": "lozlinkawakening",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllozlinkawakening.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1253-cllozminishcap",
    "title": "lozminishcap",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllozminishcap.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1254-cllozoracleofseasons",
    "title": "lozoracleofseasons",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllozoracleofseasons.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1255-cllozphantomhourglass",
    "title": "lozphantomhourglass",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllozphantomhourglass.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1256-cllozspirittracks",
    "title": "lozspirittracks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllozspirittracks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1257-cllse",
    "title": "LSE",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clLSE.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1258-cllucid",
    "title": "lucid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllucid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1259-clluckyblocks",
    "title": "luckyblocks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clluckyblocks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1260-cllumberobby",
    "title": "lumberobby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllumberobby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1261-cllummm",
    "title": "lummm",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllummm.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1262-clmadalinstuntcars",
    "title": "madalinstuntcars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadalinstuntcars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1263-clmadalinstuntcarsgood",
    "title": "madalinstuntcarsgood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadalinstuntcarsgood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1264-clmadalinstuntcarsmultiplayerfixed",
    "title": "madalinstuntcarsmultiplayerfixed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadalinstuntcarsmultiplayerfixed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1265-clmadden93",
    "title": "madden 93",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadden93.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1266-clmadden94",
    "title": "madden 94",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadden94.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1267-clmadden95",
    "title": "madden 95",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadden95.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1268-clmadden96",
    "title": "madden 96",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadden96.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1269-clmadden99",
    "title": "madden 99",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadden99.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1270-clmaddenfootball",
    "title": "maddenfootball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmaddenfootball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1271-clmaddenfootball64",
    "title": "maddenfootball 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmaddenfootball64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1272-clmaddennfl",
    "title": "maddennfl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmaddennfl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1273-clmaddennfl2000",
    "title": "maddennfl 2000",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmaddennfl2000.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1274-clmaddennfl2001",
    "title": "maddennfl 2001",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmaddennfl2001.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1275-clmaddennfl2002",
    "title": "maddennfl 2002",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmaddennfl2002.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1276-clmaddy98",
    "title": "maddy 98",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmaddy98.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1277-clmadness-retaliation",
    "title": "madness-retaliation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadness-retaliation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1278-clmadnessaccelerant",
    "title": "madnessaccelerant",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnessaccelerant.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1279-clmadnesscombatdefense",
    "title": "madnesscombatdefense",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnesscombatdefense.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1280-clmadnesscombatnexus",
    "title": "madnesscombatnexus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnesscombatnexus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1281-clmadnessgemini",
    "title": "madnessgemini",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnessgemini.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1282-clmadnesshydraulic",
    "title": "madnesshydraulic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnesshydraulic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1283-clmadnessinteractive",
    "title": "madnessinteractive",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnessinteractive.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1284-clmadnessoffcolor",
    "title": "madnessoffcolor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnessoffcolor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1285-clmadnesspremediation",
    "title": "madnesspremediation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnesspremediation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1286-clmadnessretaliation",
    "title": "madnessretaliation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnessretaliation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1287-clmadnesss2010",
    "title": "madnesss 2010",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnesss2010.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1288-clmadnessstand",
    "title": "madnessstand",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadnessstand.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1289-clmadskillsmotocross2",
    "title": "madskillsmotocross 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadskillsmotocross2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1290-clmadstick",
    "title": "madstick",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadstick.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1291-clmadstuntcars2",
    "title": "madstuntcars 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmadstuntcars2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1292-clmagetoweridle",
    "title": "magetoweridle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmagetoweridle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1293-clmagictiles3",
    "title": "magictiles 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmagictiles3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1294-clmajorasmask",
    "title": "majorasmask",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmajorasmask.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1295-clmakesureitsclosed",
    "title": "makesureitsclosed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmakesureitsclosed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1296-clmami",
    "title": "mami",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmami.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1297-clmanagod",
    "title": "managod",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmanagod.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1298-clmarbleracer-1-",
    "title": "marbleracer(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmarbleracer(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1299-clmarbleracer",
    "title": "marbleracer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmarbleracer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1300-clmari0",
    "title": "mari 0",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmari0.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1301-clmario-party-advance",
    "title": "Mario Party Advance",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMario%20Party%20Advance.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1302-clmario3",
    "title": "mario 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmario3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1303-clmario64webgl",
    "title": "mario 64 webgl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmario64webgl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1304-clmarioandluigisuperstarsaga",
    "title": "marioandluigisuperstarsaga",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmarioandluigisuperstarsaga.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1305-clmariobuilder64-1-",
    "title": "mariobuilder 64(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariobuilder64(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1306-clmariobuilder64",
    "title": "mariobuilder 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariobuilder64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1307-clmariocombat",
    "title": "mariocombat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariocombat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1308-clmariogolf",
    "title": "mariogolf",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariogolf.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1309-clmarioismissingdoneright",
    "title": "Mariois Missing Done Right",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMarioisMissingDoneRight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1310-clmariokart64",
    "title": "mariokart 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariokart64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1311-clmariokartds",
    "title": "mariokartds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariokartds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1312-clmariokartsupercircuit",
    "title": "mariokartsupercircuit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariokartsupercircuit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1313-clmariolostlevels",
    "title": "mariolostlevels",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariolostlevels.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1314-clmariomadness",
    "title": "mariomadness",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariomadness.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1315-clmariomakersnes",
    "title": "mariomakersnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariomakersnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1316-clmariominusrabbids",
    "title": "mariominusrabbids",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariominusrabbids.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1317-clmariopaint",
    "title": "mariopaint",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariopaint.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1318-clmarioparty",
    "title": "marioparty",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmarioparty.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1319-clmarioparty2",
    "title": "marioparty 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmarioparty2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1320-clmarioparty3",
    "title": "marioparty 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmarioparty3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1321-clmariopartyds",
    "title": "mariopartyds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariopartyds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1322-clmariosmysterymeat",
    "title": "mariosmysterymeat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariosmysterymeat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1323-clmariotennis",
    "title": "mariotennis",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariotennis.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1324-clmariotennisgb",
    "title": "mariotennisgb",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariotennisgb.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1325-clmariovsluigi",
    "title": "mariovsluigi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariovsluigi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1326-clmarvelsuperheroesarcade",
    "title": "Marvel Super Heroes Arcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMarvelSuperHeroesArcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1327-clmarvelvscapcomps1",
    "title": "Marvel Vs Capcom PS1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMarvelVsCapcomPS1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1328-clmarvelvsstreetfighter",
    "title": "Marvel Vs Street Fighter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMarvelVsStreetFighter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1329-clmarvelvsstreetfighterjp",
    "title": "marvelvsstreetfighterjp",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmarvelvsstreetfighterjp.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1330-clmaskedforcesunlimited",
    "title": "maskedforcesunlimited",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmaskedforcesunlimited.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1331-clmastermindworldconquerer",
    "title": "mastermindworldconquerer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmastermindworldconquerer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1332-clmatrixrampage",
    "title": "matrixrampage",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmatrixrampage.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1333-clmattv2",
    "title": "mattv 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmattv2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1334-clmauimallard",
    "title": "mauimallard",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmauimallard.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1335-clmaxpayne",
    "title": "maxpayne",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmaxpayne.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1336-clmcfpsfbhd",
    "title": "mcfpsfbhd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmcfpsfbhd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1337-clmcraerally",
    "title": "mcraerally",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmcraerally.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1338-clmeatboy",
    "title": "meatboy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmeatboy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1339-clmeatboyflash",
    "title": "meatboyflash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmeatboyflash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1340-clmedalofhonor",
    "title": "medalofhonor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmedalofhonor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1341-clmedievalshark",
    "title": "medievalshark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmedievalshark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1342-clmedievil",
    "title": "medievil",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmedievil.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1343-clmegacd",
    "title": "megacd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegacd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1344-clmegachess",
    "title": "megachess",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegachess.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1345-clmegaclient",
    "title": "megaclient",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaclient.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1346-clmegaman",
    "title": "megaman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1347-clmegaman2",
    "title": "megaman 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1348-clmegaman2gba",
    "title": "megaman 2 gba",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman2gba.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1349-clmegaman3",
    "title": "megaman 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1350-clmegaman4",
    "title": "megaman 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1351-clmegaman5",
    "title": "megaman 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1352-clmegaman5gb",
    "title": "megaman 5 gb",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman5gb.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1353-clmegaman6",
    "title": "megaman 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1354-clmegaman7",
    "title": "megaman 7",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman7.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1355-clmegaman8",
    "title": "megaman 8",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaman8.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1356-clmegamanbasscftf",
    "title": "megamanbasscftf",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanbasscftf.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1357-clmegamanbattlechipchallenge",
    "title": "megamanbattlechipchallenge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanbattlechipchallenge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1358-clmegamanbn5tc",
    "title": "megamanbn 5 tc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanbn5tc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1359-clmegamanbn5tp",
    "title": "megamanbn 5 tp",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanbn5tp.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1360-clmegamanbn6cf",
    "title": "megamanbn 6 cf",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanbn6cf.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1361-clmegamanbn6cg",
    "title": "megamanbn 6 cg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanbn6cg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1362-clmegamanlegends",
    "title": "megamanlegends",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanlegends.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1363-clmegamanlegends2",
    "title": "megamanlegends 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanlegends2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1364-clmegamanx",
    "title": "megamanx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1365-clmegamanx2",
    "title": "megamanx 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanx2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1366-clmegamanx3",
    "title": "megamanx 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanx3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1367-clmegamanx4",
    "title": "megamanx 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanx4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1368-clmegamanx5",
    "title": "megamanx 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanx5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1369-clmegamanx6",
    "title": "megamanx 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanx6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1370-clmegamanzero",
    "title": "megamanzero",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanzero.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1371-clmegamanzx",
    "title": "megamanzx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanzx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1372-clmegaminer",
    "title": "megaminer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegaminer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1373-clmelonplayground",
    "title": "melonplayground",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmelonplayground.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1374-clmeowuwu",
    "title": "meowuwu",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmeowuwu.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1375-clmergeroundracers",
    "title": "mergeroundracers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmergeroundracers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1376-clmetalgear",
    "title": "metalgear",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetalgear.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1377-clmetalgearsolid",
    "title": "metalgearsolid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetalgearsolid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1378-clmetalgearsolidps",
    "title": "metalgearsolidps",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetalgearsolidps.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1379-clmetalslug",
    "title": "metalslug",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetalslug.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1380-clmetalslug2",
    "title": "metalslug 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetalslug2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1381-clmetalslugadvance",
    "title": "metalslugadvance",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetalslugadvance.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1382-clmetalslugmission1",
    "title": "metalslugmission 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetalslugmission1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1383-clmetalslugmission2",
    "title": "metalslugmission 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetalslugmission2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1384-clmetalsonichyperdrive",
    "title": "Metal Sonic Hyperdrive",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMetalSonicHyperdrive.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1385-clmetroid",
    "title": "metroid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetroid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1386-clmetroid2",
    "title": "metroid 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetroid2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1387-clmetroidfusion",
    "title": "metroidfusion",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetroidfusion.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1388-clmetroidprimehunters",
    "title": "metroidprimehunters",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetroidprimehunters.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1389-clmetroidzeromission",
    "title": "metroidzeromission",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmetroidzeromission.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1390-clmiamishark",
    "title": "miamishark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmiamishark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1391-clmickeymaniasnes",
    "title": "mickeymaniasnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmickeymaniasnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1392-clmicrolife",
    "title": "microlife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmicrolife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1393-clmicromages",
    "title": "micromages",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmicromages.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1394-clmidwaysgreatesthitsn64",
    "title": "midwaysgreatesthitsn 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmidwaysgreatesthitsn64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1395-clmightyknight",
    "title": "mightyknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmightyknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1396-clmightyknight2",
    "title": "mightyknight 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmightyknight2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1397-clmimic",
    "title": "mimic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmimic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1398-clminceraft-i-notmine-v6-1-",
    "title": "Minceraft-I-Not Mine V6(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMinceraft-I-NotMine_V6(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1399-clminceraft-i-notmine-v6",
    "title": "Minceraft-I-Not Mine V6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMinceraft-I-NotMine_V6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1400-clmindscape",
    "title": "mindscape",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmindscape.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1401-clmindwave",
    "title": "mindwave",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmindwave.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1402-clminecaves",
    "title": "minecaves",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminecaves.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1403-clminecraft1-8-8",
    "title": "minecraft 1-8-8",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminecraft1-8-8.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1404-clminecraftcasesim",
    "title": "minecraftcasesim",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminecraftcasesim.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1405-clminecraftpocketedition",
    "title": "minecraftpocketedition",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminecraftpocketedition.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1406-clminecraftshooter",
    "title": "minecraftshooter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminecraftshooter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1407-clminecrafttowerdefense",
    "title": "MINECRAFTTOWERDEFENSE",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMINECRAFTTOWERDEFENSE.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1408-clmineshooter",
    "title": "mineshooter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmineshooter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1409-clminesweeperplus",
    "title": "minesweeperplus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminesweeperplus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1410-clminhero",
    "title": "minhero",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminhero.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1411-clminicrossword",
    "title": "minicrossword",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminicrossword.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1412-clminiflips",
    "title": "miniflips",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminiflips.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1413-clminimart",
    "title": "minimart",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminimart.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1414-clminishooters",
    "title": "minishooters",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminishooters.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1415-clminitooth",
    "title": "minitooth",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clminitooth.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1416-clmiraginewar",
    "title": "miraginewar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmiraginewar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1417-clmisslecommand",
    "title": "misslecommand",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmisslecommand.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1418-clmk4ampedup",
    "title": "mk 4 ampedup",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmk4ampedup.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1419-clmkmythologiesn64",
    "title": "mkmythologiesn 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmkmythologiesn64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1420-clmktrilogyps1",
    "title": "mktrilogyps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmktrilogyps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1421-clmmbn3b",
    "title": "mmbn 3 b",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmbn3b.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1422-clmmbn3w",
    "title": "mmbn 3 w",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmbn3w.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1423-clmmbn4bm",
    "title": "mmbn 4 bm",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmbn4bm.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1424-clmmbn4rs",
    "title": "mmbn 4 rs",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmbn4rs.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1425-clmmbnws",
    "title": "mmbnws",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmbnws.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1426-clmmsf2zxn",
    "title": "mmsf 2 zxn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmsf2zxn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1427-clmmsf2zxs",
    "title": "mmsf 2 zxs",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmsf2zxs.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1428-clmmsf3ba",
    "title": "mmsf 3 ba",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmsf3ba.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1429-clmmsf3rj",
    "title": "mmsf 3 rj",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmsf3rj.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1430-clmmsfd",
    "title": "mmsfd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmsfd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1431-clmmsfl",
    "title": "mmsfl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmsfl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1432-clmmsfp",
    "title": "mmsfp",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmsfp.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1433-clmmwilywars",
    "title": "mmwilywars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmmwilywars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1434-clmo64-1-",
    "title": "mo 64(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmo64(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1435-clmo64",
    "title": "mo 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmo64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1436-clmobcontrolhtml5",
    "title": "mobcontrolhtml 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmobcontrolhtml5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1437-clmobiusrevolution",
    "title": "mobiusrevolution",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmobiusrevolution.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1438-clmoemon-emerald-vanilla---v110-",
    "title": "Moemon Emerald Vanilla+ (v 110)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMoemon%20Emerald%20Vanilla%2B%20(v110).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1439-clmomimsleeping",
    "title": "momimsleeping",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmomimsleeping.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1440-clmomoscrushers",
    "title": "momoscrushers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmomoscrushers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1441-clmoneyrush",
    "title": "moneyrush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmoneyrush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1442-clmonkeymart",
    "title": "monkeymart",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmonkeymart.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1443-clmonkeymartenc",
    "title": "monkeymartenc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmonkeymartenc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1444-clmonsterderby",
    "title": "monsterderby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmonsterderby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1445-clmonsterswing",
    "title": "monsterswing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmonsterswing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1446-clmonstertracks",
    "title": "monstertracks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmonstertracks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1447-clmonstertruckcurfew",
    "title": "monstertruckcurfew",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmonstertruckcurfew.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1448-clmonstertruckportstunt",
    "title": "monstertruckportstunt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmonstertruckportstunt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1449-clmoonemeraldextremerandomizer",
    "title": "moonemeraldextremerandomizer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmoonemeraldextremerandomizer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1450-clmortalkombat",
    "title": "mortalkombat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmortalkombat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1451-clmortalkombat2",
    "title": "mortalkombat 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmortalkombat2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1452-clmortalkombat2a",
    "title": "mortalkombat 2 a",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmortalkombat2a.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1453-clmortalkombat3",
    "title": "mortalkombat 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmortalkombat3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1454-clmortalkombat3a",
    "title": "mortalkombat 3 a",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmortalkombat3a.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1455-clmortalkombat4",
    "title": "mortalkombat 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmortalkombat4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1456-clmortalkombata",
    "title": "mortalkombata",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmortalkombata.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1457-clmortalkombatadvance",
    "title": "mortalkombatadvance",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmortalkombatadvance.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1458-clmortkom4",
    "title": "mortkom 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmortkom4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1459-clmotherload",
    "title": "motherload",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmotherload.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1460-clmotoroadrash",
    "title": "motoroadrash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmotoroadrash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1461-clmotox3m2",
    "title": "motox 3 m 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmotox3m2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1462-clmotox3m3",
    "title": "motox 3 m 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmotox3m3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1463-clmotox3mm",
    "title": "motox 3 mm",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmotox3mm.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1464-clmotox3mpoolparty",
    "title": "motox 3 mpoolparty",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmotox3mpoolparty.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1465-clmotox3mspookyland",
    "title": "motox 3 mspookyland",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmotox3mspookyland.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1466-clmotox3mwinter",
    "title": "motox 3 mwinter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmotox3mwinter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1467-clmountainbikeracer",
    "title": "mountainbikeracer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmountainbikeracer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1468-clmrmine",
    "title": "mrmine",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmrmine.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1469-clmrracer",
    "title": "mrracer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmrracer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1470-clmspacman--1-",
    "title": "mspacman (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmspacman%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1471-clmspacman-1-",
    "title": "mspacman(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmspacman(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1472-clmspacman-2-",
    "title": "mspacman(2)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmspacman(2).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1473-clmspacman",
    "title": "mspacman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmspacman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1474-clmultitask",
    "title": "multitask",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmultitask.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1475-clmutilate-a-doll",
    "title": "mutilate-a-doll",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmutilate-a-doll.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1476-clmvpbaseball",
    "title": "mvpbaseball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmvpbaseball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1477-clmxoffroadmaster",
    "title": "mxoffroadmaster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmxoffroadmaster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1478-clmyfriendpedro",
    "title": "myfriendpedro",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmyfriendpedro.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1479-clmyfriendpedroarena",
    "title": "myfriendpedroarena",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmyfriendpedroarena.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1480-clmyteardrop",
    "title": "myteardrop",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmyteardrop.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1481-cln",
    "title": "n",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cln.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1482-clnarc",
    "title": "narc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnarc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1483-clnatsuki64",
    "title": "natsuki 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnatsuki64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1484-clnaturalselection",
    "title": "naturalselection",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnaturalselection.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1485-clnautilusos-1-",
    "title": "Nautilus OS(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clNautilusOS(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1486-clnautilusos",
    "title": "Nautilus OS",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clNautilusOS.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1487-clnbahangtime",
    "title": "NBAhangtime",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clNBAhangtime.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1488-clnbajam",
    "title": "NBAjam",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clNBAjam.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1489-clnbajamte",
    "title": "nbajam TE",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnbajamTE.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1490-clnbalive2000",
    "title": "nbalive 2000",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnbalive2000.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1491-clnbalive2003",
    "title": "nbalive 2003",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnbalive2003.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1492-clnblox",
    "title": "nblox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnblox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1493-clneonblaster",
    "title": "neonblaster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clneonblaster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1494-clneonrider",
    "title": "neonrider",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clneonrider.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1495-clnesworldchampion",
    "title": "nesworldchampion",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnesworldchampion.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1496-clnetattack",
    "title": "netattack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnetattack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1497-clneverendinglegacy",
    "title": "neverendinglegacy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clneverendinglegacy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1498-clnewersmbds",
    "title": "newersmbds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnewersmbds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1499-clnewgroundsrumble",
    "title": "newgroundsrumble",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnewgroundsrumble.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1500-clnewsupermariobros",
    "title": "newsupermariobros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnewsupermariobros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1501-clnewsupermarioworld2aroundtheworld",
    "title": "New Super Mario World 2 Aroundthe World",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clNewSuperMarioWorld2AroundtheWorld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1502-clnewyorkshark",
    "title": "newyorkshark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnewyorkshark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1503-clnextdoor",
    "title": "nextdoor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnextdoor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1504-clnflblitz",
    "title": "nflblitz",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnflblitz.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1505-clnfscarbonowncity",
    "title": "nfscarbonowncity",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnfscarbonowncity.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1506-clnfsmostwanted",
    "title": "nfsmostwanted",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnfsmostwanted.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1507-clnfsporcheunleashed",
    "title": "nfsporcheunleashed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnfsporcheunleashed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1508-clnfsunderground",
    "title": "nfsunderground",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnfsunderground.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1509-clnfsunderground2",
    "title": "nfsunderground 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnfsunderground2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1510-clngon-1-",
    "title": "ngon(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clngon(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1511-clngon",
    "title": "ngon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clngon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1512-clnhl2002",
    "title": "nhl 2002",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnhl2002.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1513-clnhl98",
    "title": "nhl 98",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnhl98.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1514-clnhlhitz2003",
    "title": "nhlhitz 2003",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnhlhitz2003.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1515-clnickelodeonsuperbrawl2",
    "title": "nickelodeonsuperbrawl 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnickelodeonsuperbrawl2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1516-clnicktoonsfreezeframefrenzy",
    "title": "Nicktoons Freeze Frame Frenzy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clNicktoonsFreezeFrameFrenzy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1517-clnightcatsurvival",
    "title": "nightcatsurvival",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnightcatsurvival.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1518-clnightclubshowdown",
    "title": "nightclubshowdown",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnightclubshowdown.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1519-clnightfire",
    "title": "nightfire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnightfire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1520-clnightshade",
    "title": "nightshade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnightshade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1521-clnikehub",
    "title": "nikehub",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnikehub.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1522-clnimrods",
    "title": "nimrods",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnimrods.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1523-clninjabrawl",
    "title": "ninjabrawl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clninjabrawl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1524-clninjaobbyparkor",
    "title": "ninjaobbyparkor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clninjaobbyparkor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1525-clnintendogslab",
    "title": "nintendogslab",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnintendogslab.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1526-clnintendoworldcup",
    "title": "nintendoworldcup",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnintendoworldcup.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1527-clnitclient",
    "title": "nitclient",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnitclient.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1528-clnitromemustdie",
    "title": "nitromemustdie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnitromemustdie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1529-clnomoregameasdsadfagfggdfs",
    "title": "nomoregameasdsadfagfggdfs",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnomoregameasdsadfagfggdfs.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1530-clnoobminer",
    "title": "noobminer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnoobminer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1531-clnotyourpawn",
    "title": "notyourpawn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnotyourpawn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1532-clnovaclient",
    "title": "novaclient",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnovaclient.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1533-clnplus",
    "title": "nplus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnplus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1534-clnsmbuds",
    "title": "nsmbuds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnsmbuds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1535-clnsmbwds",
    "title": "nsmbwds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnsmbwds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1536-clnubbysnumberfactory",
    "title": "nubbysnumberfactory",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnubbysnumberfactory.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1537-clnullkevin",
    "title": "nullkevin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnullkevin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1538-clnutsandboltsscrewingpuzzle",
    "title": "Nutsand Bolts Screwing Puzzle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clNutsandBoltsScrewingPuzzle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1539-clnzp",
    "title": "nzp",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnzp.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1540-clobby-99-will-lose",
    "title": "obby-99-will-lose",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobby-99-will-lose.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1541-clobby1jumpperclick",
    "title": "obby 1 jumpperclick",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobby1jumpperclick.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1542-clobby456",
    "title": "obby 456",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobby456.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1543-clobbybike",
    "title": "obbybike",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobbybike.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1544-clobbycart",
    "title": "obbycart",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobbycart.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1545-clobbyonlyup",
    "title": "obbyonlyup",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobbyonlyup.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1546-clobbyrainbowtower",
    "title": "obbyrainbowtower",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobbyrainbowtower.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1547-clobbyslide",
    "title": "obbyslide",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobbyslide.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1548-clobbyswing",
    "title": "obbyswing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobbyswing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1549-clobbyyardsale",
    "title": "obbyyardsale",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobbyyardsale.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1550-clobeythegame",
    "title": "obeythegame",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clobeythegame.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1551-clocarinaoftime",
    "title": "ocarinaoftime",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clocarinaoftime.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1552-cloddbotout",
    "title": "oddbotout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cloddbotout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1553-cloddfuture",
    "title": "oddfuture",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cloddfuture.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1554-clofflineparadise",
    "title": "offlineparadise",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clofflineparadise.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1555-clohflip",
    "title": "ohflip",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clohflip.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1556-clomegalayers",
    "title": "omegalayers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clomegalayers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1557-clomeganuggetclicker",
    "title": "omeganuggetclicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clomeganuggetclicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1558-clomnipresent",
    "title": "omnipresent",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clomnipresent.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1559-clonebitadventure",
    "title": "onebitadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clonebitadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1560-clonenightasfreddy",
    "title": "onenightasfreddy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clonenightasfreddy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1561-clonepiece",
    "title": "onepiece",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clonepiece.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1562-clonepiecefighting",
    "title": "onepiecefighting",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clonepiecefighting.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1563-cloneshotold",
    "title": "oneshotold",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cloneshotold.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1564-clonlyup",
    "title": "onlyup",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clonlyup.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1565-clootmasterquest",
    "title": "Oot Master Quest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clOotMasterQuest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1566-cloperius",
    "title": "operius",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cloperius.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1567-cloppositeday",
    "title": "oppositeday",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cloppositeday.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1568-clopposumcountry",
    "title": "opposumcountry",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clopposumcountry.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1569-clorangeroulette",
    "title": "Orange Roulette",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clOrangeRoulette.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1570-clorbofcreation",
    "title": "orbofcreation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clorbofcreation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1571-clordinarysonicromhack",
    "title": "ordinarysonicromhack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clordinarysonicromhack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1572-cloregontrail",
    "title": "oregontrail",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cloregontrail.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1573-clorigamiking",
    "title": "origamiking",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clorigamiking.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1574-clormmimastickwithclsoitcanberememberedoyeahclalienhominid",
    "title": "ormmimastickwithclsoitcanberememberedoyeahclalienhominid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clormmimastickwithclsoitcanberememberedoyeahclalienhominid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1575-clortalkombat4",
    "title": "ortalkombat 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clortalkombat4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1576-closu",
    "title": "osu",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/closu.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1577-clourpleguy",
    "title": "ourpleguy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clourpleguy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1578-clouthold",
    "title": "outhold",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clouthold.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1579-cloutnumbered",
    "title": "outnumbered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cloutnumbered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1580-cloutrunarcade",
    "title": "Outrun Arcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clOutrunArcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1581-cloutrungenesis",
    "title": "Outrun Genesis",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clOutrunGenesis.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1582-cloverburden",
    "title": "overburden",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cloverburden.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1583-clovo",
    "title": "ovo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clovo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1584-clovo2",
    "title": "ovo 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clovo2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1585-clovodimensions",
    "title": "ovodimensions",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clovodimensions.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1586-clovofixed",
    "title": "ovofixed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clovofixed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1587-clpacman",
    "title": "pacman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpacman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1588-clpacmana",
    "title": "pacmana",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpacmana.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1589-clpacmansuperfast",
    "title": "pacmansuperfast",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpacmansuperfast.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1590-clpacmanworld3",
    "title": "pacmanworld 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpacmanworld3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1591-clpacmanworldg",
    "title": "pacmanworldg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpacmanworldg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1592-clpacmanworldpsx",
    "title": "pacmanworldpsx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpacmanworldpsx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1593-clpandameic2",
    "title": "pandameic 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpandameic2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1594-clpapabakeria",
    "title": "papabakeria",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapabakeria.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1595-clpapadonut",
    "title": "papadonut",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapadonut.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1596-clpapalouienighthunt2",
    "title": "papalouienighthunt 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapalouienighthunt2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1597-clpapalouiewhenburgersattack",
    "title": "papalouiewhenburgersattack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapalouiewhenburgersattack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1598-clpapalouiewhenpizzasattack",
    "title": "papalouiewhenpizzasattack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapalouiewhenpizzasattack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1599-clpapalouiewhensundaesattack",
    "title": "papalouiewhensundaesattack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapalouiewhensundaesattack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1600-clpapapizzagood",
    "title": "papapizzagood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapapizzagood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1601-clpapapizzagoody",
    "title": "papapizzagoody",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapapizzagoody.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1602-clpapapizzamamamia",
    "title": "papapizzamamamia",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapapizzamamamia.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1603-clpapasburgeriiiaaaaa",
    "title": "papasburger IIIAAAAA",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapasburgerIIIAAAAA.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1604-clpapascheeseria",
    "title": "papascheeseria",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapascheeseria.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1605-clpapascupcakeria",
    "title": "papascupcakeria",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapascupcakeria.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1606-clpapasfreezeria",
    "title": "papasfreezeria",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapasfreezeria.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1607-clpapashotdoggeria",
    "title": "papashotdoggeria",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapashotdoggeria.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1608-clpapaspancakeria",
    "title": "papaspancakeria",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapaspancakeria.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1609-clpapaspastaria",
    "title": "papaspastaria",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapaspastaria.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1610-clpapasscooperia",
    "title": "papasscooperia",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapasscooperia.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1611-clpapassushiria",
    "title": "papassushiria",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapassushiria.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1612-clpapastacomia",
    "title": "papastacomia",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapastacomia.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1613-clpapaswingeria",
    "title": "papaswingeria",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapaswingeria.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1614-clpaperio",
    "title": "paperio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpaperio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1615-clpaperio3d",
    "title": "paperio 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpaperio3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1616-clpaperiomania",
    "title": "paperiomania",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpaperiomania.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1617-clpapermario",
    "title": "papermario",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapermario.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1618-clpapermariodse",
    "title": "Paper Mario DSE",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPaperMarioDSE.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1619-clpapermariopracticehack",
    "title": "Paper Mario Practice Hack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPaperMarioPracticeHack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1620-clpapermariopromode",
    "title": "papermariopromode",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapermariopromode.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1621-clpapermariottyd",
    "title": "papermariottyd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpapermariottyd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1622-clparappatherapper",
    "title": "parappatherapper",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clparappatherapper.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1623-clparappatherapperalt",
    "title": "parappatherapperalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clparappatherapperalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1624-clparkingfury",
    "title": "parkingfury",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clparkingfury.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1625-clparkingfury2",
    "title": "parkingfury 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clparkingfury2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1626-clparkingfury3",
    "title": "parkingfury 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clparkingfury3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1627-clparkingrush",
    "title": "parkingrush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clparkingrush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1628-clpartnersintime",
    "title": "partnersintime",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpartnersintime.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1629-clpeacekeeper",
    "title": "peacekeeper",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpeacekeeper.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1630-clpeach",
    "title": "peach",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpeach.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1631-clpeggle",
    "title": "peggle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpeggle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1632-clpenaltykicks",
    "title": "penaltykicks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpenaltykicks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1633-clpenguindiner",
    "title": "penguindiner",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpenguindiner.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1634-clpenguinpass",
    "title": "penguinpass",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpenguinpass.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1635-clpepsiman",
    "title": "pepsiman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpepsiman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1636-clpepsimanalt",
    "title": "pepsimanalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpepsimanalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1637-clpereelous",
    "title": "pereelous",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpereelous.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1638-clperfectdark",
    "title": "perfectdark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clperfectdark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1639-clperfecthotel",
    "title": "perfecthotel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clperfecthotel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1640-clpersona",
    "title": "persona",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpersona.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1641-clpersona2",
    "title": "persona 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpersona2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1642-clpersona2alt",
    "title": "persona 2 alt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpersona2alt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1643-clpersonaalt",
    "title": "personaalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpersonaalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1644-clpetworld",
    "title": "petworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpetworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1645-clphantasystar",
    "title": "phantasystar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clphantasystar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1646-clphantasystar2",
    "title": "phantasystar 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clphantasystar2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1647-clphantasystar3",
    "title": "phantasystar 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clphantasystar3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1648-clphantasystar4",
    "title": "phantasystar 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clphantasystar4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1649-clphasma",
    "title": "phasma",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clphasma.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1650-clpheonixjusticeforall",
    "title": "pheonixjusticeforall",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpheonixjusticeforall.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1651-clpheonixrightaceattorny",
    "title": "pheonixrightaceattorny",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpheonixrightaceattorny.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1652-clpheonixtrialsandyear",
    "title": "pheonixtrialsandyear",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpheonixtrialsandyear.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1653-clpheonixtrialsandyeartrhfasd",
    "title": "pheonixtrialsandyeartrhfasd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpheonixtrialsandyeartrhfasd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1654-clpibbyapocalypse",
    "title": "pibbyapocalypse",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpibbyapocalypse.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1655-clpiclient",
    "title": "piclient",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpiclient.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1656-clpico8",
    "title": "pico 8",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpico8.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1657-clpico8edu",
    "title": "pico 8 edu",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpico8edu.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1658-clpicodriller",
    "title": "picodriller",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpicodriller.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1659-clpicohot",
    "title": "picohot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpicohot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1660-clpicolife",
    "title": "picolife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpicolife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1661-clpiconightpunkin",
    "title": "piconightpunkin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpiconightpunkin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1662-clpicosschool",
    "title": "picosschool",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpicosschool.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1663-clpicovsbeardx",
    "title": "picovsbeardx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpicovsbeardx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1664-clpiecesofcake",
    "title": "piecesofcake",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpiecesofcake.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1665-clpikwip",
    "title": "pikwip",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpikwip.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1666-clpingpongchaos",
    "title": "pingpongchaos",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpingpongchaos.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1667-clpinkbike",
    "title": "pinkbike",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpinkbike.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1668-clpint",
    "title": "pint",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpint.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1669-clpitfall",
    "title": "pitfall",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpitfall.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1670-clpitof100trials",
    "title": "pitof 100 trials",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpitof100trials.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1671-clpixelbattlegroundsio",
    "title": "pixelbattlegroundsio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpixelbattlegroundsio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1672-clpixelcombat2",
    "title": "pixelcombat 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpixelcombat2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1673-clpixelgun",
    "title": "pixelgun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpixelgun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1674-clpixelquestlostidols",
    "title": "pixelquestlostidols",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpixelquestlostidols.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1675-clpixelshooter",
    "title": "pixelshooter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpixelshooter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1676-clpixelspeedrun",
    "title": "pixelspeedrun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpixelspeedrun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1677-clpixelwarfare",
    "title": "pixelwarfare",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpixelwarfare.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1678-clpizzapapa",
    "title": "pizzapapa",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpizzapapa.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1679-clpizzatower",
    "title": "pizzatower",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpizzatower.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1680-clpkmnarutoans",
    "title": "pkmnarutoans",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpkmnarutoans.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1681-clplanetlife",
    "title": "planetlife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clplanetlife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1682-clplangman",
    "title": "plangman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clplangman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1683-clplantsvszombies",
    "title": "plantsvszombies",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clplantsvszombies.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1684-clplantsvszombiesnds",
    "title": "plantsvszombiesnds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clplantsvszombiesnds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1685-clplazmaburst",
    "title": "plazmaburst",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clplazmaburst.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1686-clplinko",
    "title": "plinko",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clplinko.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1687-clplonky",
    "title": "plonky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clplonky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1688-clpogo3d",
    "title": "pogo 3 D",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpogo3D.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1689-clpokeacademylifeforever",
    "title": "pokeacademylifeforever",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeacademylifeforever.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1690-clpokeallin",
    "title": "pokeallin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeallin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1691-clpokeambrosia",
    "title": "Poke Ambrosia",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeAmbrosia.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1692-clpokebattlefact",
    "title": "pokebattlefact",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokebattlefact.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1693-clpokeblack",
    "title": "pokeblack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeblack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1694-clpokeblack2alt",
    "title": "pokeblack 2 alt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeblack2alt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1695-clpokeblack2html",
    "title": "pokeblack 2 html",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeblack2html.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1696-clpokeblackalt",
    "title": "pokeblackalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeblackalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1697-clpokeblazeblack2redux",
    "title": "pokeblazeblack 2 redux",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeblazeblack2redux.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1698-clpokeblue",
    "title": "pokeblue",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeblue.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1699-clpokeclassic",
    "title": "pokeclassic",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeclassic.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1700-clpokecrown",
    "title": "pokecrown",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokecrown.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1701-clpokecrystaladvanceredux",
    "title": "pokecrystaladvanceredux",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokecrystaladvanceredux.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1702-clpokecrystalclear",
    "title": "pokecrystalclear",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokecrystalclear.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1703-clpokediamond",
    "title": "pokediamond",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokediamond.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1704-clpokedreamstone",
    "title": "pokedreamstone",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokedreamstone.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1705-clpokeeliteredux",
    "title": "pokeeliteredux",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeeliteredux.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1706-clpokeelysiuma",
    "title": "pokeelysiuma",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeelysiuma.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1707-clpokeelysiumb",
    "title": "pokeelysiumb",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeelysiumb.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1708-clpokeemeraldenhanced",
    "title": "pokeemeraldenhanced",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldenhanced.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1709-clpokeemeraldexceeded",
    "title": "pokeemeraldexceeded",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldexceeded.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1710-clpokeemeraldhorizons",
    "title": "pokeemeraldhorizons",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldhorizons.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1711-clpokeemeraldimperium",
    "title": "pokeemeraldimperium",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldimperium.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1712-clpokeemeraldrandom",
    "title": "pokeemeraldrandom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldrandom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1713-clpokeemeraldrogue",
    "title": "pokeemeraldrogue",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldrogue.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1714-clpokeemeraldrogueex",
    "title": "Poke Emerald Rogue EX",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeEmeraldRogueEX.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1715-clpokeemeraldz",
    "title": "pokeemeraldz",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldz.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1716-clpokefiregold",
    "title": "pokefiregold",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokefiregold.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1717-clpokeflora",
    "title": "pokeflora",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeflora.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1718-clpokefrlgplus",
    "title": "pokefrlgplus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokefrlgplus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1719-clpokefuseddimension",
    "title": "pokefuseddimension",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokefuseddimension.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1720-clpokefusion3",
    "title": "Poke Fusion 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeFusion3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1721-clpokegaia",
    "title": "pokegaia",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokegaia.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1722-clpokegoldenshield",
    "title": "pokegoldenshield",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokegoldenshield.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1723-clpokegschronicles",
    "title": "pokegschronicles",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokegschronicles.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1724-clpokeheartgold",
    "title": "pokeheartgold",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeheartgold.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1725-clpokeheartgoldgenerations",
    "title": "Poke Heartgold Generations",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeHeartgoldGenerations.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1726-clpokelightplatinum",
    "title": "pokelightplatinum",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokelightplatinum.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1727-clpokeliquidcrysta",
    "title": "pokeliquidcrysta",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeliquidcrysta.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1728-clpokemegamoemon",
    "title": "pokemegamoemon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemegamoemon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1729-clpokemonamnesia",
    "title": "pokemonamnesia",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonamnesia.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1730-clpokemonclover",
    "title": "pokemonclover",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonclover.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1731-clpokemoncrystal",
    "title": "pokemoncrystal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemoncrystal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1732-clpokemonemerald",
    "title": "pokemonemerald",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonemerald.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1733-clpokemonemeraldcrest",
    "title": "pokemonemeraldcrest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonemeraldcrest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1734-clpokemonemeraldimperium",
    "title": "pokemonemeraldimperium",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonemeraldimperium.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1735-clpokemonemeraldkaizo",
    "title": "pokemonemeraldkaizo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonemeraldkaizo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1736-clpokemonemeraldmini",
    "title": "pokemonemeraldmini",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonemeraldmini.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1737-clpokemonemeraldrouge",
    "title": "Pokemonemeraldrouge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokemonemeraldrouge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1738-clpokemonemeraldseaglass",
    "title": "pokemonemeraldseaglass",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonemeraldseaglass.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1739-clpokemonenergizedemerald",
    "title": "pokemonenergizedemerald",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonenergizedemerald.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1740-clpokemonevolvedsfdgsdfs",
    "title": "pokemonevolvedsfdgsdfs",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonevolvedsfdgsdfs.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1741-clpokemonfirered",
    "title": "pokemonfirered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonfirered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1742-clpokemonfireredandleafgreenplusedition",
    "title": "pokemonfireredandleafgreenplusedition",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonfireredandleafgreenplusedition.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1743-clpokemonfireredrandomized",
    "title": "pokemonfireredrandomized",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonfireredrandomized.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1744-clpokemongold",
    "title": "pokemongold",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemongold.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1745-clpokemonkaizoironfirered",
    "title": "pokemonkaizoironfirered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonkaizoironfirered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1746-clpokemonlazarus",
    "title": "pokemonlazarus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonlazarus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1747-clpokemonleafgreen",
    "title": "pokemonleafgreen",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonleafgreen.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1748-clpokemonmodernemerald",
    "title": "pokemonmodernemerald",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonmodernemerald.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1749-clpokemonmysterydungeon",
    "title": "pokemonmysterydungeon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonmysterydungeon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1750-clpokemonperfectemerald55",
    "title": "pokemonperfectemerald 55",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonperfectemerald55.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1751-clpokemonquetzal",
    "title": "pokemonquetzal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonquetzal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1752-clpokemonroaringred",
    "title": "pokemonroaringred",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonroaringred.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1753-clpokemonrocketedition",
    "title": "Pokemonrocketedition",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokemonrocketedition.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1754-clpokemonruby",
    "title": "pokemonruby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonruby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1755-clpokemonsaiph",
    "title": "pokemonsaiph",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonsaiph.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1756-clpokemonsaiph2",
    "title": "pokemonsaiph 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonsaiph2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1757-clpokemonsapphire",
    "title": "pokemonsapphire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonsapphire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1758-clpokemonshinsigma",
    "title": "pokemonshinsigma",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonshinsigma.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1759-clpokemonsilver",
    "title": "pokemonsilver",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonsilver.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1760-clpokemonslgreen",
    "title": "pokemonslgreen",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonslgreen.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1761-clpokemonsmred",
    "title": "pokemonsmred",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonsmred.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1762-clpokemonsnap",
    "title": "pokemonsnap",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonsnap.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1763-clpokemonsors",
    "title": "pokemonsors",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonsors.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1764-clpokemonsors2",
    "title": "pokemonsors 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonsors2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1765-clpokemonstadium",
    "title": "pokemonstadium",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonstadium.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1766-clpokemonstadium2",
    "title": "pokemonstadium 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonstadium2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1767-clpokemontowerdefense",
    "title": "pokemontowerdefense",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemontowerdefense.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1768-clpokemonultimatefusion",
    "title": "pokemonultimatefusion",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonultimatefusion.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1769-clpokemonunbound",
    "title": "pokemonunbound",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonunbound.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1770-clpokemonvolume1",
    "title": "pokemonvolume 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonvolume1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1771-clpokemonvolume2",
    "title": "pokemonvolume 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonvolume2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1772-clpokemonvolume3",
    "title": "pokemonvolume 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonvolume3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1773-clpokemonvolume4",
    "title": "pokemonvolume 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonvolume4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1774-clpokemoonemerald",
    "title": "pokemoonemerald",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemoonemerald.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1775-clpokemoongalaxy",
    "title": "pokemoongalaxy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemoongalaxy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1776-clpokemysteryexplorersofsky",
    "title": "pokemysteryexplorersofsky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemysteryexplorersofsky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1777-clpokenameless",
    "title": "pokenameless",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokenameless.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1778-clpokeodyssey",
    "title": "pokeodyssey",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeodyssey.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1779-clpokepasta",
    "title": "pokepasta",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepasta.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1780-clpokepath",
    "title": "pokepath",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepath.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1781-clpokepearl",
    "title": "pokepearl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepearl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1782-clpokeperfectfirered",
    "title": "pokeperfectfirered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeperfectfirered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1783-clpokepisces",
    "title": "pokepisces",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepisces.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1784-clpokeplatinum",
    "title": "pokeplatinum",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeplatinum.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1785-clpokeplatinumrandomized",
    "title": "pokeplatinumrandomized",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeplatinumrandomized.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1786-clpokepureblue",
    "title": "pokepureblue",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepureblue.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1787-clpokepuregreen",
    "title": "pokepuregreen",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepuregreen.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1788-clpokepurered",
    "title": "pokepurered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepurered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1789-clpokerechargedpink",
    "title": "pokerechargedpink",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokerechargedpink.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1790-clpokerechargedyellow",
    "title": "pokerechargedyellow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokerechargedyellow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1791-clpokerecordkeepers",
    "title": "pokerecordkeepers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokerecordkeepers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1792-clpokered",
    "title": "pokered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1793-clpokerenegadeplat",
    "title": "pokerenegadeplat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokerenegadeplat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1794-clpokerocketedition",
    "title": "pokerocketedition",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokerocketedition.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1795-clpokerowe",
    "title": "pokerowe",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokerowe.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1796-clpokeruby",
    "title": "pokeruby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeruby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1797-clpokerunandbun",
    "title": "pokerunandbun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokerunandbun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1798-clpokescorchedsilver",
    "title": "pokescorchedsilver",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokescorchedsilver.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1799-clpokesoulsilver",
    "title": "pokesoulsilver",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokesoulsilver.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1800-clpokesunsky",
    "title": "pokesunsky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokesunsky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1801-clpoketcg1",
    "title": "poketcg 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpoketcg1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1802-clpoketcg2",
    "title": "poketcg 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpoketcg2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1803-clpokethepit",
    "title": "pokethepit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokethepit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1804-clpokethetaemeraldex",
    "title": "Poke Theta Emerald EX",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeThetaEmeraldEX.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1805-clpoketoomanytypes2",
    "title": "poketoomanytypes 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpoketoomanytypes2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1806-clpoketourmaline",
    "title": "poketourmaline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpoketourmaline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1807-clpokeultraviolet",
    "title": "pokeultraviolet",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeultraviolet.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1808-clpokeunovaemerald",
    "title": "pokeunovaemerald",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeunovaemerald.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1809-clpokevega",
    "title": "pokevega",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokevega.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1810-clpokevoltwhite2redux",
    "title": "pokevoltwhite 2 redux",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokevoltwhite2redux.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1811-clpokevoyager",
    "title": "pokevoyager",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokevoyager.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1812-clpokewhite",
    "title": "pokewhite",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokewhite.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1813-clpokewhite2",
    "title": "pokewhite 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokewhite2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1814-clpokewhite2alt",
    "title": "pokewhite 2 alt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokewhite2alt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1815-clpokeyellow",
    "title": "pokeyellow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeyellow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1816-clpok-mon-emerald-rush-edition--20-",
    "title": "Pok�mon Emerald Rush Edition (20)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPok%EF%BF%BDmon%20Emerald%20Rush%20Edition%20(20).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1817-clpok-mon-trade--stache--v11-",
    "title": "Pok�mon Trade& Stache (V11)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPok%EF%BF%BDmon%20Trade%26_Stache%20(V11).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1818-clpok-mon-two--v11-",
    "title": "Pok�mon TWO (v 11)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPok%EF%BF%BDmon%20TWO%20(v11).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1819-clpok-monstunningsteel",
    "title": "Pok�monstunningsteel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPok%EF%BF%BDmonstunningsteel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1820-clpolicepursuit2",
    "title": "policepursuit 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpolicepursuit2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1821-clpolishedcrystal",
    "title": "polishedcrystal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpolishedcrystal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1822-clpolytrackbutnotflagged-1-",
    "title": "polytrackbutnotflagged(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpolytrackbutnotflagged(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1823-clpolytrackbutnotflagged",
    "title": "polytrackbutnotflagged",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpolytrackbutnotflagged.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1824-clpolytrackworksnow",
    "title": "polytrackworksnow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpolytrackworksnow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1825-clpomgetsinternet",
    "title": "pomgetsinternet",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpomgetsinternet.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1826-clpoorbunny",
    "title": "poorbunny",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpoorbunny.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1827-clpopeyepapi",
    "title": "popeyepapi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpopeyepapi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1828-clporklike",
    "title": "porklike",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clporklike.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1829-clportal",
    "title": "portal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clportal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1830-clportal2d",
    "title": "portal 2 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clportal2d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1831-clportaldefendersfastbreak",
    "title": "portaldefendersfastbreak",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clportaldefendersfastbreak.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1832-clportaldefenderstd",
    "title": "portaldefenders TD",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clportaldefendersTD.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1833-clportalflash",
    "title": "portalflash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clportalflash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1834-clporter",
    "title": "porter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clporter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1835-clportraitofruin",
    "title": "portraitofruin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clportraitofruin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1836-clpossessquest",
    "title": "possessquest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpossessquest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1837-clpostal",
    "title": "postal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpostal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1838-clpotatomanseeksthetroof",
    "title": "potatomanseeksthetroof",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpotatomanseeksthetroof.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1839-clpou-1-",
    "title": "pou(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpou(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1840-clpou",
    "title": "Pou",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPou.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1841-clpowerslave",
    "title": "powerslave",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpowerslave.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1842-clpraxisfighterx",
    "title": "praxisfighterx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpraxisfighterx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1843-clprebronzeage",
    "title": "prebronzeage",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprebronzeage.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1844-clprecivilationbronzeage",
    "title": "precivilationbronzeage",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprecivilationbronzeage.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1845-clprehistoricshark",
    "title": "prehistoricshark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprehistoricshark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1846-clprimary",
    "title": "primary",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprimary.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1847-clprismarine",
    "title": "prismarine",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprismarine.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1848-clprocessortycoon",
    "title": "processortycoon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprocessortycoon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1849-clprofessorlaytonandthecuriousvillage",
    "title": "professorlaytonandthecuriousvillage",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprofessorlaytonandthecuriousvillage.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1850-clpuckman",
    "title": "puckman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpuckman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1851-clpullfrog",
    "title": "pullfrog",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpullfrog.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1852-clpumpkinrun",
    "title": "pumpkinrun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpumpkinrun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1853-clpunchout",
    "title": "punchout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpunchout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1854-clpunchthedrump",
    "title": "punchthedrump",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpunchthedrump.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1855-clpunchthetrump",
    "title": "punchthetrump",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpunchthetrump.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1856-clpuppethockey",
    "title": "puppethockey",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpuppethockey.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1857-clpuppetmaster",
    "title": "puppetmaster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpuppetmaster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1858-clpushyourluck",
    "title": "pushyourluck",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpushyourluck.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1859-clpuyopuyofever",
    "title": "puyopuyofever",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpuyopuyofever.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1860-clpvz",
    "title": "pvz",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpvz.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1861-clpvz2",
    "title": "pvz 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpvz2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1862-clpvz2gardenless",
    "title": "pvz 2 gardenless",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpvz2gardenless.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1863-clpvzm",
    "title": "PVZM",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPVZM.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1864-clpyrotoad",
    "title": "pyrotoad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpyrotoad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1865-clqbert",
    "title": "qbert",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clqbert.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1866-clqbertarcade",
    "title": "qbertarcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clqbertarcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1867-clqtrewired",
    "title": "qtrewired",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clqtrewired.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1868-clquake2",
    "title": "quake 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clquake2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1869-clquake3",
    "title": "quake 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clquake3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1870-clquake64",
    "title": "quake 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clquake64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1871-clquantumclicker",
    "title": "Quantum Clicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clQuantumClicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1872-clquickieworld",
    "title": "quickieworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clquickieworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1873-clqwop",
    "title": "qwop",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clqwop.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1874-clracemaster3d",
    "title": "racemaster 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clracemaster3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1875-clracingarena",
    "title": "racingarena",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clracingarena.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1876-clradicalred",
    "title": "radicalred",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clradicalred.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1877-clradracer",
    "title": "radracer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clradracer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1878-clraftwars",
    "title": "raftwars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clraftwars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1879-clraftwars2",
    "title": "raftwars 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clraftwars2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1880-clragdoll-io",
    "title": "ragdoll-io",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clragdoll-io.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1881-clragdollachivement",
    "title": "ragdollachivement",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clragdollachivement.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1882-clragdollarchers",
    "title": "ragdollarchers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clragdollarchers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1883-clragdolldrop",
    "title": "ragdolldrop",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clragdolldrop.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1884-clragdollhit",
    "title": "ragdollhit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clragdollhit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1885-clragdollrunners",
    "title": "ragdollrunners",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clragdollrunners.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1886-clragdollsoccer",
    "title": "ragdollsoccer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clragdollsoccer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1887-clragollhit",
    "title": "ragollhit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clragollhit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1888-clrainbowsix",
    "title": "rainbowsix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrainbowsix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1889-clrainbowsixalt",
    "title": "rainbowsixalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrainbowsixalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1890-clraldiscrackhouse",
    "title": "raldiscrackhouse",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clraldiscrackhouse.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1891-clravenbase",
    "title": "ravenbase",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clravenbase.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1892-clray1",
    "title": "ray 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clray1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1893-clray2",
    "title": "ray 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clray2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1894-clrayman",
    "title": "rayman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrayman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1895-clraze",
    "title": "raze",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clraze.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1896-clraze2",
    "title": "raze 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clraze2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1897-clraze3",
    "title": "raze 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clraze3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1898-clre3",
    "title": "re 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clre3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1899-clreachthecore",
    "title": "reachthecore",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clreachthecore.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1900-clrealflightsim",
    "title": "realflightsim",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrealflightsim.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1901-clrebuild",
    "title": "rebuild",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrebuild.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1902-clrebuild2",
    "title": "rebuild 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrebuild2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1903-clrecoil",
    "title": "recoil",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrecoil.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1904-clredalert",
    "title": "redalert",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredalert.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1905-clredball",
    "title": "redball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1906-clredball2",
    "title": "redball 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredball2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1907-clredball3",
    "title": "redball 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredball3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1908-clredball4-1-",
    "title": "redball 4(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredball4(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1909-clredball4",
    "title": "Red Ball 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clRedBall4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1910-clredball4vol2",
    "title": "redball 4 vol 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredball4vol2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1911-clredball4vol3",
    "title": "redball 4 vol 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredball4vol3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1912-clredhanded",
    "title": "redhanded",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredhanded.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1913-clredtierunner",
    "title": "redtierunner",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredtierunner.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1914-clredvbluefix",
    "title": "redvbluefix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredvbluefix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1915-clredvsblue2",
    "title": "redvsblue 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredvsblue2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1916-clredvsbluewar",
    "title": "redvsbluewar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clredvsbluewar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1917-clreignofcentipede",
    "title": "reignofcentipede",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clreignofcentipede.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1918-clrenegades",
    "title": "renegades",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrenegades.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1919-clrepobad",
    "title": "repobad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrepobad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1920-clresidentevil",
    "title": "residentevil",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clresidentevil.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1921-clresidentevil2",
    "title": "residentevil 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clresidentevil2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1922-clresidentevil2d1",
    "title": "residentevil 2 d 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clresidentevil2d1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1923-clresidentevil2d2",
    "title": "residentevil 2 d 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clresidentevil2d2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1924-clresizer",
    "title": "resizer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clresizer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1925-clresortempire",
    "title": "resortempire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clresortempire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1926-clretrobowl",
    "title": "retrobowl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clretrobowl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1927-clretrobowlcollege",
    "title": "retrobowlcollege",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clretrobowlcollege.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1928-clretrohighway",
    "title": "retrohighway",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clretrohighway.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1929-clretropingpong",
    "title": "retropingpong",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clretropingpong.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1930-clreturnman",
    "title": "returnman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clreturnman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1931-clreturnman2",
    "title": "returnman 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clreturnman2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1932-clreturntoriddleschool",
    "title": "returntoriddleschool",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clreturntoriddleschool.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1933-clrevolutionidle",
    "title": "revolutionidle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrevolutionidle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1934-clrewrite2",
    "title": "rewrite 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrewrite2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1935-clrh",
    "title": "rh",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrh.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1936-clrhythmheaven",
    "title": "rhythmheaven",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrhythmheaven.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1937-clrhythymymheaven",
    "title": "rhythymymheaven",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrhythymymheaven.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1938-clricochetkills2",
    "title": "ricochetkills 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clricochetkills2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1939-clriddle",
    "title": "riddle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clriddle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1940-clriddlemiddleschool",
    "title": "riddlemiddleschool",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clriddlemiddleschool.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1941-clriddleschool",
    "title": "riddleschool",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clriddleschool.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1942-clriddleschool2",
    "title": "riddleschool 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clriddleschool2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1943-clriddleschool3",
    "title": "riddleschool 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clriddleschool3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1944-clriddleschool445544444--444-444",
    "title": "riddleschool 445544444$$444$444",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clriddleschool445544444%24%24444%24444.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1945-clriddletransfer",
    "title": "riddletransfer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clriddletransfer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1946-clriddletransfer2",
    "title": "riddletransfer 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clriddletransfer2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1947-clriddleuneversityfix",
    "title": "riddleuneversityfix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clriddleuneversityfix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1948-clridgeracer",
    "title": "ridgeracer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clridgeracer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1949-clrisehigher",
    "title": "risehigher",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrisehigher.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1950-clristar",
    "title": "ristar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clristar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1951-clroadfighter",
    "title": "roadfighter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroadfighter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1952-clroadoffury",
    "title": "roadoffury",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroadoffury.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1953-clroadofthedead",
    "title": "roadofthedead",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroadofthedead.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1954-clroadofthedead2",
    "title": "roadofthedead 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroadofthedead2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1955-clroadrunnernes",
    "title": "roadrunnernes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroadrunnernes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1956-clrocketgoalio",
    "title": "rocketgoalio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketgoalio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1957-clrocketjump",
    "title": "rocketjump",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketjump.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1958-clrocketknight2--1-",
    "title": "rocketknight 2 (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketknight2%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1959-clrocketknight2-1-",
    "title": "rocketknight 2(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketknight2(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1960-clrocketknight2-2-",
    "title": "rocketknight 2(2)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketknight2(2).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1961-clrocketknight2",
    "title": "rocketknight 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketknight2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1962-clrocketknightadventures",
    "title": "rocketknightadventures",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketknightadventures.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1963-clrocketleague",
    "title": "rocketleague",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketleague.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1964-clrocketpult",
    "title": "rocketpult",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketpult.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1965-clrocketsoccerderby",
    "title": "rocketsoccerderby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrocketsoccerderby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1966-clrodha",
    "title": "rodha",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrodha.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1967-clroguesoul",
    "title": "roguesoul",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroguesoul.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1968-clroguesoul2",
    "title": "roguesoul 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroguesoul2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1969-clrollerballer",
    "title": "rollerballer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrollerballer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1970-clrollingsky",
    "title": "rollingsky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrollingsky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1971-clrollyvortex",
    "title": "rollyvortex",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrollyvortex.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1972-clrolypolymonster",
    "title": "rolypolymonster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrolypolymonster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1973-clrooftoprun",
    "title": "rooftoprun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrooftoprun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1974-clrooftopsnipers",
    "title": "rooftopsnipers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrooftopsnipers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1975-clrooftopsnipers2",
    "title": "rooftopsnipers 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrooftopsnipers2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1976-clroomclicker",
    "title": "roomclicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroomclicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1977-clrosegold",
    "title": "rosegold",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrosegold.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1978-clrotate",
    "title": "rotate",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrotate.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1979-clroulettehero",
    "title": "roulettehero",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroulettehero.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1980-clrouletteknight",
    "title": "rouletteknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrouletteknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1981-clruffle",
    "title": "ruffle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clruffle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1982-clrun-2",
    "title": "run-2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrun-2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1983-clrun",
    "title": "run",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1984-clrun2",
    "title": "run 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrun2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1985-clrun3",
    "title": "run 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrun3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1986-clrunningfred",
    "title": "runningfred",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrunningfred.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1987-clrussianbuckshot",
    "title": "russianbuckshot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrussianbuckshot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1988-clrussiancardriver",
    "title": "russiancardriver",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrussiancardriver.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1989-clrussiansandbox",
    "title": "russiansandbox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrussiansandbox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1990-clsaihatestation",
    "title": "saihatestation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsaihatestation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1991-clsandboxcity",
    "title": "sandboxcity",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsandboxcity.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1992-clsandboxels",
    "title": "sandboxels",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsandboxels.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1993-clsandsofthecoliseum",
    "title": "sandsofthecoliseum",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsandsofthecoliseum.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1994-clsandstone-1-",
    "title": "sandstone(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsandstone(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1995-clsandstone",
    "title": "sandstone",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsandstone.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1996-clsandtris",
    "title": "sandtris",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsandtris.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1997-clsantarun",
    "title": "santarun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsantarun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1998-clsanty",
    "title": "santy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsanty.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-1999-clsaszombieassault2",
    "title": "saszombieassault 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsaszombieassault2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2000-clsatryn",
    "title": "satryn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsatryn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2001-clsaulgoodmanrun",
    "title": "saulgoodmanrun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsaulgoodmanrun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2002-clsausageflip",
    "title": "sausageflip",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsausageflip.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2003-clsayorisnotebook",
    "title": "sayorisnotebook",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsayorisnotebook.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2004-clscalethedepths",
    "title": "scalethedepths",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscalethedepths.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2005-clscamptonthegreatfightrecreate",
    "title": "Scampton The Great Fight Recreate",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clScamptonTheGreatFightRecreate.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2006-clscarletandviolet",
    "title": "scarletandviolet",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscarletandviolet.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2007-clscarletshift",
    "title": "scarletshift",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscarletshift.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2008-clscarymazegame",
    "title": "scarymazegame",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscarymazegame.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2009-clscaryshawarma",
    "title": "scaryshawarma",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscaryshawarma.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2010-clscaryteacher3d",
    "title": "scaryteacher 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscaryteacher3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2011-clschoolboyrunaway",
    "title": "schoolboyrunaway",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clschoolboyrunaway.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2012-clscrapmetal3",
    "title": "scrapmetal 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscrapmetal3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2013-clscrapyarddog",
    "title": "scrapyarddog",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscrapyarddog.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2014-clscratchoptions",
    "title": "scratchoptions",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscratchoptions.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2015-clscribblenauts",
    "title": "scribblenauts",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscribblenauts.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2016-clscubabear",
    "title": "scubabear",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscubabear.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2017-clsd-thewar",
    "title": "sd-thewar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsd-thewar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2018-clsdf",
    "title": "sdf",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsdf.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2019-clseamongrel",
    "title": "seamongrel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clseamongrel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2020-clsecretofmana",
    "title": "secretofmana",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsecretofmana.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2021-clsega2gg",
    "title": "sega 2 gg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsega2gg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2022-clsegasonicthehedgehog",
    "title": "Sega Sonic The Hedgehog",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSegaSonicTheHedgehog.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2023-clself",
    "title": "self",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clself.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2024-clsentryfortress",
    "title": "sentryfortress",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsentryfortress.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2025-clserenitrove",
    "title": "serenitrove",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clserenitrove.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2026-clserioussamadvance",
    "title": "serioussamadvance",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clserioussamadvance.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2027-clservingupmadness",
    "title": "servingupmadness",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clservingupmadness.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2028-clsevendays",
    "title": "sevendays",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsevendays.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2029-clsfk",
    "title": "sfk",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsfk.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2030-clsfk2",
    "title": "sfk 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsfk2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2031-clsfklaststand",
    "title": "sfklaststand",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsfklaststand.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2032-clsfkleague",
    "title": "sfkleague",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsfkleague.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2033-clshadowcourier",
    "title": "shadowcourier",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshadowcourier.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2034-clshadowdancer",
    "title": "shadowdancer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshadowdancer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2035-clshadowdancersecret",
    "title": "shadowdancersecret",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshadowdancersecret.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2036-clshaggy--1-",
    "title": "shaggy (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshaggy%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2037-clshaggy",
    "title": "shaggy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshaggy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2038-clshantaegb",
    "title": "shantaegb",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshantaegb.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2039-clshapetransform",
    "title": "shapetransform",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshapetransform.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2040-clshc1",
    "title": "shc 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshc1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2041-clshc2",
    "title": "shc 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshc2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2042-clshc3",
    "title": "shc 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshc3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2043-clshift",
    "title": "shift",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshift.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2044-clshift2",
    "title": "shift 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshift2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2045-clshift3",
    "title": "shift 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshift3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2046-clshiftatmidnight",
    "title": "shiftatmidnight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshiftatmidnight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2047-clshinmegamitenseidevilsurvivor",
    "title": "shinmegamitenseidevilsurvivor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshinmegamitenseidevilsurvivor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2048-clshinobi",
    "title": "shinobi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshinobi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2049-clshinobi3",
    "title": "shinobi 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshinobi3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2050-clshinobirevenge",
    "title": "shinobirevenge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshinobirevenge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2051-clshoppingcarthero",
    "title": "shoppingcarthero",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshoppingcarthero.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2052-clshortlife",
    "title": "shortlife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshortlife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2053-clshotout4",
    "title": "shotout 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshotout4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2054-clshredmill",
    "title": "shredmill",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshredmill.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2055-clshredsauce",
    "title": "shredsauce",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshredsauce.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2056-clshrek-2",
    "title": "shrek-2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshrek-2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2057-clshrubnaut",
    "title": "shrubnaut",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshrubnaut.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2058-clshwultimatem",
    "title": "shwultimatem",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clshwultimatem.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2059-clsideeffects",
    "title": "sideeffects",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsideeffects.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2060-clsidepocket",
    "title": "sidepocket",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsidepocket.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2061-clsierra7",
    "title": "sierra 7",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsierra7.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2062-clsilenthill",
    "title": "silenthill",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsilenthill.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2063-clsilenthillalt",
    "title": "silenthillalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsilenthillalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2064-clsilk",
    "title": "silk",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsilk.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2065-clsilkmelody",
    "title": "silkmelody",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsilkmelody.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2066-clsiloshowdow",
    "title": "siloshowdow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsiloshowdow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2067-clsilver",
    "title": "silver",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsilver.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2068-clsimcity64",
    "title": "simcity 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsimcity64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2069-clsimpsonsarcade",
    "title": "simpsonsarcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsimpsonsarcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2070-clsinglefile",
    "title": "SINGLEFILE",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSINGLEFILE.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2071-clsixwaystodie",
    "title": "sixwaystodie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsixwaystodie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2072-clskateit",
    "title": "skateit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskateit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2073-clskateordie",
    "title": "skateordie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskateordie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2074-clskibididibidygyattohiorizzingallovertheplacestillwatermangotheoryfemboydrool",
    "title": "skibididibidygyattohiorizzingallovertheplacestillwatermangotheoryfemboydrool",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskibididibidygyattohiorizzingallovertheplacestillwatermangotheoryfemboydrool.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2075-clskibidiinthebackrooms",
    "title": "skibidiinthebackrooms",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskibidiinthebackrooms.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2076-clskibidishooter",
    "title": "skibidishooter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskibidishooter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2077-clskinwalker",
    "title": "skinwalker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskinwalker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2078-clskong",
    "title": "skong",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskong.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2079-clskyrace-3d",
    "title": "skyrace-3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskyrace-3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2080-clskyriders",
    "title": "Sky Riders",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSkyRiders.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2081-clskywire",
    "title": "skywire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskywire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2082-clskywire2",
    "title": "skywire 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskywire2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2083-clslenderman",
    "title": "slenderman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslenderman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2084-clslendytubbies",
    "title": "slendytubbies",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslendytubbies.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2085-clsliceitall",
    "title": "sliceitall",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsliceitall.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2086-clslideinthewoods",
    "title": "slideinthewoods",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslideinthewoods.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2087-clslimelabratory",
    "title": "slimelabratory",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslimelabratory.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2088-clslipways",
    "title": "slipways",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslipways.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2089-clslitherio",
    "title": "slitherio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslitherio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2090-clslope",
    "title": "slope",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslope.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2091-clslope2player",
    "title": "slope 2 player",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslope2player.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2092-clslope3",
    "title": "slope 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslope3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2093-clslopeplus",
    "title": "slopeplus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslopeplus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2094-clslotornot",
    "title": "slotornot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslotornot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2095-clslowroads",
    "title": "slowroads",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslowroads.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2096-clsm63redux",
    "title": "sm 63 redux",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm63redux.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2097-clsm64greenstars",
    "title": "sm 64 greenstars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64greenstars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2098-clsm64hiddenstars",
    "title": "sm 64 hiddenstars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64hiddenstars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2099-clsm64land",
    "title": "SM64 Land",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSM64Land.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2100-clsm64lastimpact",
    "title": "sm 64 lastimpact",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64lastimpact.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2101-clsm64liminaldream",
    "title": "sm 64 liminaldream",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64liminaldream.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2102-clsm64oot",
    "title": "sm 64 oot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64oot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2103-clsm64sapphire",
    "title": "sm 64 sapphire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64sapphire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2104-clsmadvance2",
    "title": "smadvance 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmadvance2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2105-clsmadvance3",
    "title": "smadvance 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmadvance3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2106-clsmash-hit-ripoff",
    "title": "Smash Hit Ripoff",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSmash%20Hit%20Ripoff.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2107-clsmashkarts",
    "title": "smashkarts",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmashkarts.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2108-clsmashkartsworking",
    "title": "smashkartsworking",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmashkartsworking.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2109-clsmashremix",
    "title": "smashremix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmashremix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2110-clsmashremix201",
    "title": "smashremix 201",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmashremix201.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2111-clsmb12",
    "title": "smb 12",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmb12.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2112-clsmbc",
    "title": "smbc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmbc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2113-clsmbcrossover",
    "title": "smbcrossover",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmbcrossover.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2114-clsmbgameover",
    "title": "smbgameover",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmbgameover.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2115-clsmbremastered",
    "title": "smbremastered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmbremastered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2116-clsmc",
    "title": "smc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2117-clsmgds",
    "title": "smgds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmgds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2118-clsnailbob",
    "title": "snailbob",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnailbob.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2119-clsnailbob2",
    "title": "snailbob 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnailbob2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2120-clsnailbob3",
    "title": "snailbob 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnailbob3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2121-clsnailbob4space",
    "title": "snailbob 4 space",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnailbob4space.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2122-clsnailbob5lovestory",
    "title": "snailbob 5 lovestory",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnailbob5lovestory.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2123-clsnakeis",
    "title": "snakeis",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnakeis.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2124-clsnakelike",
    "title": "snakelike",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnakelike.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2125-clsnipershot",
    "title": "snipershot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnipershot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2126-clsniperv2",
    "title": "sniperv 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsniperv2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2127-clsnowballio",
    "title": "snowballio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowballio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2128-clsnowboardobby",
    "title": "snowboardobby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowboardobby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2129-clsnowbros--1-",
    "title": "snowbros (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowbros%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2130-clsnowbros-1-",
    "title": "snowbros(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowbros(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2131-clsnowbros-2-",
    "title": "snowbros(2)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowbros(2).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2132-clsnowbros",
    "title": "snowbros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowbros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2133-clsnowbrosgenesis",
    "title": "Snow Bros Genesis",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSnowBrosGenesis.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2134-clsnowbrothers",
    "title": "snowbrothers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowbrothers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2135-clsnowdrift",
    "title": "snowdrift",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowdrift.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2136-clsnowrid",
    "title": "snowrid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowrid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2137-clsnowrideee",
    "title": "snowrideee",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowrideee.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2138-clsnowrider",
    "title": "snowrider",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowrider.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2139-clsnowridergoodygumdrops",
    "title": "snowridergoodygumdrops",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowridergoodygumdrops.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2140-clsnowriderrrr",
    "title": "snowriderrrr",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowriderrrr.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2141-clsnowroad",
    "title": "snowroad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowroad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2142-clsnowwhite",
    "title": "snowwhite",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsnowwhite.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2143-clsoccerbros",
    "title": "soccerbros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoccerbros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2144-clsoccerrandom",
    "title": "soccerrandom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoccerrandom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2145-clsoccerrandomgood",
    "title": "soccerrandomgood",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoccerrandomgood.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2146-clsodasimulator",
    "title": "sodasimulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsodasimulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2147-clsolarsandbox",
    "title": "solarsandbox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsolarsandbox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2148-clsolarsmash",
    "title": "solarsmash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsolarsmash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2149-clsolatrobo",
    "title": "solatrobo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsolatrobo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2150-clsolitaire",
    "title": "solitaire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsolitaire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2151-clsolstice",
    "title": "solstice",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsolstice.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2152-clsomari64",
    "title": "somari 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsomari64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2153-clsonic---knuckles---sonic-the-hedgehog-3",
    "title": "Sonic & Knuckles + Sonic The Hedgehog 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSonic%20%26%20Knuckles%20%2B%20Sonic%20The%20Hedgehog%203.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2154-clsonic1contemporary",
    "title": "sonic 1 contemporary",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic1contemporary.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2155-clsonic1mobile",
    "title": "sonic 1 mobile",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic1mobile.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2156-clsonic1scorerush",
    "title": "Sonic 1 Score Rush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSonic1ScoreRush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2157-clsonic1thesuperchallenges",
    "title": "Sonic 1 The Super Challenges",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSonic1TheSuperChallenges.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2158-clsonic2mobile",
    "title": "sonic 2 mobile",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic2mobile.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2159-clsonic2pinkedition",
    "title": "sonic 2 pinkedition",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic2pinkedition.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2160-clsonic2scorerush",
    "title": "Sonic 2 Score Rush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSonic2ScoreRush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2161-clsonic2timeandplace",
    "title": "sonic 2 timeandplace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic2timeandplace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2162-clsonic3andknuckles",
    "title": "sonic 3 andknuckles",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic3andknuckles.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2163-clsonic3andsally",
    "title": "sonic 3 andsally",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic3andsally.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2164-clsonic3complete",
    "title": "sonic 3 complete",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic3complete.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2165-clsonic3dblast",
    "title": "sonic 3 dblast",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic3dblast.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2166-clsonic3dblastdx",
    "title": "sonic 3 dblastdx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic3dblastdx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2167-clsonicadvance",
    "title": "sonicadvance",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicadvance.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2168-clsonicadvance2",
    "title": "sonicadvance 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicadvance2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2169-clsonicadvance2sp",
    "title": "sonicadvance 2 sp",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicadvance2sp.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2170-clsonicadvance3",
    "title": "sonicadvance 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicadvance3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2171-clsonicandashuro",
    "title": "sonicandashuro",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicandashuro.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2172-clsonicandfallingstar",
    "title": "sonicandfallingstar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicandfallingstar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2173-clsonicandknuckles",
    "title": "sonicandknuckles",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicandknuckles.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2174-clsonicbattle",
    "title": "sonicbattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicbattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2175-clsonicblast",
    "title": "sonicblast",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicblast.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2176-clsoniccd",
    "title": "soniccd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoniccd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2177-clsoniccdmobile",
    "title": "soniccdmobile",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoniccdmobile.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2178-clsonicchaos",
    "title": "sonicchaos",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicchaos.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2179-clsonicclassiccollection",
    "title": "sonicclassiccollection",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicclassiccollection.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2180-clsonicclassicheroes-1-",
    "title": "sonicclassicheroes(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicclassicheroes(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2181-clsonicclassicheroes",
    "title": "sonicclassicheroes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicclassicheroes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2182-clsonicclassics",
    "title": "Sonic Classics",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSonicClassics.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2183-clsoniccolors",
    "title": "soniccolors",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoniccolors.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2184-clsonicdeltaorigins",
    "title": "sonicdeltaorigins",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicdeltaorigins.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2185-clsoniceexeog",
    "title": "soniceexeog",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoniceexeog.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2186-clsonicerazor",
    "title": "sonicerazor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicerazor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2187-clsonicgg",
    "title": "sonicgg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicgg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2188-clsonichellfiresaga",
    "title": "Sonic Hellfire Saga",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSonicHellfireSaga.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2189-clsonicinsm64",
    "title": "Sonic In SM64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSonicInSM64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2190-clsonicinsmw-1-",
    "title": "Sonicin SMW(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSonicinSMW(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2191-clsonicinsmw-2-",
    "title": "sonicinsmw(2)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicinsmw(2).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2192-clsonicinsmw",
    "title": "Sonicin SMW",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSonicinSMW.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2193-clsonicjam",
    "title": "sonicjam",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicjam.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2194-clsoniclabyrinth",
    "title": "soniclabyrinth",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoniclabyrinth.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2195-clsonicmania",
    "title": "sonicmania",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicmania.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2196-clsonicmaniaplus",
    "title": "sonicmaniaplus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicmaniaplus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2197-clsonicmegamix",
    "title": "sonicmegamix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicmegamix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2198-clsonicmon",
    "title": "sonicmon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicmon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2199-clsonicpocketadventure",
    "title": "sonicpocketadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicpocketadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2200-clsonicr",
    "title": "sonicr",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicr.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2201-clsonicralt",
    "title": "sonicralt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicralt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2202-clsonicrevert",
    "title": "sonicrevert",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicrevert.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2203-clsonicrush",
    "title": "sonicrush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicrush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2204-clsonicrushadventure",
    "title": "sonicrushadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicrushadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2205-clsonicscorchedquest",
    "title": "sonicscorchedquest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicscorchedquest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2206-clsonicspinball",
    "title": "sonicspinball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicspinball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2207-clsonicthehedgehog",
    "title": "sonicthehedgehog",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicthehedgehog.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2208-clsonicthehedgehog2",
    "title": "sonicthehedgehog 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicthehedgehog2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2209-clsonicthehedgehog3",
    "title": "sonicthehedgehog 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicthehedgehog3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2210-clsonny2",
    "title": "sonny 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonny2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2211-clsortthecourt",
    "title": "sortthecourt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsortthecourt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2212-clsotn",
    "title": "sotn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsotn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2213-clsouljumper",
    "title": "souljumper",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsouljumper.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2214-clsoundboard",
    "title": "soundboard",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoundboard.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2215-clsouthparkn64",
    "title": "southparkn 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsouthparkn64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2216-clsovereignoftheskys",
    "title": "Sovereignoftheskys",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSovereignoftheskys.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2217-clspacebarclicker",
    "title": "spacebarclicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspacebarclicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2218-clspacecompany",
    "title": "spacecompany",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspacecompany.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2219-clspaceharriersms",
    "title": "spaceharriersms",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspaceharriersms.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2220-clspaceinvade95",
    "title": "spaceinvade 95",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspaceinvade95.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2221-clspaceinvaders",
    "title": "spaceinvaders",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspaceinvaders.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2222-clspaceiskey",
    "title": "spaceiskey",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspaceiskey.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2223-clspaceiskey2",
    "title": "spaceiskey 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspaceiskey2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2224-clspaceiskeyxmas",
    "title": "spaceiskeyxmas",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspaceiskeyxmas.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2225-clspacewarsbattleground",
    "title": "spacewarsbattleground",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspacewarsbattleground.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2226-clspacewaves",
    "title": "spacewaves",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspacewaves.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2227-clspecialmission",
    "title": "specialmission",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspecialmission.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2228-clspeedperclick",
    "title": "speedperclick",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspeedperclick.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2229-clspeedstars",
    "title": "speedstars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspeedstars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2230-clspelunky",
    "title": "spelunky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspelunky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2231-clspewer",
    "title": "spewer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspewer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2232-clspidermanps1",
    "title": "spidermanps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspidermanps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2233-clspiralroll",
    "title": "spiralroll",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspiralroll.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2234-clspiritsofhell",
    "title": "spiritsofhell",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspiritsofhell.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2235-clspongebobpowerkartgrandprix",
    "title": "Spongebob Power Kart Grand Prix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSpongebobPowerKartGrandPrix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2236-clsportsheadsicehockey",
    "title": "Sports Heads Ice Hockey",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSportsHeadsIceHockey.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2237-clsprinter",
    "title": "sprinter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsprinter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2238-clsprunked",
    "title": "sprunked",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsprunked.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2239-clsprunki",
    "title": "sprunki",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsprunki.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2240-clsprunkiclicker",
    "title": "sprunkiclicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsprunkiclicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2241-clspyhunter",
    "title": "spyhunter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspyhunter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2242-clsquidplayground",
    "title": "squidplayground",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsquidplayground.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2243-clssf2arcade",
    "title": "SSF2 Arcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSSF2Arcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2244-clssf2tarcade",
    "title": "SSF2 TArcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSSF2TArcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2245-clstackballio",
    "title": "stackballio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstackballio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2246-clstacktris",
    "title": "stacktris",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstacktris.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2247-clstackydash",
    "title": "stackydash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstackydash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2248-clstarfox",
    "title": "starfox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstarfox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2249-clstarfox64",
    "title": "starfox 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstarfox64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2250-clstarraiders",
    "title": "starraiders",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstarraiders.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2251-clstateio",
    "title": "stateio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstateio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2252-clstation141",
    "title": "station 141",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstation141.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2253-clstationmeltdown",
    "title": "stationmeltdown",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstationmeltdown.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2254-clstationsaturn",
    "title": "stationsaturn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstationsaturn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2255-clsteakandjake",
    "title": "steakandjake",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsteakandjake.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2256-clstealbrainrot",
    "title": "stealbrainrot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstealbrainrot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2257-clstealbrainrotonline",
    "title": "stealbrainrotonline",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstealbrainrotonline.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2258-clstealthassassin",
    "title": "stealthassassin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstealthassassin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2259-clstealthmaster",
    "title": "stealthmaster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstealthmaster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2260-clsteelempire",
    "title": "steelempire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsteelempire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2261-clsteelsurge",
    "title": "steelsurge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsteelsurge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2262-clsteepdescent",
    "title": "steepdescent",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsteepdescent.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2263-clstickarchersbattle",
    "title": "stickarchersbattle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickarchersbattle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2264-clstickdefenders",
    "title": "stickdefenders",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickdefenders.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2265-clstickfighter",
    "title": "stickfighter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickfighter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2266-clstickjetchallenge",
    "title": "stickjetchallenge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickjetchallenge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2267-clstickmanandguns",
    "title": "stickmanandguns",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickmanandguns.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2268-clstickmanclash",
    "title": "stickmanclash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickmanclash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2269-clstickmanduel",
    "title": "stickmanduel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickmanduel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2270-clstickmangtacity",
    "title": "stickmangtacity",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickmangtacity.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2271-clstickmanhook",
    "title": "stickmanhook",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickmanhook.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2272-clstickmankingdomclash",
    "title": "Stickman Kingdomclash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clStickmanKingdomclash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2273-clstickmankombat2d",
    "title": "stickmankombat 2 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickmankombat2d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2274-clstickmanstealingdiamond",
    "title": "stickmanstealingdiamond",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickmanstealingdiamond.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2275-clstickmerge",
    "title": "stickmerge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickmerge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2276-clstickminairship",
    "title": "stickminairship",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickminairship.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2277-clstickminbreakingbank",
    "title": "stickminbreakingbank",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickminbreakingbank.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2278-clstickminescapingprison",
    "title": "stickminescapingprison",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickminescapingprison.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2279-clstickminfleecomplex",
    "title": "stickminfleecomplex",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickminfleecomplex.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2280-clstickrpgcomplete",
    "title": "stickrpgcomplete",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickrpgcomplete.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2281-clstickslasher",
    "title": "stickslasher",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickslasher.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2282-clstickwar",
    "title": "stickwar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickwar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2283-clstickwar2",
    "title": "stickwar 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickwar2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2284-clstickwithit",
    "title": "stickwithit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstickwithit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2285-clstormthehouse",
    "title": "stormthehouse",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstormthehouse.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2286-clstormthehouse2",
    "title": "stormthehouse 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstormthehouse2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2287-clstormthehouse3",
    "title": "stormthehouse 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstormthehouse3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2288-clstrangejournet",
    "title": "strangejournet",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstrangejournet.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2289-clstreangeropepolice",
    "title": "streangeropepolice",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstreangeropepolice.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2290-clstreetfighter1arcade",
    "title": "Street Fighter 1 Arcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clStreetFighter1Arcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2291-clstreetfighter2",
    "title": "streetfighter 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstreetfighter2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2292-clstreetfighter2arcade",
    "title": "Street Fighter 2 Arcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clStreetFighter2Arcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2293-clstreetfighter2cearcade",
    "title": "Street Fighter 2 CEArcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clStreetFighter2CEArcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2294-clstreetfighter2hfarcade-1-",
    "title": "Street Fighter 2 HFArcade(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clStreetFighter2HFArcade(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2295-clstreetfighter2hfarcade",
    "title": "Street Fighter 2 HFArcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clStreetFighter2HFArcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2296-clstreetfighter2turbo",
    "title": "streetfighter 2 turbo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstreetfighter2turbo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2297-clstreetfighteralpha3",
    "title": "streetfighteralpha 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstreetfighteralpha3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2298-clstreetfighterumuhsomething",
    "title": "streetfighterumuhsomething",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstreetfighterumuhsomething.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2299-clstreetofrage",
    "title": "streetofrage",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstreetofrage.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2300-clstreetofrage2",
    "title": "streetofrage 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstreetofrage2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2301-clstreetofrage3",
    "title": "streetofrage 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstreetofrage3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2302-clstrikeforceheroes",
    "title": "strikeforceheroes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstrikeforceheroes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2303-clstrikeforceheroes2",
    "title": "strikeforceheroes 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstrikeforceheroes2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2304-clstrikeforceheroes3",
    "title": "strikeforceheroes 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstrikeforceheroes3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2305-clstrikerdummies",
    "title": "strikerdummies",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstrikerdummies.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2306-clstylesavvy",
    "title": "stylesavvy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstylesavvy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2307-clsubwaysurfersbarcelona",
    "title": "subwaysurfersbarcelona",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersbarcelona.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2308-clsubwaysurfersbeijing",
    "title": "subwaysurfersbeijing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersbeijing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2309-clsubwaysurfersberlin",
    "title": "subwaysurfersberlin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersberlin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2310-clsubwaysurfersbuenosaires",
    "title": "subwaysurfersbuenosaires",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersbuenosaires.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2311-clsubwaysurfershavana",
    "title": "subwaysurfershavana",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfershavana.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2312-clsubwaysurfershouston",
    "title": "subwaysurfershouston",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfershouston.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2313-clsubwaysurfersiceland",
    "title": "subwaysurfersiceland",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersiceland.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2314-clsubwaysurferslondon",
    "title": "subwaysurferslondon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurferslondon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2315-clsubwaysurfersmexico",
    "title": "subwaysurfersmexico",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersmexico.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2316-clsubwaysurfersmiami",
    "title": "subwaysurfersmiami",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersmiami.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2317-clsubwaysurfersmonaco",
    "title": "subwaysurfersmonaco",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersmonaco.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2318-clsubwaysurfersneworeleans",
    "title": "subwaysurfersneworeleans",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersneworeleans.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2319-clsubwaysurfersneworleans",
    "title": "subwaysurfersneworleans",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersneworleans.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2320-clsubwaysurferssanfrancisco--1-",
    "title": "subwaysurferssanfrancisco (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurferssanfrancisco%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2321-clsubwaysurferssanfrancisco-1-",
    "title": "subwaysurferssanfrancisco(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurferssanfrancisco(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2322-clsubwaysurferssanfrancisco",
    "title": "subwaysurferssanfrancisco",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurferssanfrancisco.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2323-clsubwaysurfersstpetersburg",
    "title": "subwaysurfersstpetersburg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurfersstpetersburg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2324-clsubwaysurferswinterholiday",
    "title": "subwaysurferswinterholiday",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurferswinterholiday.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2325-clsubwaysurferszurich",
    "title": "subwaysurferszurich",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsubwaysurferszurich.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2326-clsugarsugar",
    "title": "sugarsugar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsugarsugar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2327-clsuika",
    "title": "suika",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuika.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2328-clsuikapico",
    "title": "suikapico",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuikapico.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2329-clsummerrider",
    "title": "summerrider",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsummerrider.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2330-clsunandmoon",
    "title": "sunandmoon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsunandmoon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2331-clsuperbomberman",
    "title": "superbomberman",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperbomberman.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2332-clsuperbomberman2",
    "title": "superbomberman 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperbomberman2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2333-clsuperbomberman3",
    "title": "superbomberman 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperbomberman3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2334-clsuperbomberman4",
    "title": "superbomberman 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperbomberman4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2335-clsuperbomberman5",
    "title": "superbomberman 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperbomberman5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2336-clsuperc",
    "title": "superc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2337-clsupercarrush",
    "title": "supercarrush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupercarrush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2338-clsupercastlevaniavi",
    "title": "supercastlevania VI",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupercastlevaniaVI.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2339-clsuperchibiknight",
    "title": "superchibiknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperchibiknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2340-clsupercold",
    "title": "supercold",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupercold.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2341-clsuperdarkdeception",
    "title": "superdarkdeception",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperdarkdeception.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2342-clsuperdiagonalmario2",
    "title": "superdiagonalmario 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperdiagonalmario2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2343-clsuperdromebugs-1-",
    "title": "superdromebugs(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperdromebugs(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2344-clsuperdromebugs",
    "title": "superdromebugs",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperdromebugs.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2345-clsuperfallingfred",
    "title": "superfallingfred",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperfallingfred.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2346-clsuperfighters",
    "title": "superfighters",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperfighters.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2347-clsuperhot",
    "title": "superhot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperhot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2348-clsuperhotlinemiami",
    "title": "superhotlinemiami",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperhotlinemiami.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2349-clsuperhouseofdeadninjas",
    "title": "superhouseofdeadninjas",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperhouseofdeadninjas.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2350-clsuperislandadventure",
    "title": "superislandadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperislandadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2351-clsuperliquidsoccer",
    "title": "superliquidsoccer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperliquidsoccer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2352-clsupermario",
    "title": "supermario",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermario.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2353-clsupermario3mix",
    "title": "supermario 3 mix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermario3mix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2354-clsupermario63",
    "title": "supermario 63",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermario63.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2355-clsupermario64",
    "title": "supermario 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermario64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2356-clsupermario64ds",
    "title": "supermario 64 ds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermario64ds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2357-clsupermario74",
    "title": "supermario 74",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermario74.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2358-clsupermarioallstars",
    "title": "supermarioallstars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermarioallstars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2359-clsupermariobros",
    "title": "supermariobros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariobros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2360-clsupermariobros2",
    "title": "supermariobros 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariobros2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2361-clsupermariobros2us",
    "title": "supermariobros 2 us",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariobros2us.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2362-clsupermariobros3",
    "title": "supermariobros 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariobros3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2363-clsupermariobros3real",
    "title": "supermariobros 3 real",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariobros3real.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2364-clsupermariokart",
    "title": "supermariokart",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariokart.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2365-clsupermarioland",
    "title": "supermarioland",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermarioland.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2366-clsupermarioland2",
    "title": "supermarioland 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermarioland2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2367-clsupermarioland2dx",
    "title": "supermarioland 2 dx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermarioland2dx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2368-clsupermariolanddx",
    "title": "supermariolanddx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariolanddx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2369-clsupermariomon",
    "title": "supermariomon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariomon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2370-clsupermariorpg",
    "title": "supermariorpg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariorpg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2371-clsupermariostarroad",
    "title": "supermariostarroad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariostarroad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2372-clsupermariostarroadretooled",
    "title": "supermariostarroadretooled",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariostarroadretooled.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2373-clsupermariosunshine64",
    "title": "supermariosunshine 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariosunshine64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2374-clsupermarioworld",
    "title": "supermarioworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermarioworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2375-clsupermarioworld2",
    "title": "supermarioworld 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermarioworld2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2376-clsupermarioworldthe-secretofthe7goldenstatues",
    "title": "Super Mario World The Secret Of The 7 Golden Statues",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSuperMarioWorldThe%20SecretOfThe7GoldenStatues.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2377-clsupermetroid",
    "title": "supermetroid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermetroid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2378-clsupermonkeyballjr",
    "title": "supermonkeyballjr",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermonkeyballjr.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2379-clsupernoahsark3d",
    "title": "supernoahsark 3 D",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupernoahsark3D.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2380-clsuperoliverworld",
    "title": "superoliverworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperoliverworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2381-clsuperonionboy2",
    "title": "superonionboy 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperonionboy2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2382-clsuperpickleballadventure",
    "title": "superpickleballadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperpickleballadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2383-clsuperpunchout",
    "title": "superpunchout",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperpunchout.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2384-clsuperpunchouten",
    "title": "Super Punch Out EN",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSuperPunchOutEN.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2385-clsuperpuzzlefighter2turbo",
    "title": "superpuzzlefighter 2 turbo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperpuzzlefighter2turbo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2386-clsuperpuzzlefighter2turboalt",
    "title": "superpuzzlefighter 2 turboalt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperpuzzlefighter2turboalt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2387-clsupersantakicker",
    "title": "supersantakicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupersantakicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2388-clsupersantakicker2",
    "title": "supersantakicker 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupersantakicker2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2389-clsuperscribblenauts",
    "title": "superscribblenauts",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperscribblenauts.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2390-clsupersmashbros",
    "title": "supersmashbros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupersmashbros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2391-clsupersmashflash",
    "title": "supersmashflash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupersmashflash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2392-clsupersmashflash08",
    "title": "supersmashflash 08",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupersmashflash08.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2393-clsupersmashflash2",
    "title": "supersmashflash 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupersmashflash2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2394-clsupersmashflash2butdifversion",
    "title": "supersmashflash 2 butdifversion",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupersmashflash2butdifversion.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2395-clsuperstreetfighter2turbojp",
    "title": "superstreetfighter 2 turbojp",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsuperstreetfighter2turbojp.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2396-clsupertiltbros",
    "title": "supertiltbros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupertiltbros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2397-clsupitdept",
    "title": "supitdept",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupitdept.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2398-clsupremeduelist",
    "title": "supremeduelist",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupremeduelist.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2399-clsupremeduelist2019",
    "title": "Supreme Duelist 2019",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSupremeDuelist2019.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2400-clsurvivalracev2",
    "title": "survivalracev 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsurvivalracev2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2401-clsurvivorio",
    "title": "survivorio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsurvivorio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2402-clsushicat",
    "title": "sushicat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsushicat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2403-clsushicat2",
    "title": "sushicat 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsushicat2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2404-clsushiunroll",
    "title": "sushiunroll",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsushiunroll.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2405-clswerve",
    "title": "swerve",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clswerve.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2406-clswitchblade",
    "title": "switchblade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clswitchblade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2407-clswordandshieldultimateplus",
    "title": "swordandshieldultimateplus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clswordandshieldultimateplus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2408-clswordfight",
    "title": "swordfight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clswordfight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2409-clswordplay",
    "title": "swordplay",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clswordplay.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2410-clswordsandsandals",
    "title": "swordsandsandals",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clswordsandsandals.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2411-clswordsandsandals2",
    "title": "swordsandsandals 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clswordsandsandals2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2412-clswordsandsouls",
    "title": "swordsandsouls",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clswordsandsouls.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2413-clsydneyshark",
    "title": "sydneyshark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsydneyshark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2414-cltabi",
    "title": "tabi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltabi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2415-cltabletanks",
    "title": "tabletanks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltabletanks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2416-cltabletennisworldtour",
    "title": "tabletennisworldtour",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltabletennisworldtour.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2417-cltacostand",
    "title": "tacostand",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltacostand.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2418-cltag-",
    "title": "tag-",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltag-.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2419-cltagc3",
    "title": "tagc 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltagc3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2420-cltagcm",
    "title": "tagcm",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltagcm.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2421-cltaikonotatsujin",
    "title": "Taikono Tatsujin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clTaikonoTatsujin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2422-cltailofthedragon",
    "title": "tailofthedragon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltailofthedragon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2423-cltaisei",
    "title": "taisei",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltaisei.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2424-cltakeover",
    "title": "takeover",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltakeover.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2425-cltallio",
    "title": "tallio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltallio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2426-cltallmanrun",
    "title": "tallmanrun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltallmanrun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2427-cltankmayhem",
    "title": "tankmayhem",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltankmayhem.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2428-cltankpixel",
    "title": "tankpixel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltankpixel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2429-cltanktrouble",
    "title": "tanktrouble",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltanktrouble.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2430-cltanukisunset",
    "title": "tanukisunset",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltanukisunset.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2431-cltanukisunsetuhhhhhhhh",
    "title": "tanukisunsetuhhhhhhhh",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltanukisunsetuhhhhhhhh.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2432-cltapper",
    "title": "tapper",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltapper.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2433-cltaproad",
    "title": "taproad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltaproad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2434-cltastyplanet",
    "title": "tastyplanet",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltastyplanet.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2435-cltboidemo",
    "title": "tboidemo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltboidemo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2436-cltboilambeternal",
    "title": "tboilambeternal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltboilambeternal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2437-cltecmobowl",
    "title": "tecmobowl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltecmobowl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2438-cltekken2ps1",
    "title": "tekken 2 ps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltekken2ps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2439-cltekken3ps1",
    "title": "tekken 3 ps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltekken3ps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2440-cltelephonetrouble",
    "title": "telephonetrouble",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltelephonetrouble.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2441-cltelocation",
    "title": "telocation",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltelocation.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2442-cltempest2000",
    "title": "tempest 2000",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltempest2000.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2443-cltempleofboom",
    "title": "templeofboom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltempleofboom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2444-cltemplerun2",
    "title": "templerun 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltemplerun2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2445-cltempoverdose",
    "title": "tempoverdose",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltempoverdose.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2446-clteod",
    "title": "teod",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clteod.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2447-clterra",
    "title": "terra",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clterra.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2448-clterritorialio",
    "title": "territorialio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clterritorialio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2449-clterritorywar",
    "title": "territorywar",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clterritorywar.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2450-clterritorywar2",
    "title": "territorywar 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clterritorywar2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2451-clterritorywar3",
    "title": "territorywar 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clterritorywar3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2452-cltetris",
    "title": "tetris",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltetris.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2453-cltetrisattack",
    "title": "tetrisattack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltetrisattack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2454-cltetrisgba",
    "title": "tetrisgba",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltetrisgba.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2455-cltetrisgrandmaster2",
    "title": "tetrisgrandmaster 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltetrisgrandmaster2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2456-clthanksforremindingmeihadtofixthis",
    "title": "thanksforremindingmeihadtofixthis",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthanksforremindingmeihadtofixthis.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2457-cltheclassroom",
    "title": "theclassroom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltheclassroom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2458-cltheclassroom2",
    "title": "theclassroom 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltheclassroom2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2459-cltheclassroom3",
    "title": "theclassroom 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltheclassroom3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2460-clthedeadseat",
    "title": "thedeadseat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthedeadseat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2461-clthedeepestsleep",
    "title": "thedeepestsleep",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthedeepestsleep.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2462-clthedude",
    "title": "thedude",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthedude.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2463-cltheenchantedcave2",
    "title": "theenchantedcave 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltheenchantedcave2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2464-cltheimpossiblegame",
    "title": "theimpossiblegame",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltheimpossiblegame.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2465-cltheincrediblemachine",
    "title": "theincrediblemachine",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltheincrediblemachine.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2466-clthelaststand",
    "title": "thelaststand",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthelaststand.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2467-clthelaststandunioncity--1-",
    "title": "thelaststandunioncity (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthelaststandunioncity%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2468-clthelaststandunioncity",
    "title": "thelaststandunioncity",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthelaststandunioncity.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2469-cltheloneranger",
    "title": "The Lone Ranger",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clTheLoneRanger.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2470-clthemaninthewindow",
    "title": "themaninthewindow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthemaninthewindow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2471-clthemepark",
    "title": "themepark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthemepark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2472-clthepit",
    "title": "thepit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthepit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2473-clthereisnofile",
    "title": "thereisnofile",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthereisnofile.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2474-clthermomorph",
    "title": "thermomorph",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthermomorph.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2475-clthesodorrace",
    "title": "thesodorrace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthesodorrace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2476-clthesunforthevampire",
    "title": "The Sun For The Vampire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clTheSunForTheVampire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2477-cltheyarecoming",
    "title": "theyarecoming",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltheyarecoming.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2478-clthisistheonlylevel",
    "title": "thisistheonlylevel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthisistheonlylevel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2479-clthisistheonlylevel2",
    "title": "thisistheonlylevel 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthisistheonlylevel2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2480-clthisistheonlyleveltoo",
    "title": "thisistheonlyleveltoo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthisistheonlyleveltoo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2481-clthreegoblets",
    "title": "threegoblets",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthreegoblets.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2482-clthrowapotato",
    "title": "throwapotato",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthrowapotato.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2483-clthrowapotatoagain",
    "title": "throwapotatoagain",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthrowapotatoagain.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2484-clthwack",
    "title": "thwack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthwack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2485-cltiberiandawn",
    "title": "tiberiandawn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltiberiandawn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2486-cltimeshooter2",
    "title": "timeshooter 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltimeshooter2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2487-cltimeshooter3",
    "title": "timeshooter 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltimeshooter3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2488-cltimewarriors",
    "title": "timewarriors",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltimewarriors.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2489-cltinyfishing",
    "title": "tinyfishing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltinyfishing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2490-cltmnt",
    "title": "tmnt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltmnt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2491-cltmnt2arc",
    "title": "tmnt 2 arc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltmnt2arc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2492-cltmntarc",
    "title": "tmntarc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltmntarc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2493-cltmntturtlesintime",
    "title": "tmntturtlesintime",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltmntturtlesintime.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2494-cltoastarling",
    "title": "toastarling",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltoastarling.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2495-cltoasterball",
    "title": "toasterball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltoasterball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2496-cltoejam-earl",
    "title": "toejam&earl",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltoejam%26earl.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2497-cltoejam-earlpof",
    "title": "toejam&earlpof",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltoejam%26earlpof.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2498-cltombofthemass",
    "title": "tombofthemass",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltombofthemass.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2499-cltommorowandyesterday",
    "title": "tommorowandyesterday",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltommorowandyesterday.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2500-cltomodachicollection",
    "title": "tomodachicollection",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltomodachicollection.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2501-cltonyhawkskater2",
    "title": "tonyhawkskater 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltonyhawkskater2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2502-cltonyhawkskater4",
    "title": "tonyhawkskater 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltonyhawkskater4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2503-cltonyhawksunderground",
    "title": "tonyhawksunderground",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltonyhawksunderground.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2504-cltoomanytypes",
    "title": "toomanytypes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltoomanytypes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2505-cltopspeedracing3d",
    "title": "topspeedracing 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltopspeedracing3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2506-cltosstheturtle",
    "title": "tosstheturtle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltosstheturtle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2507-cltotm",
    "title": "totm",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltotm.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2508-cltouhou",
    "title": "touhou",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltouhou.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2509-cltouhou2",
    "title": "touhou 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltouhou2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2510-cltouhou3",
    "title": "touhou 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltouhou3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2511-cltouhou4",
    "title": "touhou 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltouhou4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2512-cltouhou5",
    "title": "touhou 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltouhou5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2513-cltowerblocks",
    "title": "towerblocks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltowerblocks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2514-cltowercrash3d",
    "title": "towercrash 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltowercrash3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2515-cltowerwizard",
    "title": "towerwizard",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltowerwizard.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2516-cltownscraper",
    "title": "townscraper",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltownscraper.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2517-cltrace",
    "title": "trace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2518-cltrafficjam3d",
    "title": "trafficjam 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrafficjam3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2519-cltralalerotralalaescapetungtungtungsahur",
    "title": "tralalerotralalaescapetungtungtungsahur",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltralalerotralalaescapetungtungtungsahur.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2520-cltrappedwithjester",
    "title": "trappedwithjester",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrappedwithjester.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2521-cltrapthecat",
    "title": "trapthecat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrapthecat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2522-cltrechoroustrials",
    "title": "trechoroustrials",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrechoroustrials.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2523-cltrechoroustrialspart2",
    "title": "trechoroustrialspart 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrechoroustrialspart2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2524-cltriachnid",
    "title": "triachnid",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltriachnid.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2525-cltripleplay2000",
    "title": "tripleplay 2000",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltripleplay2000.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2526-cltriviacrack",
    "title": "triviacrack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltriviacrack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2527-cltrollfacequest1",
    "title": "trollfacequest 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2528-cltrollfacequest10",
    "title": "trollfacequest 10",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest10.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2529-cltrollfacequest11",
    "title": "trollfacequest 11",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest11.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2530-cltrollfacequest12",
    "title": "trollfacequest 12",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest12.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2531-cltrollfacequest13",
    "title": "trollfacequest 13",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest13.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2532-cltrollfacequest2",
    "title": "trollfacequest 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2533-cltrollfacequest3",
    "title": "trollfacequest 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2534-cltrollfacequest4",
    "title": "trollfacequest 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2535-cltrollfacequest5",
    "title": "trollfacequest 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2536-cltrollfacequest6",
    "title": "trollfacequest 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2537-cltrollfacequest7",
    "title": "trollfacequest 7",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest7.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2538-cltrollfacequest8",
    "title": "trollfacequest 8",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest8.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2539-cltrollfacequest9",
    "title": "trollfacequest 9",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrollfacequest9.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2540-cltrucksim",
    "title": "trucksim",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltrucksim.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2541-cltsuzukimaze",
    "title": "tsuzukimaze",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltsuzukimaze.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2542-cltubejumpers",
    "title": "tubejumpers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltubejumpers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2543-cltungtunghorror",
    "title": "tungtunghorror",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltungtunghorror.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2544-cltungtungtungsahurobby",
    "title": "tungtungtungsahurobby",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltungtungtungsahurobby.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2545-cltunnelrush",
    "title": "tunnelrush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltunnelrush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2546-cltunnelrushbetter",
    "title": "tunnelrushbetter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltunnelrushbetter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2547-cltupertariotros",
    "title": "tupertariotros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltupertariotros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2548-clturbostars",
    "title": "turbostars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clturbostars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2549-clturokdinosaurhunter",
    "title": "turokdinosaurhunter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clturokdinosaurhunter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2550-cltwinshot--1-",
    "title": "twinshot (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltwinshot%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2551-cltwinshot-1-",
    "title": "twinshot(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltwinshot(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2552-cltwinshot",
    "title": "twinshot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltwinshot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2553-cltwistedmetal",
    "title": "twistedmetal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltwistedmetal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2554-cltwistedmetal2",
    "title": "twistedmetal 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltwistedmetal2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2555-cltwoball3d",
    "title": "twoball 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltwoball3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2556-clucds",
    "title": "ucds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clucds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2557-cluckyblockobbyeuophratesriver",
    "title": "uckyblockobby EUOPHRATESRIVER",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cluckyblockobbyEUOPHRATESRIVER.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2558-clufoswampoddysey",
    "title": "ufoswampoddysey",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clufoswampoddysey.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2559-clultima",
    "title": "ultima",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clultima.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2560-clultimateassassian2",
    "title": "ultimateassassian 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clultimateassassian2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2561-clultimateassassian3",
    "title": "ultimateassassian 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clultimateassassian3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2562-clultimatecardrivingsimulator",
    "title": "Ultimatecardrivingsimulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clUltimatecardrivingsimulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2563-clultimatemortalkombat",
    "title": "ultimatemortalkombat",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clultimatemortalkombat.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2564-clultimatemortalkombat3",
    "title": "ultimatemortalkombat 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clultimatemortalkombat3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2565-clultrakill",
    "title": "ultrakill",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clultrakill.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2566-clumjammerlammy",
    "title": "umjammerlammy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clumjammerlammy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2567-clumstickmangameidkiforgor",
    "title": "umstickmangameidkiforgor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clumstickmangameidkiforgor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2568-cluncannycatgolf",
    "title": "uncannycatgolf",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cluncannycatgolf.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2569-clunderneath",
    "title": "underneath",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clunderneath.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2570-clundertalelb",
    "title": "undertalelb",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clundertalelb.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2571-clundertaler",
    "title": "undertaler",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clundertaler.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2572-clundertaleyellow",
    "title": "undertaleyellow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clundertaleyellow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2573-clunfairmario",
    "title": "unfairmario",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clunfairmario.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2574-clunfairmarioworkquestionmark",
    "title": "unfairmarioworkquestionmark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clunfairmarioworkquestionmark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2575-clunfairundyne",
    "title": "unfairundyne",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clunfairundyne.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2576-clunicyclehero",
    "title": "unicyclehero",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clunicyclehero.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2577-clunitresdreams",
    "title": "unitresdreams",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clunitresdreams.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2578-cluno",
    "title": "uno",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cluno.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2579-clunownking",
    "title": "unownking",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clunownking.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2580-cluntime",
    "title": "untime",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cluntime.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2581-cluntitledgoosegame",
    "title": "untitledgoosegame",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cluntitledgoosegame.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2582-clupgradecomplete",
    "title": "upgradecomplete",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clupgradecomplete.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2583-clupgradecomplete2",
    "title": "upgradecomplete 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clupgradecomplete2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2584-clupslash",
    "title": "upslash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clupslash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2585-clusterrush",
    "title": "usterrush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clusterrush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2586-cluzg",
    "title": "UZG",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clUZG.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2587-clvampiresurvivors",
    "title": "vampiresurvivors",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvampiresurvivors.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2588-clvanguard",
    "title": "vanguard",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvanguard.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2589-clvaportrails",
    "title": "vaportrails",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvaportrails.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2590-clvex",
    "title": "vex",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvex.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2591-clvex2",
    "title": "vex 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvex2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2592-clvex3",
    "title": "vex 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvex3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2593-clvex3xmas",
    "title": "vex 3 xmas",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvex3xmas.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2594-clvex4",
    "title": "vex 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvex4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2595-clvex5",
    "title": "vex 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvex5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2596-clvex6",
    "title": "vex 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvex6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2597-clvex7",
    "title": "vex 7",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvex7.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2598-clvex8",
    "title": "vex 8",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvex8.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2599-clvexchallenges",
    "title": "vexchallenges",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvexchallenges.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2600-clvexx3m",
    "title": "vexx 3 m",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvexx3m.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2601-clvexx3m2",
    "title": "vexx 3 m 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvexx3m2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2602-clvillager",
    "title": "villager",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvillager.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2603-clvincentmansionofthedead",
    "title": "vincentmansionofthedead",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvincentmansionofthedead.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2604-clvisitor",
    "title": "visitor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvisitor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2605-clvolleyrandom",
    "title": "volleyrandom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvolleyrandom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2606-clvollyballchallenge",
    "title": "vollyballchallenge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvollyballchallenge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2607-clvortex",
    "title": "vortex",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvortex.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2608-clvsagore",
    "title": "vsagore",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvsagore.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2609-clvsnonsense",
    "title": "vsnonsense",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvsnonsense.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2610-clvssmb",
    "title": "VSSMB",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clVSSMB.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2611-clvvvvvv-1-",
    "title": "vvvvvv(1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvvvvvv(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2612-clvvvvvv",
    "title": "vvvvvv",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvvvvvv.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2613-clwaluigitacostand",
    "title": "waluigitacostand",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwaluigitacostand.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2614-clwarfare1917",
    "title": "warfare 1917",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwarfare1917.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2615-clwarfare1944",
    "title": "warfare 1944",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwarfare1944.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2616-clwarioland1",
    "title": "warioland 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwarioland1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2617-clwarioland3",
    "title": "warioland 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwarioland3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2618-clwarioland4",
    "title": "warioland 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwarioland4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2619-clwariowarediy",
    "title": "wariowarediy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwariowarediy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2620-clwariowareinc",
    "title": "wariowareinc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwariowareinc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2621-clwartheknight",
    "title": "wartheknight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwartheknight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2622-clwaterpoolio",
    "title": "waterpoolio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwaterpoolio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2623-clwaterworks",
    "title": "waterworks",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwaterworks.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2624-clwavedash",
    "title": "wavedash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwavedash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2625-clwaverace64",
    "title": "waverace 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwaverace64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2626-clwaverun",
    "title": "waverun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwaverun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2627-clwebecomewhatwebehold",
    "title": "webecomewhatwebehold",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwebecomewhatwebehold.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2628-clwebfishing",
    "title": "webfishing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwebfishing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2629-clweltling",
    "title": "weltling",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clweltling.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2630-clwermhole",
    "title": "wermhole",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwermhole.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2631-clwhackthetheif",
    "title": "whackthetheif",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwhackthetheif.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2632-clwhackyourboss",
    "title": "whackyourboss",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwhackyourboss.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2633-clwhackyourcomputer",
    "title": "whackyourcomputer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwhackyourcomputer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2634-clwhatamarioworld",
    "title": "whatamarioworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwhatamarioworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2635-clwheeliebike",
    "title": "wheeliebike",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwheeliebike.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2636-clwheely",
    "title": "wheely",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwheely.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2637-clwheely2",
    "title": "wheely 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwheely2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2638-clwheely3",
    "title": "wheely 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwheely3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2639-clwheely4",
    "title": "wheely 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwheely4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2640-clwheely5",
    "title": "wheely 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwheely5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2641-clwheely6",
    "title": "wheely 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwheely6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2642-clwheely7",
    "title": "wheely 7",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwheely7.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2643-clwheely8",
    "title": "wheely 8",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwheely8.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2644-clwilywars",
    "title": "wilywars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwilywars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2645-clwindowsdoors",
    "title": "windowsdoors",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwindowsdoors.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2646-clwinterfalling",
    "title": "winterfalling",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwinterfalling.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2647-clwinterolympics",
    "title": "winterolympics",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwinterolympics.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2648-clwipeout2097",
    "title": "wipeout 2097",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwipeout2097.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2649-clwipeout2097alt",
    "title": "wipeout 2097 alt",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwipeout2097alt.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2650-clwitchcrafttd",
    "title": "witchcrafttd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwitchcrafttd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2651-clwolfchild",
    "title": "wolfchild",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwolfchild.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2652-clwolfenstein",
    "title": "wolfenstein",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwolfenstein.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2653-clwolfenstein3d",
    "title": "wolfenstein 3 d",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwolfenstein3d.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2654-clwoodworm",
    "title": "woodworm",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwoodworm.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2655-clwordle",
    "title": "wordle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwordle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2656-clworldcup98",
    "title": "worldcup 98",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clworldcup98.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2657-clworldshardestgame",
    "title": "worldshardestgame",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clworldshardestgame.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2658-clworldshardestgame2",
    "title": "worldshardestgame 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clworldshardestgame2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2659-clworldshardestgame3",
    "title": "worldshardestgame 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clworldshardestgame3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2660-clworldshardestgame4",
    "title": "worldshardestgame 4",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clworldshardestgame4.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2661-clwpnfire",
    "title": "wpnfire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwpnfire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2662-clwrassling",
    "title": "wrassling",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwrassling.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2663-clwrestlebros",
    "title": "wrestlebros",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwrestlebros.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2664-clwwfattitude",
    "title": "wwfattitude",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwwfattitude.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2665-clwwfsmackdown2",
    "title": "wwfsmackdown 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwwfsmackdown2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2666-clxevent",
    "title": "xevent",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clxevent.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2667-clxevious",
    "title": "Xevious",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clXevious.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2668-clxmenarcade",
    "title": "xmenarcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clxmenarcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2669-clxmenchildrenoftheatomarcade",
    "title": "XMen Children Of The Atom Arcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clXMenChildrenOfTheAtomArcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2670-clxmenvsstreetfighter",
    "title": "XMen VSStreet Fighter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clXMenVSStreetFighter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2671-clyanderesimulator",
    "title": "yanderesimulator",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clyanderesimulator.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2672-clyarsrevenge",
    "title": "yarsrevenge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clyarsrevenge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2673-clyellow",
    "title": "yellow",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clyellow.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2674-clyohohoio",
    "title": "yohohoio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clyohohoio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2675-clyoshisstrangequest",
    "title": "Yoshis Strange Quest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clYoshisStrangeQuest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2676-clyouarelucky",
    "title": "youarelucky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clyouarelucky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2677-clyourturntodie",
    "title": "yourturntodie",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clyourturntodie.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2678-clyouvs100skibidi",
    "title": "youvs 100 skibidi",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clyouvs100skibidi.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2679-clyumenikki",
    "title": "yumenikki",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clyumenikki.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2680-clzdoom",
    "title": "zdoom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzdoom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2681-clzelda2thelegendoflink",
    "title": "zelda 2 thelegendoflink",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzelda2thelegendoflink.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2682-clzeldaindigoch2",
    "title": "Zelda Indigoch 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clZeldaIndigoch2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2683-clzeldaminishcap",
    "title": "zeldaminishcap",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzeldaminishcap.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2684-clzenword",
    "title": "zenword",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzenword.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2685-clzoinkz",
    "title": "zoinkz",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzoinkz.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2686-clzombieexploder",
    "title": "zombieexploder",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzombieexploder.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2687-clzombieroad",
    "title": "zombieroad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzombieroad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2688-clzombierush",
    "title": "zombierush",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzombierush.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2689-clzombiesatemyneighboors",
    "title": "zombiesatemyneighboors",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzombiesatemyneighboors.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2690-clzombopaclypse2",
    "title": "zombopaclypse 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzombopaclypse2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2691-clzombotron",
    "title": "zombotron",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzombotron.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2692-clzombotron2",
    "title": "zombotron 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzombotron2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2693-clzombotronreboot",
    "title": "zombotronreboot",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzombotronreboot.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2694-clzrist",
    "title": "zrist",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzrist.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2695-clzuma",
    "title": "zuma",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzuma.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2696-clzumashooter",
    "title": "zumashooter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clzumashooter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2697-cl-oo",
    "title": "�oo",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl%EF%BF%BDoo.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2698-clbaldi-3",
    "title": "baldi-3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaldi-3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2699-clbaldi-b",
    "title": "baldi-b",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaldi-b.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2700-cl100in1nes",
    "title": "100 in 1 nes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl100in1nes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2701-cl10bullets",
    "title": "10 bullets",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl10bullets.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2702-cl10yardfight",
    "title": "10 yardfight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl10yardfight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2703-cl1942nes",
    "title": "1942 nes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl1942nes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2704-claceattorneymilesedgeworth",
    "title": "aceattorneymilesedgeworth",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/claceattorneymilesedgeworth.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2705-cladvancewarsdualstrike",
    "title": "advancewarsdualstrike",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cladvancewarsdualstrike.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2706-clalexkiddinmiracleworld",
    "title": "alexkiddinmiracleworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clalexkiddinmiracleworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2707-clangrybirds2",
    "title": "angrybirds 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clangrybirds2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2708-clangrybirdsslingshotfrenzy",
    "title": "angrybirdsslingshotfrenzy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clangrybirdsslingshotfrenzy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2709-clanimalcrossing",
    "title": "animalcrossing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clanimalcrossing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2710-clanimalforestn64",
    "title": "animalforestn 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clanimalforestn64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2711-clantipathy",
    "title": "antipathy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clantipathy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2712-clarcadevolley",
    "title": "arcadevolley",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clarcadevolley.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2713-classroommaxxing",
    "title": "assroommaxxing",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/classroommaxxing.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2714-clb3313unabandoneda2",
    "title": "b 3313 unabandoned A2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clb3313unabandonedA2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2715-clbadicecream2",
    "title": "badicecream 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadicecream2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2716-clbadicecream3",
    "title": "badicecream 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbadicecream3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2717-clballoonfight",
    "title": "balloonfight",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clballoonfight.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2718-clbaseballnes",
    "title": "baseballnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbaseballnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2719-clbejeweledtwistds",
    "title": "bejeweledtwistds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbejeweledtwistds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2720-clbitburner",
    "title": "bitburner",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbitburner.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2721-clbotwds",
    "title": "botwds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbotwds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2722-clbrotato",
    "title": "brotato",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbrotato.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2723-clbuckbumble",
    "title": "buckbumble",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clbuckbumble.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2724-clcactusmccoy",
    "title": "cactusmccoy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcactusmccoy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2725-clcactusmccoy2",
    "title": "cactusmccoy 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcactusmccoy2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2726-clcarnivalgamesds",
    "title": "carnivalgamesds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcarnivalgamesds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2727-clceleste",
    "title": "celeste",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clceleste.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2728-clceleste2",
    "title": "celeste 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clceleste2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2729-clcelestemariodx",
    "title": "celestemariodx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcelestemariodx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2730-clceliasstupidromhack",
    "title": "Celias Stupid ROMHack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clCeliasStupidROMHack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2731-clchoroqwonderful",
    "title": "choroqwonderful",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clchoroqwonderful.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2732-clclucluland",
    "title": "clucluland",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clclucluland.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2733-clcoldfront",
    "title": "coldfront",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoldfront.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2734-clcoverorangeplayerspack3",
    "title": "coverorangeplayerspack 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcoverorangeplayerspack3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2735-clcrash2",
    "title": "crash 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrash2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2736-clcrash3",
    "title": "crash 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrash3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2737-clcrashbandicoot--1-",
    "title": "crashbandicoot (1)",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrashbandicoot%20(1).html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2738-clcrashbash",
    "title": "crashbash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcrashbash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2739-clcvooc",
    "title": "cvooc",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clcvooc.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2740-cldecision3",
    "title": "decision 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldecision3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2741-cldknescollection",
    "title": "DKNESCollection",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clDKNESCollection.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2742-cldodecadragons",
    "title": "dodecadragons",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldodecadragons.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2743-cldoomori",
    "title": "doomori",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoomori.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2744-cldoubledribble",
    "title": "doubledribble",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldoubledribble.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2745-cldragonquest5ds",
    "title": "dragonquest 5 ds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldragonquest5ds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2746-clducktales2",
    "title": "ducktales 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clducktales2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2747-cldunedash",
    "title": "dunedash",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldunedash.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2748-cldungeonsanddegenerategambler",
    "title": "dungeonsanddegenerategambler",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldungeonsanddegenerategambler.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2749-cldungeonsanddegenerategamblerdebug",
    "title": "dungeonsanddegenerategamblerdebug",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cldungeonsanddegenerategamblerdebug.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2750-cleccothedolphin",
    "title": "eccothedolphin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleccothedolphin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2751-clelevatoraction",
    "title": "elevatoraction",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clelevatoraction.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2752-clescalatingduel",
    "title": "escalatingduel",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clescalatingduel.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2753-clescaperoad3",
    "title": "escaperoad 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clescaperoad3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2754-cleugeneslife",
    "title": "eugeneslife",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cleugeneslife.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2755-clexcitebike",
    "title": "excitebike",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clexcitebike.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2756-clexitpath",
    "title": "exitpath",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clexitpath.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2757-clfamidashesides1-2-8",
    "title": "famidash ESides 1.2.8",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfamidashESides1.2.8",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2758-clfantasyzone",
    "title": "fantasyzone",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfantasyzone.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2759-clfinalfantasy2nes",
    "title": "finalfantasy 2 nes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasy2nes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2760-clfinalfantasy3nes",
    "title": "finalfantasy 3 nes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfinalfantasy3nes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2761-clfivenightsatfrickbears3",
    "title": "fivenightsatfrickbears 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfivenightsatfrickbears3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2762-clfloodrunner3",
    "title": "floodrunner 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfloodrunner3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2763-clfnfsohv2",
    "title": "fnfsohv 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfnfsohv2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2764-clfzerox",
    "title": "fzerox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clfzerox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2765-clgeometrydashwave",
    "title": "Geometry Dash Wave",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clGeometryDashWave.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2766-clgettingoverit",
    "title": "gettingoverit",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgettingoverit.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2767-clgrandshiftauto",
    "title": "grandshiftauto",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgrandshiftauto.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2768-clgyromite",
    "title": "gyromite",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clgyromite.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2769-clhangonsms",
    "title": "hangonsms",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhangonsms.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2770-clheartandsoul1-2-1",
    "title": "heartandsoul 1.2.1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clheartandsoul1.2.1",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2771-clhelltaker",
    "title": "Helltaker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clHelltaker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2772-clhl2doom",
    "title": "hl 2 doom",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhl2doom.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2773-clhoennslastwish",
    "title": "Hoenns Last Wish",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clHoennsLastWish.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2774-clhooked",
    "title": "hooked",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhooked.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2775-clhorntale",
    "title": "horntale",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhorntale.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2776-clhungrylamu2",
    "title": "hungrylamu 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhungrylamu2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2777-clhungrypumpkin",
    "title": "hungrypumpkin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clhungrypumpkin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2778-cliceclimber",
    "title": "iceclimber",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cliceclimber.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2779-clihateyou",
    "title": "ihateyou",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clihateyou.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2780-climpossiblequiz",
    "title": "impossiblequiz",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/climpossiblequiz.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2781-climpossiblequiz2",
    "title": "impossiblequiz 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/climpossiblequiz2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2782-cljojobaps1",
    "title": "jojobaps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljojobaps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2783-cljustaplatformer",
    "title": "justaplatformer",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljustaplatformer.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2784-cljustaplatformere",
    "title": "justaplatformer E",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljustaplatformerE.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2785-cljustaplatformere2",
    "title": "justaplatformer E2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cljustaplatformerE2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2786-clknuckleschaotix",
    "title": "knuckleschaotix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clknuckleschaotix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2787-clleafblower",
    "title": "leafblower",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clleafblower.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2788-cllearntofly2hacked",
    "title": "learntofly 2 hacked",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllearntofly2hacked.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2789-cllearntofly3debug",
    "title": "Learn To Fly 3 Debug",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clLearnToFly3Debug.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2790-cllearntoflyidle",
    "title": "learntoflyidle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllearntoflyidle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2791-cllearntoflyidlehack",
    "title": "learntoflyidlehack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllearntoflyidlehack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2792-cllegionbreaker",
    "title": "legionbreaker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cllegionbreaker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2793-clmachrider",
    "title": "machrider",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmachrider.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2794-clmariobrosnes",
    "title": "mariobrosnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmariobrosnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2795-clmarvelvscapcomps1",
    "title": "Marvel Vs Capcom PS1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMarvelVsCapcomPS1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2796-clmarvelvsstreetfighter",
    "title": "Marvel Vs Street Fighter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clMarvelVsStreetFighter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2797-clmedalofhonor",
    "title": "medalofhonor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmedalofhonor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2798-clmegamanx5",
    "title": "megamanx 5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanx5.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2799-clmegamanx6",
    "title": "megamanx 6",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmegamanx6.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2800-clmeowio",
    "title": "meowio",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmeowio.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2801-clmidwaysgreatesthitsn64",
    "title": "midwaysgreatesthitsn 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmidwaysgreatesthitsn64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2802-clmkmythologiesn64",
    "title": "mkmythologiesn 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmkmythologiesn64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2803-clmktrilogyps1",
    "title": "mktrilogyps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmktrilogyps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2804-clmrdriller",
    "title": "mrdriller",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmrdriller.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2805-clmrdriller2",
    "title": "mrdriller 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clmrdriller2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2806-clneonrider",
    "title": "neonrider",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clneonrider.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2807-clnewersmbds",
    "title": "newersmbds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnewersmbds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2808-clnewsuperbowserworld",
    "title": "newsuperbowserworld",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnewsuperbowserworld.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2809-clnguidle",
    "title": "nguidle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnguidle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2810-clnsmbuds",
    "title": "nsmbuds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnsmbuds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2811-clnsmbwds",
    "title": "nsmbwds",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clnsmbwds.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2812-clootmasterquest",
    "title": "Oot Master Quest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clOotMasterQuest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2813-clorangeroulette",
    "title": "Orange Roulette",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clOrangeRoulette.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2814-clpapermariodse",
    "title": "Paper Mario DSE",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPaperMarioDSE.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2815-clpapermariopracticehack",
    "title": "Paper Mario Practice Hack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPaperMarioPracticeHack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2816-clpinballnes",
    "title": "pinballnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpinballnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2817-clpokeambrosia",
    "title": "Poke Ambrosia",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeAmbrosia.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2818-clpokecrystaladvanceredux",
    "title": "pokecrystaladvanceredux",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokecrystaladvanceredux.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2819-clpokecrystalclear",
    "title": "pokecrystalclear",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokecrystalclear.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2820-clpokeemeraldextendedcut",
    "title": "pokeemeraldextendedcut",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldextendedcut.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2821-clpokeemeraldimperium",
    "title": "pokeemeraldimperium",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldimperium.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2822-clpokeemeraldrogue",
    "title": "pokeemeraldrogue",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokeemeraldrogue.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2823-clpokeemeraldrogueex",
    "title": "Poke Emerald Rogue EX",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeEmeraldRogueEX.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2824-clpokefrlgplus",
    "title": "pokefrlgplus",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokefrlgplus.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2825-clpokefusion3",
    "title": "Poke Fusion 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeFusion3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2826-clpokegoldenshield",
    "title": "pokegoldenshield",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokegoldenshield.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2827-clpokeheartgoldgenerations",
    "title": "Poke Heartgold Generations",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeHeartgoldGenerations.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2828-clpokelowbudgetcrystal",
    "title": "pokelowbudgetcrystal",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokelowbudgetcrystal.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2829-clpokemonemeraldcrest",
    "title": "pokemonemeraldcrest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonemeraldcrest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2830-clpokemonemeraldrouge",
    "title": "Pokemonemeraldrouge",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokemonemeraldrouge.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2831-clpokemonperfectemerald5-5",
    "title": "pokemonperfectemerald 5.5",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonperfectemerald5.5",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2832-clpokemonstadium2",
    "title": "pokemonstadium 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemonstadium2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2833-clpokemoonemerald",
    "title": "pokemoonemerald",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemoonemerald.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2834-clpokemoongalaxy",
    "title": "pokemoongalaxy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokemoongalaxy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2835-clpokepicross",
    "title": "pokepicross",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepicross.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2836-clpokepureblue",
    "title": "pokepureblue",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepureblue.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2837-clpokepuregreen",
    "title": "pokepuregreen",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepuregreen.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2838-clpokepurered",
    "title": "pokepurered",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokepurered.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2839-clpokerowe",
    "title": "pokerowe",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokerowe.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2840-clpokescrambledscarlet",
    "title": "pokescrambledscarlet",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokescrambledscarlet.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2841-clpokesunsky",
    "title": "pokesunsky",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpokesunsky.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2842-clpokethetaemeraldex",
    "title": "Poke Theta Emerald EX",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clPokeThetaEmeraldEX.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2843-clpoketoomanytypes2",
    "title": "poketoomanytypes 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpoketoomanytypes2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2844-clportraitofruin",
    "title": "portraitofruin",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clportraitofruin.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2845-clprankcalltungtungtungsahurclicker",
    "title": "prankcalltungtungtungsahurclicker",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprankcalltungtungtungsahurclicker.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2846-clprestigetree",
    "title": "prestigetree",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprestigetree.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2847-clprowrestling",
    "title": "prowrestling",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clprowrestling.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2848-clpunchthetrump",
    "title": "punchthetrump",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clpunchthetrump.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2849-clquake",
    "title": "quake",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clquake.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2850-clrabbithole106",
    "title": "rabbithole 106",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrabbithole106.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2851-clradicalred",
    "title": "radicalred",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clradicalred.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2852-clreacticore",
    "title": "reacticore",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clreacticore.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2853-clroadrunnernes",
    "title": "roadrunnernes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clroadrunnernes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2854-clrunfromwitheredfox",
    "title": "runfromwitheredfox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clrunfromwitheredfox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2855-clscoobydoocreepyrun",
    "title": "scoobydoocreepyrun",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscoobydoocreepyrun.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2856-clscoobydoozombiehunter",
    "title": "scoobydoozombiehunter",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clscoobydoozombiehunter.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2857-clsimcity64",
    "title": "simcity 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsimcity64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2858-clsinglefile",
    "title": "SINGLEFILE",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSINGLEFILE.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2859-clskywire",
    "title": "skywire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskywire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2860-clskywire2",
    "title": "skywire 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clskywire2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2861-clslalomnes",
    "title": "slalomnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslalomnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2862-clslicemaster",
    "title": "slicemaster",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clslicemaster.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2863-clsm64greenstars",
    "title": "sm 64 greenstars",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64greenstars.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2864-clsm64land",
    "title": "SM64 Land",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSM64Land.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2865-clsm64lastimpact",
    "title": "sm 64 lastimpact",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64lastimpact.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2866-clsm64liminaldream",
    "title": "sm 64 liminaldream",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64liminaldream.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2867-clsm64sapphire",
    "title": "sm 64 sapphire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64sapphire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2868-clsm64yscaled",
    "title": "sm 64 yscaled",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsm64yscaled.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2869-clsmashremix2-0-1",
    "title": "smashremix 2.0.1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsmashremix2.0.1",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2870-clsoccernes",
    "title": "soccernes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoccernes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2871-clsomari64",
    "title": "somari 64",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsomari64.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2872-clsonic2pinkedition",
    "title": "sonic 2 pinkedition",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic2pinkedition.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2873-clsonic2timeandplace",
    "title": "sonic 2 timeandplace",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic2timeandplace.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2874-clsonic3andsally",
    "title": "sonic 3 andsally",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonic3andsally.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2875-clsoniccd",
    "title": "soniccd",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsoniccd.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2876-clsonicclassicheroes",
    "title": "sonicclassicheroes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicclassicheroes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2877-clsonicdrift",
    "title": "sonicdrift",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicdrift.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2878-clsonicdrift2",
    "title": "sonicdrift 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicdrift2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2879-clsonicerazor",
    "title": "sonicerazor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicerazor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2880-clsonicmegamix5-0aleaked",
    "title": "sonicmegamix 5.0 a LEAKED",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicmegamix5.0aLEAKED",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2881-clsonicmushroomblast",
    "title": "sonicmushroomblast",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicmushroomblast.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2882-clsonicscorchedquest",
    "title": "sonicscorchedquest",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsonicscorchedquest.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2883-clsotn",
    "title": "sotn",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsotn.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2884-clspaceharriersms",
    "title": "spaceharriersms",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspaceharriersms.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2885-clspidermanps1",
    "title": "spidermanps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clspidermanps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2886-clsportsheadsicehockey",
    "title": "Sports Heads Ice Hockey",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clSportsHeadsIceHockey.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2887-clsprunkipyramixed",
    "title": "sprunkipyramixed",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsprunkipyramixed.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2888-clstarfox",
    "title": "starfox",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstarfox.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2889-clstarfox2",
    "title": "starfox 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstarfox2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2890-clstarfoxsfx2",
    "title": "starfoxsfx 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clstarfoxsfx2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2891-clsugaryspire",
    "title": "sugaryspire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsugaryspire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2892-clsupermario3mix",
    "title": "supermario 3 mix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermario3mix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2893-clsupermario74",
    "title": "supermario 74",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermario74.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2894-clsupermariostarroad",
    "title": "supermariostarroad",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariostarroad.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2895-clsupermariostarroadretooled",
    "title": "supermariostarroadretooled",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clsupermariostarroadretooled.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2896-clswingforbrainrots",
    "title": "swingforbrainrots",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clswingforbrainrots.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2897-cltailsadventure",
    "title": "tailsadventure",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltailsadventure.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2898-cltailsskypatrol",
    "title": "tailsskypatrol",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltailsskypatrol.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2899-cltekken2ps1",
    "title": "tekken 2 ps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltekken2ps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2900-cltekken3ps1",
    "title": "tekken 3 ps 1",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltekken3ps1.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2901-cltennisnes",
    "title": "tennisnes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltennisnes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2902-clthemeparkpsx",
    "title": "themeparkpsx",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clthemeparkpsx.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2903-clthesunforthevampire",
    "title": "The Sun For The Vampire",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clTheSunForTheVampire.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2904-cltomodachicollection",
    "title": "tomodachicollection",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltomodachicollection.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2905-cltoomanytypes",
    "title": "toomanytypes",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltoomanytypes.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2906-cltreeshateyou",
    "title": "treeshateyou",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltreeshateyou.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2907-cltungtungbasics",
    "title": "tungtungbasics",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cltungtungbasics.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2908-clumjammerlammy",
    "title": "umjammerlammy",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clumjammerlammy.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2909-clunfairmarioworkquestionmark",
    "title": "unfairmarioworkquestionmark",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clunfairmarioworkquestionmark.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2910-clurbanchampion",
    "title": "urbanchampion",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clurbanchampion.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2911-cluvuvwevwevweonyetenvewveugwemubwemossas",
    "title": "Uvuvwevwevwe Onyetenvewve Ugwemubwem Ossas",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clUvuvwevwevweOnyetenvewveUgwemubwemOssas.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2912-clvibribbon",
    "title": "vibribbon",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvibribbon.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2913-clvolleyball",
    "title": "volleyball",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clvolleyball.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2914-clwackyflip",
    "title": "wackyflip",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwackyflip.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2915-clwbml",
    "title": "wbml",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwbml.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2916-clwebdashers",
    "title": "webdashers",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwebdashers.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2917-clwonderboy3",
    "title": "wonderboy 3",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwonderboy3.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2918-clwonderboyarcade",
    "title": "wonderboyarcade",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwonderboyarcade.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2919-clwreckingcrew",
    "title": "wreckingcrew",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwreckingcrew.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2920-clwwfattitude",
    "title": "wwfattitude",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwwfattitude.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2921-clwwfsmackdown2",
    "title": "wwfsmackdown 2",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clwwfsmackdown2.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2922-clxor",
    "title": "xor",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/clxor.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2923-codeorg",
    "title": "codeorg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/codeorg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2924-eb-client-v1-0-0r2-wasm",
    "title": "EB.Client.V1.0.0 R2.WASM",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/EB.Client.V1.0.0R2.WASM",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2925-esm",
    "title": "esm",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/esm.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2926-npm",
    "title": "npm",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/npm.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2927-skypack",
    "title": "skypack",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/skypack.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2928-supremeduelistfix",
    "title": "supremeduelistfix",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/supremeduelistfix.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2929-thiefpuzzle",
    "title": "thiefpuzzle",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/thiefpuzzle.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2930-unpkg",
    "title": "unpkg",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/unpkg.html",
    "type": "iframe",
    "category": "UGS"
  },
  {
    "id": "ugs-2931-cl-",
    "title": "?",
    "embedUrl": "https://cdn.jsdelivr.net/gh/bubbls/ugs-singlefile/UGS-Files/cl%3F.html",
    "type": "iframe",
    "category": "UGS"
  }
];
