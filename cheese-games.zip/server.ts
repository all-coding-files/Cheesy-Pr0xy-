import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const GROQ_API_KEY = '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';

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // Disable x-powered-by
  app.disable('x-powered-by');

  // Support parsing JSON & urlencoded bodies for proxy forms
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  /**
   * Helper to proxy an HTTP request to any target URL,
   * stripping frame barriers (X-Frame-Options, CSP) and letting the site load directly.
   */
  async function handleProxyRequest(targetUrlString: string, req: Request, res: Response) {
    try {
      let targetUrl = (targetUrlString || '').trim();
      if (!targetUrl) {
        res.status(400).send('Missing target URL');
        return;
      }

      if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
        targetUrl = 'https://' + targetUrl;
      }

      let parsedUrl: URL;
      try {
        parsedUrl = new URL(targetUrl);
      } catch {
        res.status(400).send('Invalid target URL');
        return;
      }

      if (!parsedUrl.hostname || !parsedUrl.hostname.includes('.')) {
        res.status(400).send('Invalid hostname');
        return;
      }

      // Realistic browser headers
      const headersToSend: Record<string, string> = {
        'User-Agent': (req.headers['user-agent'] as string) ||
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36',
        'Accept': (req.headers['accept'] as string) ||
          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': (req.headers['accept-language'] as string) || 'en-US,en;q=0.9',
        'Sec-Ch-Ua': '"Not A(Brand";v="8", "Chromium";v="132", "Google Chrome";v="132"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'cross-site',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
      };

      headersToSend['Origin'] = parsedUrl.origin;
      headersToSend['Referer'] = parsedUrl.origin + '/';
      if (req.headers['cookie']) {
        headersToSend['Cookie'] = req.headers['cookie'] as string;
      }

      const fetchOptions: RequestInit = {
        method: req.method,
        headers: headersToSend,
        redirect: 'follow'
      };

      if (req.method !== 'GET' && req.method !== 'HEAD' && req.body) {
        if (typeof req.body === 'object' && Object.keys(req.body).length > 0) {
          const contentType = req.headers['content-type'] || '';
          if (contentType.includes('application/x-www-form-urlencoded')) {
            fetchOptions.body = new URLSearchParams(req.body).toString();
          } else {
            fetchOptions.body = JSON.stringify(req.body);
          }
        }
      }

      let upstreamResponse: globalThis.Response;
      try {
        upstreamResponse = await fetch(parsedUrl.href, fetchOptions);
      } catch {
        // Fallback to http if https failed
        if (parsedUrl.protocol === 'https:') {
          try {
            const httpUrl = parsedUrl.href.replace(/^https:/, 'http:');
            upstreamResponse = await fetch(httpUrl, fetchOptions);
          } catch {
            res.status(502).send(renderGatewayNotice(targetUrlString));
            return;
          }
        } else {
          res.status(502).send(renderGatewayNotice(targetUrlString));
          return;
        }
      }

      const contentType = upstreamResponse.headers.get('content-type') || '';
      const finalUrl = upstreamResponse.url || parsedUrl.href;

      // Copy allowed headers from upstream response
      upstreamResponse.headers.forEach((value, key) => {
        const lowerKey = key.toLowerCase();
        // Rewrite location headers so redirects stay within proxy
        if (lowerKey === 'location') {
          try {
            const resolvedLoc = new URL(value, finalUrl).href;
            res.setHeader('location', `/service/${encodeURIComponent(resolvedLoc)}`);
          } catch {
            res.setHeader('location', value);
          }
          return;
        }
        if (lowerKey === 'set-cookie') {
          res.setHeader('set-cookie', value);
          return;
        }
        // Strip restrictive frame headers, COEP, COOP, and CSP that block iframe embedding
        if (
          lowerKey === 'x-frame-options' ||
          lowerKey === 'content-security-policy' ||
          lowerKey === 'content-security-policy-report-only' ||
          lowerKey === 'cross-origin-embedder-policy' ||
          lowerKey === 'cross-origin-opener-policy' ||
          lowerKey === 'cross-origin-resource-policy' ||
          lowerKey === 'content-encoding' ||
          lowerKey === 'content-length'
        ) {
          return;
        }
        res.setHeader(key, value);
      });

      // Allow iframe framing
      res.removeHeader('X-Frame-Options');
      res.removeHeader('Content-Security-Policy');
      res.setHeader('Access-Control-Allow-Origin', '*');

      const safeStatusCode = upstreamResponse.status === 404 ? 200 : upstreamResponse.status;

      // If HTML content, inject <base> tag and seamless link interceptor
      if (contentType.includes('text/html')) {
        let html = await upstreamResponse.text();

        // Inject script and base tag right after <head> or at top
        const baseHref = finalUrl;
        const injectedHead = `
<base href="${baseHref}">
<script>
(function() {
  var baseUrl = "${baseHref}";

  function notifyCheese(targetUrl) {
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'CHEESE_PROXY_NAVIGATE', url: targetUrl }, '*');
      }
    } catch(e) {}
  }

  // Notify parent of current loaded URL immediately
  notifyCheese(baseUrl);

  // Seamless Proxy Link and Form Interceptor
  document.addEventListener('click', function(e) {
    var a = e.target.closest('a');
    if (a && a.href) {
      var rawHref = a.getAttribute('href') || a.href;
      if (rawHref && !rawHref.startsWith('javascript:') && !rawHref.startsWith('#')) {
        e.preventDefault();
        try {
          var resolved = new URL(rawHref, baseUrl).href;
          notifyCheese(resolved);
          window.location.href = '/service/' + encodeURIComponent(resolved);
        } catch(err) {
          notifyCheese(a.href);
          window.location.href = '/service/' + encodeURIComponent(a.href);
        }
      }
    }
  }, true);

  document.addEventListener('submit', function(e) {
    var form = e.target;
    if (form) {
      e.preventDefault();
      var rawAction = form.getAttribute('action') || form.action || baseUrl;
      var resolvedAction = rawAction;
      try {
        resolvedAction = new URL(rawAction, baseUrl).href;
      } catch(e) {}
      var formData = new FormData(form);
      var params = new URLSearchParams(formData);
      var full = resolvedAction + (resolvedAction.includes('?') ? '&' : '?') + params.toString();
      notifyCheese(full);
      window.location.href = '/service/' + encodeURIComponent(full);
    }
  }, true);

  // Hook window.open so popups stay in proxy
  window.open = function(url) {
    if (url) {
      var resolved = url;
      try { resolved = new URL(url, baseUrl).href; } catch(e) {}
      notifyCheese(resolved);
      window.location.href = '/service/' + encodeURIComponent(resolved);
    }
    return null;
  };
})();
</script>
`;

        if (html.includes('<head>')) {
          html = html.replace('<head>', '<head>' + injectedHead);
        } else if (html.includes('<HEAD>')) {
          html = html.replace('<HEAD>', '<HEAD>' + injectedHead);
        } else {
          html = injectedHead + html;
        }

        res.status(safeStatusCode).send(html);
        return;
      }

      // For binary or streaming responses (CSS, JS, images, fonts, video streams, etc.)
      res.status(safeStatusCode);
      if (upstreamResponse.body) {
        Readable.fromWeb(upstreamResponse.body as any).pipe(res);
      } else {
        res.end();
      }
    } catch {
      res.status(502).send(renderGatewayNotice(targetUrlString));
    }
  }

  function escapeHtml(str: string): string {
    return (str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function renderGatewayNotice(targetUrl: string): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Cheese Proxy Notice</title>
  <style>
    body { font-family: monospace; background: #070608; color: #fff; padding: 40px; text-align: center; }
    .box { max-width: 600px; margin: 40px auto; background: #141118; border: 2px solid #eab308; padding: 30px; border-radius: 12px; }
    h2 { color: #facc15; margin-top: 0; }
    p { color: #a8a29e; font-size: 14px; line-height: 1.6; }
    button { background: #eab308; color: #000; border: none; padding: 10px 20px; font-weight: bold; border-radius: 6px; cursor: pointer; }
  </style>
</head>
<body>
  <div class="box">
    <h2>Cheese Proxy Notice</h2>
    <p>Could not connect directly to <strong>${escapeHtml(targetUrl)}</strong>.</p>
    <p>The host server may be temporarily down or blocking automated requests.</p>
    <p><button onclick="window.location.reload()">Retry Loading</button></p>
  </div>
</body>
</html>
    `;
  }

  // 1. Primary Proxy Endpoint: /api/proxy?url=...
  app.all('/api/proxy', async (req: Request, res: Response) => {
    const rawUrl = req.query.url as string;
    if (!rawUrl) {
      res.status(400).send('Missing target url query parameter');
      return;
    }
    await handleProxyRequest(rawUrl, req, res);
  });

  // 2. Scramjet Service Route: /service/*
  app.all('/service/*', async (req: Request, res: Response) => {
    let subpath = req.url.slice('/service/'.length);
    if (subpath.startsWith('http://') || subpath.startsWith('https://')) {
      await handleProxyRequest(subpath, req, res);
      return;
    }
    try {
      const decoded = decodeURIComponent(subpath);
      await handleProxyRequest(decoded, req, res);
    } catch {
      res.status(400).send('Invalid proxied path');
    }
  });

  // 3. Groq Proxy Endpoint: /api/groq (Bypasses any school/network filters blocking api.groq.com)
  app.post('/api/groq', async (req: Request, res: Response) => {
    try {
      const { model = 'chatgpt-120b', messages = [], temperature = 0.7, max_tokens = 1200 } = req.body;

      let upstreamModel = 'openai/gpt-oss-120b';
      let systemPersona = '';

      const lower = String(model).toLowerCase();
      if (lower.includes('llama')) {
        systemPersona = 'Your name is LLaMA. You are an AI assistant developed by Meta. If asked who you are or who created you, state clearly that you are LLaMA created by Meta. Provide direct, helpful, and insightful answers.';
        upstreamModel = 'openai/gpt-oss-120b';
      } else if (lower.includes('turbo') || lower.includes('20b')) {
        systemPersona = 'You are ChatGPT Turbo, an ultra-fast AI assistant created by OpenAI. Provide quick, direct, and concise answers.';
        upstreamModel = 'openai/gpt-oss-20b';
      } else if (lower.includes('qwen')) {
        systemPersona = 'You are Qwen, a capable and multilingual AI assistant developed by Alibaba Cloud.';
        upstreamModel = 'qwen/qwen3.8-27b';
      } else {
        // Default to ChatGPT Flagship (OpenAI GPT-OSS 120B)
        systemPersona = 'You are ChatGPT, an AI assistant developed by OpenAI. Provide thoughtful, step-by-step, and comprehensive explanations.';
        upstreamModel = 'openai/gpt-oss-120b';
      }

      // Safe token limit (Qwen OTPM safeguard)
      const safeTokens = upstreamModel === 'qwen/qwen3.8-27b' ? Math.min(max_tokens, 750) : max_tokens;

      // Ensure system/developer prompt is present to enforce authentic model identity
      const roleName = lower.includes('llama') ? 'developer' : 'system';
      const processedMessages = messages.filter((m: any) => m.role !== 'system' && m.role !== 'developer');
      processedMessages.unshift({ role: roleName, content: systemPersona });

      const groqResponse = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${GROQ_API_KEY}`
        },
        body: JSON.stringify({
          model: upstreamModel,
          messages: processedMessages,
          temperature,
          max_tokens: safeTokens
        })
      });

      if (!groqResponse.ok) {
        // Fallback to high-capacity OpenAI GPT-OSS model if the selected model had rate limit or error
        const fallbackModel = upstreamModel === 'openai/gpt-oss-120b' ? 'openai/gpt-oss-20b' : 'openai/gpt-oss-120b';

        const fallbackRes = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${GROQ_API_KEY}`
          },
          body: JSON.stringify({
            model: fallbackModel,
            messages: processedMessages,
            temperature,
            max_tokens: 1000
          })
        });

        if (fallbackRes.ok) {
          const fallbackData = await fallbackRes.json();
          return res.json(fallbackData);
        }

        const errText = await groqResponse.text();
        return res.status(groqResponse.status).send(errText);
      }

      const data = await groqResponse.json();
      res.json(data);
    } catch (err: any) {
      res.status(500).json({ error: { message: err.message || 'Groq proxy request failed' } });
    }
  });

  // 4. Vite development server or production static files
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        port: PORT,
        host: '0.0.0.0'
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Cheese Server] Running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
