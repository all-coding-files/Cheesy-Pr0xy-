importScripts('/scramjet/scramjet.all.js');

const { ScramjetServiceWorker } = $scramjetLoadWorker();
const scramjet = new ScramjetServiceWorker();

self.addEventListener('install', (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // ONLY intercept Scramjet proxied routes (/service/*)
  // NEVER block standard app assets, Vite dev scripts, or API requests!
  if (!url.pathname.startsWith('/service/')) {
    return;
  }

  event.respondWith((async () => {
    try {
      await scramjet.loadConfig();
      if (scramjet.route(event)) {
        return await scramjet.fetch(event);
      }
    } catch (err) {
      console.warn('[Scramjet Fetch Error]:', err);
    }
    return await fetch(event.request);
  })());
});
